#!/usr/bin/env python3
"""
Sync Notion study assignments into the GitHub repository.

Supported Notion assignment titles / types:
- math_theory: download submitted files only
- paper_review: download PDF/MD files and summarize them
- analysis: download report PDF/MD + IPYNB files and summarize them

Target layout:
algorithms/{algorithm}/{assignment_type}/
  README.md
  files/
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import textwrap
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


NOTION_API_BASE = "https://api.notion.com/v1"
OPENAI_RESPONSES_URL = "https://api.openai.com/v1/responses"
DEFAULT_NOTION_VERSION = "2026-03-11"
DEFAULT_OPENAI_MODEL = "gpt-5.6-terra"
ASSIGNMENT_TYPES = {"math_theory", "paper_review", "analysis"}


@dataclass
class NotionFile:
    name: str
    url: str
    source: str


@dataclass
class AssignmentRecord:
    page_id: str
    page_title: str
    notion_url: str
    author: str
    week: str
    assignment_type: str
    text: str
    files: list[NotionFile] = field(default_factory=list)
    downloaded_files: list[Path] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)


def normalize_uuid(raw: str) -> str:
    compact = re.sub(r"[^0-9a-fA-F]", "", raw)
    if len(compact) != 32:
        raise ValueError(f"Notion id must contain 32 hex characters: {raw}")
    return (
        f"{compact[0:8]}-{compact[8:12]}-{compact[12:16]}-"
        f"{compact[16:20]}-{compact[20:32]}"
    ).lower()


def notion_id_from_url_or_id(value: str) -> str:
    value = value.strip()
    if not value:
        raise ValueError("empty Notion page id/url")

    parsed = urllib.parse.urlparse(value)
    query = urllib.parse.parse_qs(parsed.query)
    if query.get("p"):
        return normalize_uuid(query["p"][0])

    matches = re.findall(r"[0-9a-fA-F]{32}", value.replace("-", ""))
    if not matches:
        raise ValueError(f"Could not find a Notion id in: {value}")
    return normalize_uuid(matches[-1])


def split_sources(value: str) -> list[str]:
    if not value:
        return []
    return [part.strip() for part in re.split(r"[,\n]+", value) if part.strip()]


def safe_filename(value: str, fallback: str = "untitled") -> str:
    value = value.strip() or fallback
    value = re.sub(r"[\\/:*?\"<>|]+", " ", value)
    value = re.sub(r"\s+", "_", value)
    value = re.sub(r"_+", "_", value)
    value = value.strip("._- ")
    return value[:120] or fallback


def plain_text(items: list[dict[str, Any]] | None) -> str:
    if not items:
        return ""
    return "".join(item.get("plain_text", "") for item in items)


def property_to_text(prop: dict[str, Any]) -> str:
    kind = prop.get("type")
    if kind == "title":
        return plain_text(prop.get("title"))
    if kind == "rich_text":
        return plain_text(prop.get("rich_text"))
    if kind == "status":
        return (prop.get("status") or {}).get("name", "")
    if kind == "select":
        return (prop.get("select") or {}).get("name", "")
    if kind == "multi_select":
        return ", ".join(item.get("name", "") for item in prop.get("multi_select", []))
    if kind == "people":
        return ", ".join(person.get("name", "") for person in prop.get("people", []))
    if kind == "url":
        return prop.get("url") or ""
    if kind == "files":
        return ", ".join(item.get("name", "") for item in prop.get("files", []))
    if kind == "checkbox":
        return "true" if prop.get("checkbox") else "false"
    if kind == "date":
        date = prop.get("date") or {}
        return date.get("start", "")
    if kind == "number":
        number = prop.get("number")
        return "" if number is None else str(number)
    return ""


def page_title(page: dict[str, Any]) -> str:
    for prop in page.get("properties", {}).values():
        if prop.get("type") == "title":
            title = property_to_text(prop)
            if title:
                return title
    return "Untitled"


def page_author(page: dict[str, Any]) -> str:
    preferred = ["담당자", "작성자", "발표자", "Author", "Assignee", "Owner"]
    props = page.get("properties", {})
    for name in preferred:
        if name in props:
            value = property_to_text(props[name])
            if value:
                return value
    for prop in props.values():
        if prop.get("type") == "people":
            value = property_to_text(prop)
            if value:
                return value
    return "unknown"


def display_author_name(author: str) -> str:
    aliases = {
        "jaesungkang": "강재성",
        "wjddbsl03": "신정윤",
        "pjh": "박중현",
        "노랑고흐": "박중현",
    }
    normalized = re.sub(r"[^0-9a-zA-Z가-힣]+", "", author).lower()
    for key, value in aliases.items():
        if key in normalized:
            return value
    return author


def page_url(page: dict[str, Any], page_id: str) -> str:
    return page.get("url") or f"https://www.notion.so/{page_id.replace('-', '')}"


def normalize_assignment_type(value: str) -> str:
    normalized = re.sub(r"[\s\-]+", "_", value.strip().lower())
    aliases = {
        "math": "math_theory",
        "theory": "math_theory",
        "math_theory": "math_theory",
        "paper": "paper_review",
        "paper_review": "paper_review",
        "review": "paper_review",
        "analysis": "analysis",
        "project": "analysis",
        "mini_project": "analysis",
    }
    return aliases.get(normalized, normalized)


def infer_assignment_type(page: dict[str, Any], explicit: str) -> str:
    if explicit:
        return normalize_assignment_type(explicit)

    props = page.get("properties", {})
    candidates = [
        page_title(page),
        property_to_text(props.get("유형", {})),
        property_to_text(props.get("과제 유형", {})),
        property_to_text(props.get("과제", {})),
        property_to_text(props.get("Title", {})),
    ]
    joined = " ".join(item for item in candidates if item).lower()
    for assignment_type in ASSIGNMENT_TYPES:
        if assignment_type in joined:
            return assignment_type
    for raw, canonical in {
        "paper": "paper_review",
        "review": "paper_review",
        "project": "analysis",
        "analysis": "analysis",
        "math": "math_theory",
        "theory": "math_theory",
    }.items():
        if raw in joined:
            return canonical
    return ""


def page_week(page: dict[str, Any], fallback: str) -> str:
    props = page.get("properties", {})
    for name in ["주차", "Week", "week"]:
        if name in props:
            value = property_to_text(props[name])
            if value:
                return value
    return fallback


class NotionClient:
    def __init__(self, token: str, version: str = DEFAULT_NOTION_VERSION) -> None:
        self.token = token
        self.version = version

    def request(self, method: str, path: str, body: dict[str, Any] | None = None) -> dict[str, Any]:
        url = f"{NOTION_API_BASE}{path}"
        data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Notion-Version": self.version,
            "Content-Type": "application/json",
        }
        req = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=45) as res:
                return json.loads(res.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Notion API error {exc.code}: {detail}") from exc

    def retrieve_page(self, page_id: str) -> dict[str, Any]:
        return self.request("GET", f"/pages/{page_id}")

    def retrieve_block_children(self, block_id: str) -> list[dict[str, Any]]:
        children: list[dict[str, Any]] = []
        cursor: str | None = None
        while True:
            query = {"page_size": "100"}
            if cursor:
                query["start_cursor"] = cursor
            path = f"/blocks/{block_id}/children?{urllib.parse.urlencode(query)}"
            data = self.request("GET", path)
            children.extend(data.get("results", []))
            if not data.get("has_more"):
                return children
            cursor = data.get("next_cursor")
            time.sleep(0.35)

    def query_source(self, source_id: str, source_kind: str) -> list[dict[str, Any]]:
        endpoint = "data_sources" if source_kind == "data_source" else "databases"
        source_uuid = notion_id_from_url_or_id(source_id)
        pages: list[dict[str, Any]] = []
        cursor: str | None = None
        while True:
            body: dict[str, Any] = {"page_size": 100}
            if cursor:
                body["start_cursor"] = cursor
            data = self.request("POST", f"/{endpoint}/{source_uuid}/query", body)
            pages.extend(data.get("results", []))
            if not data.get("has_more"):
                return pages
            cursor = data.get("next_cursor")
            time.sleep(0.35)


def rich_text_from_block(block: dict[str, Any]) -> str:
    kind = block.get("type")
    data = block.get(kind) or {}
    if kind in {
        "paragraph",
        "heading_1",
        "heading_2",
        "heading_3",
        "bulleted_list_item",
        "numbered_list_item",
        "quote",
        "callout",
        "toggle",
    }:
        return plain_text(data.get("rich_text"))
    if kind == "to_do":
        checked = "[x]" if data.get("checked") else "[ ]"
        return f"{checked} {plain_text(data.get('rich_text'))}".strip()
    if kind == "child_database":
        return data.get("title", "")
    return ""


def file_from_notion_obj(obj: dict[str, Any], source: str) -> NotionFile | None:
    kind = obj.get("type")
    url = ""
    expiry = None
    if kind == "file":
        data = obj.get("file") or {}
        url = data.get("url", "")
        expiry = data.get("expiry_time")
    elif kind == "external":
        data = obj.get("external") or {}
        url = data.get("url", "")
    if not url:
        return None
    name = obj.get("name") or Path(urllib.parse.urlparse(url).path).name or "notion_file"
    if expiry:
        source = f"{source}; expires={expiry}"
    return NotionFile(name=name, url=url, source=source)


def page_property_files(page: dict[str, Any]) -> list[NotionFile]:
    files: list[NotionFile] = []
    for prop_name, prop in page.get("properties", {}).items():
        if prop.get("type") != "files":
            continue
        for item in prop.get("files", []):
            notion_file = file_from_notion_obj(item, f"property:{prop_name}")
            if notion_file:
                files.append(notion_file)
    return files


def block_file(block: dict[str, Any]) -> NotionFile | None:
    kind = block.get("type")
    if kind not in {"file", "pdf"}:
        return None
    data = block.get(kind) or {}
    notion_file = file_from_notion_obj(data, f"block:{kind}")
    if notion_file and kind == "pdf" and not notion_file.name.lower().endswith(".pdf"):
        notion_file.name = f"{notion_file.name}.pdf"
    return notion_file


def read_blocks_recursive(client: NotionClient, block_id: str, depth: int = 0) -> tuple[str, list[NotionFile]]:
    if depth > 4:
        return "", []
    lines: list[str] = []
    files: list[NotionFile] = []
    for block in client.retrieve_block_children(block_id):
        text = rich_text_from_block(block)
        if text:
            lines.append(text)
        notion_file = block_file(block)
        if notion_file:
            files.append(notion_file)
        if block.get("has_children"):
            child_text, child_files = read_blocks_recursive(client, block["id"], depth + 1)
            if child_text:
                lines.append(child_text)
            files.extend(child_files)
    return "\n".join(lines), files


def filter_page(
    page: dict[str, Any],
    *,
    week: str,
    algorithm: str,
    assignment_type: str,
    status_prop: str,
    status_done: str,
    week_prop: str,
    algorithm_prop: str,
) -> bool:
    props = page.get("properties", {})

    def prop_value(name: str) -> str:
        return property_to_text(props[name]).lower() if name in props else ""

    if status_prop in props and status_done:
        if status_done.lower() not in prop_value(status_prop):
            return False
    if week_prop in props and week:
        if week.lower() not in prop_value(week_prop):
            return False
    if algorithm_prop in props and algorithm:
        if algorithm.lower() not in prop_value(algorithm_prop):
            return False

    inferred = infer_assignment_type(page, "")
    if assignment_type:
        if not inferred:
            return False
        if assignment_type != inferred:
            return False
    return True


def allowed_suffixes(assignment_type: str) -> set[str]:
    if assignment_type == "analysis":
        return {".pdf", ".md", ".ipynb"}
    if assignment_type == "paper_review":
        return {".pdf", ".md"}
    if assignment_type == "math_theory":
        return {".pdf", ".md", ".jpg", ".jpeg", ".png", ".webp"}
    return set()


def download_file(
    file: NotionFile,
    target_dir: Path,
    record: AssignmentRecord,
    dry_run: bool = False,
) -> Path | None:
    parsed_name = urllib.parse.unquote(file.name)
    suffix = Path(parsed_name).suffix.lower()

    if not suffix:
        url_suffix = Path(urllib.parse.urlparse(urllib.parse.unquote(file.url)).path).suffix.lower()
        suffix = url_suffix
        if suffix:
            parsed_name = f"{parsed_name}{suffix}"

    if suffix not in allowed_suffixes(record.assignment_type):
        return None

    author = safe_filename(display_author_name(record.author), "unknown")
    title = safe_filename(record.page_title, record.assignment_type)
    original = safe_filename(Path(parsed_name).stem, "file")
    filename = f"{author}_{title}_{original}{suffix}"
    path = target_dir / filename

    if dry_run:
        return path

    target_dir.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(file.url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=120) as res:
        content = res.read()
    if path.exists() and path.read_bytes() == content:
        return path
    path.write_bytes(content)
    return path


def extract_pdf_text(pdf_path: Path) -> str:
    try:
        from pypdf import PdfReader  # type: ignore
    except Exception:
        return ""
    try:
        reader = PdfReader(str(pdf_path))
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    except Exception:
        return ""


def extract_ipynb_text(ipynb_path: Path) -> str:
    try:
        data = json.loads(ipynb_path.read_text(encoding="utf-8"))
    except Exception:
        return ""
    chunks: list[str] = []
    for index, cell in enumerate(data.get("cells", []), start=1):
        source = "".join(cell.get("source", [])).strip()
        if not source:
            continue
        cell_type = cell.get("cell_type", "cell")
        chunks.append(f"--- {cell_type} cell {index} ---\n{source}")
    return "\n\n".join(chunks)


def extract_text(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return extract_pdf_text(path)
    if suffix == ".ipynb":
        return extract_ipynb_text(path)
    if suffix == ".md":
        try:
            return path.read_text(encoding="utf-8")
        except Exception:
            return ""
    return ""


def build_summary_source(record: AssignmentRecord, allow_text_fallback: bool) -> str:
    parts: list[str] = []
    for path in record.downloaded_files:
        text = extract_text(path).strip()
        if text:
            parts.append(f"--- FILE: {path.name} ---\n{text}")
    if parts:
        return "\n\n".join(parts)
    if allow_text_fallback and record.text.strip():
        return record.text.strip()
    raise RuntimeError(
        f"{record.page_title}: no readable text found. "
        "For summaries, submit text-based PDF/MD or a readable IPYNB."
    )


def openai_json(prompt: str, schema: dict[str, Any], model: str) -> dict[str, Any]:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is required for summaries")

    payload = {
        "model": model,
        "store": False,
        "input": [{"role": "user", "content": [{"type": "input_text", "text": prompt}]}],
        "text": {
            "format": {
                "type": "json_schema",
                "name": "assignment_summary",
                "schema": schema,
                "strict": True,
            }
        },
        "max_output_tokens": 1600,
    }
    req = urllib.request.Request(
        OPENAI_RESPONSES_URL,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as res:
            data = json.loads(res.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"OpenAI API error {exc.code}: {detail}") from exc

    if "output_text" in data:
        return json.loads(data["output_text"])

    parts: list[str] = []
    for item in data.get("output", []):
        for content in item.get("content", []):
            if content.get("type") in {"output_text", "text"}:
                parts.append(content.get("text", ""))
    output_text = "\n".join(parts).strip()
    if not output_text:
        raise RuntimeError("OpenAI response did not contain output text")
    return json.loads(output_text)


def summarize_record(record: AssignmentRecord, model: str, allow_text_fallback: bool) -> dict[str, Any]:
    if record.assignment_type == "math_theory":
        return {}

    source_text = build_summary_source(record, allow_text_fallback)[:45000]
    meta = f"""
메타데이터:
- 과제 유형: {record.assignment_type}
- 주차: {record.week}
- 제목: {record.page_title}
- 작성자: {record.author}
- Notion URL: {record.notion_url}
- 첨부 파일: {", ".join(path.name for path in record.downloaded_files) or "없음"}
"""

    if record.assignment_type == "paper_review":
        schema = {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "source": {"type": "string"},
                "keywords": {"type": "array", "items": {"type": "string"}, "minItems": 3, "maxItems": 8},
                "summary": {"type": "array", "items": {"type": "string"}, "minItems": 3, "maxItems": 5},
            },
            "required": ["source", "keywords", "summary"],
        }
        prompt = f"""{meta}

아래 논문 리뷰 제출물을 읽고 GitHub README에 들어갈 짧은 요약을 작성한다.
문체는 논문 개요처럼 담백하게 쓴다.
각 요약 bullet은 한 문장으로 작성한다.

자료:
{source_text}
"""
        return openai_json(prompt, schema, model)

    schema = {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "topic": {"type": "string"},
            "data": {"type": "string"},
            "method": {"type": "string"},
            "result": {"type": "string"},
            "summary": {"type": "array", "items": {"type": "string"}, "minItems": 3, "maxItems": 5},
        },
        "required": ["topic", "data", "method", "result", "summary"],
    }
    prompt = f"""{meta}

아래 분석 보고서와 노트북 내용을 읽고 GitHub README에 들어갈 짧은 분석 요약을 작성한다.
결과 이미지 파일은 별도로 저장하지 않으므로, 보고서와 노트북에 기록된 내용만 기준으로 정리한다.
각 요약 bullet은 발표 전에 빠르게 읽을 수 있게 간결하게 쓴다.

자료:
{source_text}
"""
    return openai_json(prompt, schema, model)


def markdown_link(path: Path, base_dir: Path) -> str:
    rel = path.relative_to(base_dir).as_posix()
    return f"[{path.name}]({rel})"


def file_links(record: AssignmentRecord, readme_dir: Path, suffixes: set[str] | None = None) -> str:
    paths = record.downloaded_files
    if suffixes is not None:
        paths = [path for path in paths if path.suffix.lower() in suffixes]
    return ", ".join(markdown_link(path, readme_dir) for path in paths) or "파일 확인 필요"


def build_markdown_section(records: list[AssignmentRecord], assignment_type: str, readme_dir: Path) -> str:
    title_map = {
        "math_theory": "## Math Theory",
        "paper_review": "## Paper Review",
        "analysis": "## Analysis",
    }
    lines = [title_map[assignment_type], ""]

    if assignment_type == "math_theory":
        lines.extend([
            "| 주차 | 작성자 | 제출 파일 | Notion |",
            "|---|---|---|---|",
        ])
        for record in records:
            lines.append(
                f"| {record.week or '-'} | {display_author_name(record.author)} | "
                f"{file_links(record, readme_dir)} | [Notion]({record.notion_url}) |"
            )
        return "\n".join(lines).rstrip() + "\n"

    if assignment_type == "paper_review":
        lines.extend([
            "| 주차 | 작성자 | 논문/자료 | 키워드 | 파일 | Notion |",
            "|---|---|---|---|---|---|",
        ])
        for record in records:
            keywords = record.summary.get("keywords") or []
            lines.append(
                f"| {record.week or '-'} | {display_author_name(record.author)} | "
                f"{record.summary.get('source', record.page_title)} | "
                f"{', '.join(keywords) if keywords else '확인 필요'} | "
                f"{file_links(record, readme_dir)} | [Notion]({record.notion_url}) |"
            )
        lines.extend(["", "### Summary", ""])
        for record in records:
            lines.extend([f"#### {display_author_name(record.author)}", ""])
            for bullet in record.summary.get("summary", []):
                lines.append(f"- {bullet}")
            lines.append("")
        return "\n".join(lines).rstrip() + "\n"

    lines.extend([
        "| 주차 | 작성자 | 분석 주제 | 보고서 | 노트북 | Notion |",
        "|---|---|---|---|---|---|",
    ])
    for record in records:
        lines.append(
            f"| {record.week or '-'} | {display_author_name(record.author)} | "
            f"{record.summary.get('topic', record.page_title)} | "
            f"{file_links(record, readme_dir, {'.pdf', '.md'})} | "
            f"{file_links(record, readme_dir, {'.ipynb'})} | [Notion]({record.notion_url}) |"
        )
    lines.extend(["", "### Summary", ""])
    for record in records:
        lines.extend([f"#### {display_author_name(record.author)}", ""])
        summary = record.summary
        if summary.get("data"):
            lines.append(f"- 데이터: {summary['data']}")
        if summary.get("method"):
            lines.append(f"- 방법: {summary['method']}")
        if summary.get("result"):
            lines.append(f"- 결과: {summary['result']}")
        for bullet in summary.get("summary", []):
            lines.append(f"- {bullet}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def update_readme(readme_path: Path, section: str, assignment_type: str, dry_run: bool = False) -> None:
    start = f"<!-- notion-assignment-sync:{assignment_type}:start -->"
    end = f"<!-- notion-assignment-sync:{assignment_type}:end -->"
    managed = f"{start}\n{section}{end}\n"

    if readme_path.exists():
        original = readme_path.read_text(encoding="utf-8")
    else:
        original = f"# {assignment_type}\n"

    pattern = re.compile(re.escape(start) + r".*?" + re.escape(end) + r"\n?", re.DOTALL)
    if pattern.search(original):
        updated = pattern.sub(managed, original)
    else:
        updated = original.rstrip() + "\n\n" + managed

    if not dry_run:
        readme_path.parent.mkdir(parents=True, exist_ok=True)
        readme_path.write_text(updated, encoding="utf-8")


def collect_records(args: argparse.Namespace) -> list[AssignmentRecord]:
    token = os.getenv("NOTION_API_KEY")
    if not token:
        raise RuntimeError("NOTION_API_KEY is required")

    client = NotionClient(token, os.getenv("NOTION_VERSION", DEFAULT_NOTION_VERSION))
    page_ids = [notion_id_from_url_or_id(item) for item in split_sources(args.notion_pages)]

    if args.notion_source_id:
        candidates = client.query_source(args.notion_source_id, args.notion_source_kind)
        for page in candidates:
            if filter_page(
                page,
                week=args.week,
                algorithm=args.algorithm,
                assignment_type=args.assignment_type,
                status_prop=args.status_prop,
                status_done=args.status_done,
                week_prop=args.week_prop,
                algorithm_prop=args.algorithm_prop,
            ):
                page_ids.append(page["id"])

    if not page_ids:
        raise RuntimeError("Provide --notion-pages or --notion-source-id")

    records: list[AssignmentRecord] = []
    seen: set[str] = set()
    for page_id in page_ids:
        if page_id in seen:
            continue
        seen.add(page_id)
        page = client.retrieve_page(page_id)
        assignment_type = infer_assignment_type(page, args.assignment_type)
        if assignment_type not in ASSIGNMENT_TYPES:
            raise RuntimeError(
                f"{page_title(page)}: assignment type must be one of "
                f"{', '.join(sorted(ASSIGNMENT_TYPES))}"
            )
        text, block_files = read_blocks_recursive(client, page_id)
        record = AssignmentRecord(
            page_id=page_id,
            page_title=page_title(page),
            notion_url=page_url(page, page_id),
            author=page_author(page),
            week=page_week(page, args.week),
            assignment_type=assignment_type,
            text=text,
            files=page_property_files(page) + block_files,
        )
        records.append(record)
    return records


def run(args: argparse.Namespace) -> int:
    root = Path(args.repo_root).resolve()
    assignment_type = normalize_assignment_type(args.assignment_type)
    if assignment_type not in ASSIGNMENT_TYPES:
        raise RuntimeError(f"--assignment-type must be one of: {', '.join(sorted(ASSIGNMENT_TYPES))}")

    target_dir = root / "algorithms" / args.algorithm / assignment_type
    files_dir = target_dir / "files"
    readme_path = target_dir / "README.md"

    records = collect_records(args)
    for record in records:
        if record.assignment_type != assignment_type:
            continue
        for notion_file in record.files:
            downloaded = download_file(notion_file, files_dir, record, args.dry_run)
            if downloaded:
                record.downloaded_files.append(downloaded)

        if assignment_type != "math_theory" and not args.skip_summary:
            record.summary = summarize_record(
                record,
                os.getenv("OPENAI_MODEL", DEFAULT_OPENAI_MODEL),
                allow_text_fallback=args.allow_text_fallback,
            )
        elif assignment_type != "math_theory":
            record.summary = {"topic": record.page_title, "summary": []}

    records = [record for record in records if record.assignment_type == assignment_type]
    if not records:
        raise RuntimeError(f"No records matched assignment type: {assignment_type}")

    section = build_markdown_section(records, assignment_type, readme_path.parent)
    update_readme(readme_path, section, assignment_type, args.dry_run)

    print(f"Processed {len(records)} Notion assignment page(s).")
    print(f"Target: {target_dir}")
    print(f"README: {readme_path}")
    for record in records:
        print(f"- {display_author_name(record.author)}: {record.page_title}")
        for file_path in record.downloaded_files:
            print(f"  FILE: {file_path}")

    if args.dry_run:
        print("\n--- README section preview ---")
        print(section)
    return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Sync Notion study assignments to GitHub folders and README summaries.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent(
            """
            Examples:
              python scripts/sync_notion_assignments_to_github.py --algorithm svm --assignment-type analysis --week W8 --notion-pages "URL1,URL2"
              python scripts/sync_notion_assignments_to_github.py --algorithm svm --assignment-type math_theory --week W6 --notion-source-id "..."
            """
        ),
    )
    parser.add_argument("--repo-root", default=".", help="Repository root path.")
    parser.add_argument("--algorithm", default=os.getenv("STUDY_ALGORITHM", "svm"))
    parser.add_argument("--assignment-type", default=os.getenv("STUDY_ASSIGNMENT_TYPE", "paper_review"))
    parser.add_argument("--week", default=os.getenv("STUDY_WEEK", ""))
    parser.add_argument("--notion-pages", default=os.getenv("NOTION_PAGES", ""), help="Comma/newline-separated Notion page URLs or IDs.")
    parser.add_argument("--notion-source-id", default=os.getenv("NOTION_SOURCE_ID", ""), help="Optional Notion data source/database ID.")
    parser.add_argument("--notion-source-kind", default=os.getenv("NOTION_SOURCE_KIND", "data_source"), choices=["data_source", "database"])
    parser.add_argument("--status-prop", default=os.getenv("NOTION_STATUS_PROP", "상태"))
    parser.add_argument("--status-done", default=os.getenv("NOTION_STATUS_DONE", "완료"))
    parser.add_argument("--week-prop", default=os.getenv("NOTION_WEEK_PROP", "주차"))
    parser.add_argument("--algorithm-prop", default=os.getenv("NOTION_ALGORITHM_PROP", "알고리즘"))
    parser.add_argument(
        "--allow-text-fallback",
        action="store_true",
        help="If submitted files have no readable text, summarize the Notion body instead.",
    )
    parser.add_argument(
        "--skip-summary",
        action="store_true",
        help="Download files and update tables without calling OpenAI. Useful for testing.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Read and summarize, but do not write files.")
    return parser.parse_args()


if __name__ == "__main__":
    try:
        raise SystemExit(run(parse_args()))
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(1)
