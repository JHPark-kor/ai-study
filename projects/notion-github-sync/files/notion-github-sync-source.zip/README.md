# Notion–GitHub 과제 정리 소스

Notion 첨부 자료를 `algorithms/{algorithm}/{assignment_type}/files/`에 저장하고 해당 과제의 README를 작성하는 Python 소스 패키지입니다.

## 로컬 사용

1. Python 3.10 이상에서 이 폴더를 엽니다.
2. `python -m pip install -r requirements.txt`를 실행합니다.
3. Notion integration에 대상 카드 접근 권한을 연결하고 실행 환경에 `NOTION_API_KEY`를 설정합니다. 요약에는 `OPENAI_API_KEY`와 사용할 `OPENAI_MODEL`을 설정합니다.
4. 대상 저장소와 카드 URL을 지정합니다.

```bash
python scripts/sync_notion_assignments_to_github.py --repo-root /path/to/study --algorithm bayesian --assignment-type math_theory --week W9 --notion-pages "NOTION_CARD_URL"
```

같은 알고리즘·과제 유형의 README에 남길 카드 전체를 한 번에 지정합니다. 자동 관리 영역은 이번 실행에 지정한 카드 목록으로 갱신됩니다.

과제 유형은 `math_theory`, `paper_review`, `analysis`입니다. 수학은 파일과 표만 정리하며, 논문 리뷰와 분석은 읽을 수 있는 PDF/MD/IPYNB 텍스트를 요약합니다. `--skip-summary`는 요약을 생략하고, `--allow-text-fallback`은 첨부에서 텍스트를 얻지 못할 때 Notion 본문을 사용합니다. 여러 카드 URL은 쉼표로 구분합니다.

## GitHub Actions

`scripts/`, `prompts/`, `.github/workflows/notion-sync.yml`을 대상 저장소의 같은 경로에 배치합니다. 저장소 Actions secrets에 `NOTION_API_KEY`, 요약용 `OPENAI_API_KEY`를 등록하고 Actions variable `OPENAI_MODEL`에 사용할 모델을 지정합니다. Actions의 PR 생성 권한을 허용한 뒤 `Sync Notion assignments`를 수동 실행합니다. 워크플로는 변경 브랜치와 PR을 생성하며, 검토 후 병합하는 구성입니다.

주 실행 파일은 `scripts/sync_notion_assignments_to_github.py`입니다. `scripts/sync_notion_to_github.py`와 `prompts/paper_review_summary.txt`는 PDF 논문 리뷰용 초기 구현입니다. 비밀값은 환경 변수나 Actions secrets로 관리합니다.
