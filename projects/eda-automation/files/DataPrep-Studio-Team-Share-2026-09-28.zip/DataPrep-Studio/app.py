"""One-page data review. Long jobs run in worker.py, not in the browser session."""
from __future__ import annotations

import html
import datetime as dt
import json
import re
import uuid

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from studio.config import ROOT
from studio.analysis_loader import inspect_archive
from studio.repository import Repository
from studio.service import Service, registered_path, read_frame
from studio.styles import CSS

st.set_page_config(page_title='DataPrep Studio',page_icon='◈',layout='wide',initial_sidebar_state='auto')
st.markdown(CSS,unsafe_allow_html=True)


@st.cache_resource
def backend():
    repo=Repository(); repo.initialize()
    return repo,Service(repo)


def action(fn,*args):
    try:
        fn(*args)
        st.rerun()
    except Exception as exc:
        st.error(str(exc))


def section(number,title):
    st.markdown(f'<div class="step-title"><span class="step-no">{number:02}</span><span class="step-name">{html.escape(title)}</span></div>',unsafe_allow_html=True)


def stage_navigation(state):
    stages=['데이터 개요','데이터 이해','변수 진단','정제 검토','결과']
    if state.get('stage')=='outputs':active=5
    elif state.get('stage') in ('basic_review','deep_review'):active=4
    elif state.get('profile'):active=3
    elif state.get('understanding'):active=2
    else:active=1
    items=[]
    for index,label in enumerate(stages,1):
        status='active' if index==active else 'done' if index<active else ''
        items.append(f'<div class="stage-item {status}"><span class="stage-index">{index}</span><span class="stage-label">{label}</span></div>')
    st.markdown('<div class="stage-nav">'+''.join(items)+'</div>',unsafe_allow_html=True)


def readable(value):
    if value is None:return '—'
    if isinstance(value,(dict,list)):return json.dumps(value,ensure_ascii=False)
    return str(value)


def connection_panel():
    from studio.codex_client import check_connection,start_login,login_status,cancel_login
    from studio.diagnostics import auth_transport
    with st.expander('연결 설정',expanded=False):
        auth=st.session_state.get('auth',{})
        st.caption('ChatGPT로 로그인한 Codex를 사용합니다.')
        st.write('Codex · '+('로그인됨' if auth.get('connected') else '확인 필요'))
        if st.button('연결 확인',use_container_width=True):
            with st.spinner('연결 상태 확인 중'):
                try:
                    st.session_state.auth=check_connection(refresh=True)
                    st.session_state.auth_transport=auth_transport()
                except Exception as exc:st.session_state.auth={'error':str(exc)}
            st.rerun()
        if auth.get('error'):st.caption(auth['error'])
        transport=st.session_state.get('auth_transport')
        if transport:
            if transport['reachable']:st.caption('인증 서버 연결 확인됨')
            else:st.error(transport['message'])
        if not auth.get('connected'):
            if st.button('ChatGPT로 로그인',use_container_width=True):
                try:
                    transport=auth_transport()
                    st.session_state.auth_transport=transport
                    if not transport['reachable']:
                        st.warning('인증 서버 사전 확인에 실패했습니다. Codex 연결 방식으로 로그인을 시도합니다.')
                    previous_login=st.session_state.pop('login',None)
                    if previous_login:
                        try:cancel_login(previous_login['login_id'])
                        except Exception:pass
                    st.session_state.login=start_login()
                except Exception as exc:st.error(str(exc))
            login=st.session_state.get('login')
            if login:
                st.link_button('로그인 페이지 열기',login['auth_url'],use_container_width=True)
                if st.button('로그인 완료 확인',use_container_width=True):
                    try:
                        result=login_status(login['login_id'])
                        if result['status']=='completed':
                            st.session_state.auth=result.get('connection') or check_connection()
                            st.session_state.pop('login',None);st.rerun()
                        elif result.get('error'):st.error(result['error'])
                        else:st.info('브라우저에서 로그인을 마친 뒤 다시 확인해 주세요.')
                    except Exception as exc:st.error(str(exc))
                if st.button('로그인 취소'):
                    cancel_login(login['login_id']);st.session_state.pop('login',None);st.rerun()
        st.caption('로그인 상태와 실제 분석 응답 여부는 따로 표시합니다.')


def upload(service):
    st.markdown('<div class="eyebrow">데이터 점검</div>',unsafe_allow_html=True)
    st.title('데이터를 이해하는 것부터')
    st.markdown('<div class="empty-intro">파일을 올리면 데이터의 구조와 품질을 먼저 살펴봅니다.<br>확인이 필요한 내용은 대화로 정리하고, 데이터 변경 전에는 영향을 미리 보여드립니다.</div>',unsafe_allow_html=True)
    with st.container(border=True):
        section(0,'데이터 입력')
        raw=st.file_uploader('분석할 데이터',type=['csv','xlsx','txt','tsv','arff','ts','zip'],
                             help='CSV, Excel, 구분자 텍스트, ARFF, TS 또는 ZIP · 최대 150MB · 변환 후 300개 컬럼')
        archive_items=[];archive_error=None
        if raw is not None and raw.name.lower().endswith('.zip'):
            try:archive_items=inspect_archive(raw.getvalue())
            except Exception as exc:archive_error=str(exc);st.error(archive_error)
        with st.form('upload',border=False):
            archive_member=None
            if archive_items:
                options=[item['name'] for item in archive_items]
                details={item['name']:f"{item['name']} · {item['size_bytes']/1024/1024:,.1f}MB" for item in archive_items}
                archive_member=st.selectbox('ZIP 안에서 분석할 파일',options,format_func=lambda name:details[name])
                st.caption(f'지원하는 데이터 파일 {len(options)}개를 찾았습니다. 선택한 파일만 메모리에서 읽고 ZIP 원본은 그대로 보관합니다.')
            goal=st.text_area('분석 목적',placeholder='예: 지역별 카드 이용 현황을 비교하고 이용이 낮은 집단의 특성을 파악하려고 합니다.',height=90,help='아직 정하지 않았다면 비워두어도 됩니다.')
            effort=st.selectbox('AI 분석 강도',['low','medium','high'],index=1,
                                format_func=lambda value:{'low':'빠르게 · 예상 사용량 적음','medium':'균형 있게 · 예상 사용량 보통','high':'꼼꼼하게 · 예상 사용량 많음'}[value],
                                help='현재 ChatGPT 계정에서 이 강도를 지원하는 Codex 모델을 자동으로 선택합니다. 파일 전체 대신 Python 요약과 필요한 근거만 전달합니다.')
            with st.expander('데이터 설명과 메타데이터 추가'):
                meta=st.file_uploader('컬럼 정의서 또는 설명 파일',type=['csv','xlsx','json','txt','md'])
                explanation=st.text_area('알고 있는 내용',placeholder='한 행의 의미, 컬럼 단위, 코드값, 수집 방식 등을 적어 주세요.')
                source=st.text_input('출처',placeholder='예: 내부 거래 시스템')
                period=st.text_input('수집 기간',placeholder='예: 2026년 8월')
            submitted=st.form_submit_button('분석 시작',type='primary',use_container_width=True)
        if submitted:
            if raw is None:st.warning('분석할 파일을 선택해 주세요.')
            elif archive_error:st.warning('ZIP 파일의 구성을 확인해 주세요.')
            else:
                try:
                    settings={'reasoning_effort':effort}
                    if archive_member:settings['archive_member']=archive_member
                    pid=service.create(raw.getvalue(),raw.name,goal,meta.getvalue() if meta else None,meta.name if meta else None,explanation,{'source':source,'collection_period':period},settings)
                    st.query_params['project']=pid;st.rerun()
                except Exception as exc:st.error(str(exc))
        st.caption('원본은 보관하며, 데이터 변경은 미리보기를 확인하고 승인한 뒤 적용합니다.')
    if st.button('예제 데이터로 둘러보기',type='tertiary'):
        try:
            pid=service.create((ROOT/'samples/orders.csv').read_bytes(),'예제_거래.csv','지역별 거래 현황과 취소 거래 특성을 비교한다.',metadata_text='한 행은 거래 한 건입니다. 거래ID는 6자리 식별자입니다. 단가와 결제금액의 단위는 원입니다. 취소 거래는 결제금액을 음수로 기록합니다. 수집 기간은 2026년 8월입니다. 실제 업무 데이터가 아닌 합성 예제입니다.',source_info={'source':'합성 예제 데이터'},settings={'reasoning_effort':'medium'})
            st.query_params['project']=pid;st.rerun()
        except Exception as exc:st.error(str(exc))


def overview(state):
    p=state['profile'];o=p.get('overview',{})
    with st.container(border=True):
        section(1,'데이터 개요')
        metrics=[]
        for label,key in zip(['행','컬럼','결측값','중복 행'],['rows','columns','missing_cells','duplicate_rows']):
            value=o.get(key,0)
            shown=f'{value:,}' if isinstance(value,(float,int)) else readable(value)
            metrics.append(f'<div class="overview-metric"><span>{label}</span><strong>{html.escape(shown)}</strong></div>')
        st.markdown('<div class="overview-grid">'+''.join(metrics)+'</div>',unsafe_allow_html=True)
        context=state.get('context',{})
        warnings=state.get('metadata_warnings',[])+state.get('ingest',{}).get('warnings',[])
        details=f"파일 정보 · {state['version_id']} · 메모리 {o.get('memory_bytes',0)/1024/1024:,.1f}MB"
        with st.expander(details):
            st.caption(state['filename'])
            if state.get('ingest',{}).get('archive_member'):
                st.write('ZIP 내부 파일 · '+state['ingest']['archive_member'])
            if context.get('source') or context.get('collection_period'):
                st.write(' · '.join(x for x in [f"출처: {context['source']}" if context.get('source') else '',f"수집 기간: {context['collection_period']}" if context.get('collection_period') else ''] if x))
            if warnings:
                st.markdown('**읽기 설정·확인 사항**')
                for warning in warnings:st.write('• '+readable(warning))


def explanation(state,service=None,busy=False):
    result=state.get('analysis',{});context=state.get('context',{})
    description=context.get('dataset_description') or result.get('dataset_description')
    understanding=state.get('understanding',{})
    with st.container(border=True):
        section(2,'이 데이터는 무엇인가요?')
        if description:st.markdown(f'<div class="summary-lead">{html.escape(polite_analysis_text(description))}</div>',unsafe_allow_html=True)
        else:st.caption('전체 데이터의 특성과 컬럼 간 맥락을 종합해 설명을 작성하고 있습니다.' if busy else '데이터 설명을 요청하면 전체 맥락과 분석 활용 방안을 확인할 수 있습니다.')
        if context.get('observation_unit'):
            st.markdown(f'<div class="observation-unit">관측 단위 · {html.escape(polite_analysis_text(readable(context["observation_unit"])))}</div>',unsafe_allow_html=True)
        if understanding.get('status')=='failed':
            st.warning('데이터 설명을 끝까지 받지 못했습니다. 작성된 내용은 유지되며, 다시 요청하면 남은 컬럼부터 이어갑니다.')
            st.caption(understanding.get('error',''))
        if busy and understanding.get('status')=='pending':
            st.caption(f"컬럼 설명 {len(understanding.get('completed_columns',[]))} / {len(state['schema'])}개 작성")
        rows=[{'컬럼':c['name'],'역할':{'numeric':'수치형','categorical':'범주형','datetime':'날짜','text':'텍스트','id':'식별자'}.get(c['role'],c['role']),
               '의미':polite_analysis_text(c.get('description','')) if c.get('description') else '설명 작성 전'} for c in state['schema']]
        uses=context.get('analysis_uses',[])
        if uses:
            chips=''.join(f'<span class="use-chip">{html.escape(polite_analysis_text(use))}</span>' for use in uses)
            st.markdown(f'<div class="use-row"><span class="use-label">분석에 활용할 수 있어요</span>{chips}</div>',unsafe_allow_html=True)
        with st.expander(f'컬럼 {len(rows)}개 보기'):
            st.dataframe(pd.DataFrame(rows),hide_index=True,use_container_width=True,height=min(38+len(rows)*36,470),
                         column_config={'의미':st.column_config.TextColumn(width='large'),'컬럼':st.column_config.TextColumn(width='medium')})
            st.caption('상세 설명과 분포는 아래의 변수별 진단에서 확인할 수 있습니다.')
        st.caption('전체 행의 통계와 대표 값, 제공된 설명을 바탕으로 작성한 초안입니다. 아래 대화에서 내용을 보완할 수 있습니다.')
        if service and (understanding.get('status')!='completed' or not uses):
            if st.button('데이터 설명 이어서 작성' if understanding else '데이터 설명·활용 방안 작성',disabled=busy):
                action(service.summarize,state)


STAT_NAMES={
    'n':'수치 계산 대상','mean':'평균','std':'표준편차','min':'최솟값','q1':'1사분위수',
    'median':'중앙값','q3':'3사분위수','max':'최댓값','skew':'왜도','kurtosis':'첨도',
    'negative':'음수','iqr_candidates':'IQR 극단값 후보','z_candidates':'Z-score 극단값 후보',
    'parse_failures':'형식 해석 실패','nonfinite':'무한값','iqr_lower':'IQR 하한','iqr_upper':'IQR 상한',
    'mode':'최빈값','mode_count':'최빈값 건수','unique_ratio':'고유값 비율',
    'rare_categories':'희소 범주 수','rare_rows':'희소 범주 건수',
    'length_min':'최소 문자열 길이','length_max':'최대 문자열 길이','length_mean':'평균 문자열 길이',
    'parsed':'날짜 해석 성공','start':'시작일','end':'종료일','future':'미래 날짜','ambiguous_dates':'일·월 순서 확인 필요',
    'typical_interval_seconds':'관측 간격 중앙값(초)','gap_candidates':'긴 시간 간격 후보',
    'max_interval_seconds':'최대 관측 간격(초)','whitespace_only':'공백만 있는 값',
    'outer_whitespace':'앞뒤 공백이 있는 값','leading_zero':'선행 0이 있는 값',
    'duplicate_extra':'중복으로 추가된 값','duplicate_participants':'중복에 해당하는 값',
}


def chart_style(fig):
    fig.update_layout(height=285,margin=dict(t=16,b=35,l=12,r=16),paper_bgcolor='rgba(0,0,0,0)',plot_bgcolor='rgba(0,0,0,0)',font=dict(family='Noto Sans KR, Malgun Gothic',size=13,color='#4e5968'),showlegend=False,hoverlabel=dict(bgcolor='white',font_size=13))
    fig.update_yaxes(gridcolor='#f2f4f6',zerolinecolor='#e5e8eb')
    fig.update_xaxes(zerolinecolor='#e5e8eb')
    return fig


ISSUE_LABELS={
    'missing':'결측','outlier':'극단값·범위','rare':'희소 범주','format':'자료형·형식',
    'duplicate':'중복','relation':'변수 관계','context':'분석 맥락',
}
ISSUE_KIND_MAP={
    'missing':'missing','grouped_missing':'missing','co_missing':'missing',
    'outlier_candidate':'outlier','negative_values':'outlier','rule_check':'outlier','date_order':'outlier',
    'parse_failure':'format','ambiguous_date':'format','category_variants':'format','headers':'format','invalid_definition':'format',
    'duplicate_rows':'duplicate','key_duplicates':'duplicate','identical_columns':'duplicate',
    'correlation':'relation','relation_residual':'relation','time_profile':'relation',
}
PRIORITY_LABELS={'high':'먼저 확인','medium':'확인 권장','low':'참고'}
PRIORITY_RANK={'high':0,'medium':1,'low':2}


def confirmed_target_ids(state):
    """Return only targets explicitly recorded from user or metadata decisions."""
    known={column['id'] for column in state.get('schema',[])}
    targets={cid for cid in state.get('context',{}).get('target_column_ids',[]) if cid in known}
    keywords=('타깃','목표 변수','예측 대상','종속 변수','분류 대상')
    for decision in state.get('context',{}).get('decisions',[]):
        if not isinstance(decision,dict) or decision.get('basis') not in {'user','metadata'}:continue
        if any(keyword in str(decision.get('summary','')) for keyword in keywords):
            targets.update(cid for cid in decision.get('columns',[]) if cid in known)
    return targets


def build_review_rows(state):
    """Build a compact, deterministic variable review index from saved evidence."""
    profile=state.get('profile') or {};columns=profile.get('columns') or []
    targets=confirmed_target_ids(state)
    rows={column['id']:{
        'id':column['id'],'name':column.get('name') or '이름 없는 컬럼','role':column.get('role',''),
        'issues':set(),'notes':[],'priority':'low','order':index,'target':column['id'] in targets,
    } for index,column in enumerate(columns)}
    for column in columns:
        row=rows[column['id']];stats=column.get('stats') or {}
        if column.get('missing'):
            row['issues'].add('missing');row['notes'].append(f"결측 {int(column['missing']):,}건")
            row['priority']='high' if row['target'] or column.get('role')=='id' else 'medium'
        if stats.get('iqr_candidates'):
            row['issues'].add('outlier');row['notes'].append(f"극단값 후보 {int(stats['iqr_candidates']):,}건")
            if row['priority']=='low':row['priority']='medium'
        if stats.get('rare_categories'):
            row['issues'].add('rare');row['notes'].append(f"희소 범주 {int(stats['rare_categories']):,}개")
            if row['target']:row['priority']='high'
        if stats.get('parse_failures'):
            row['issues'].add('format');row['notes'].append(f"형식 확인 {int(stats['parse_failures']):,}건")
            row['priority']='high'
    for evidence in profile.get('evidence',[]):
        kind=evidence.get('kind');issue=ISSUE_KIND_MAP.get(kind)
        if not issue:continue
        if kind=='headers':continue
        if kind not in {'correlation','time_profile'} and evidence.get('count') in {0,None} and not evidence.get('row_ids'):continue
        evidence_columns=evidence.get('columns',[])
        if kind=='grouped_missing':
            groups=set((evidence.get('details') or {}).get('group_by',[]))
            evidence_columns=[cid for cid in evidence_columns if cid not in groups][:1]
        for cid in evidence_columns:
            if cid in rows:
                rows[cid]['issues'].add(issue)
                note=ISSUE_LABELS[issue]+' 확인'
                keyword={'outlier':'극단값','format':'형식','relation':'관계'}.get(issue,ISSUE_LABELS[issue])
                if not any(keyword in existing for existing in rows[cid]['notes']):rows[cid]['notes'].append(note)
                if issue in {'format','duplicate'} and rows[cid]['priority']=='low':rows[cid]['priority']='medium'
    for finding in state.get('analysis',{}).get('findings',[]):
        if not isinstance(finding,dict):continue
        priority=finding.get('priority','medium')
        for cid in finding.get('columns',[]):
            if cid not in rows:continue
            rows[cid]['issues'].add('context')
            if PRIORITY_RANK.get(priority,1)<PRIORITY_RANK.get(rows[cid]['priority'],2):rows[cid]['priority']=priority
            if '분석 맥락 확인' not in rows[cid]['notes']:rows[cid]['notes'].append('분석 맥락 확인')
    return list(rows.values()),targets


def review_index(state,columns):
    rows,targets=build_review_rows(state);key=state['id']
    st.markdown('<div class="review-heading"><strong>확인이 필요한 변수</strong><span>분석에 영향을 줄 수 있는 항목만 먼저 모았습니다.</span></div>',unsafe_allow_html=True)
    counts={issue:sum(issue in row['issues'] for row in rows) for issue in ISSUE_LABELS}
    missing_cells=sum(int(column.get('missing') or 0) for column in columns)
    outlier_values=sum(int((column.get('stats') or {}).get('iqr_candidates') or 0) for column in columns)
    rare_values=sum(int((column.get('stats') or {}).get('rare_categories') or 0) for column in columns)
    parse_values=sum(int((column.get('stats') or {}).get('parse_failures') or 0) for column in columns)
    relation_count=len({r['id'] for r in rows if r['issues']&{'duplicate','relation'}})
    card_candidates=[
        ('missing',counts['missing'],f"결측값 확인\n{counts['missing']:,}개 변수 · {missing_cells:,}건"),
        ('outlier',counts['outlier'],f"극단값 후보\n{counts['outlier']:,}개 변수 · {outlier_values:,}건"),
        ('rare',counts['rare'],f"희소 범주 후보\n{counts['rare']:,}개 변수 · {rare_values:,}개 범주"),
        ('format',counts['format'],f"자료형·형식 확인\n{counts['format']:,}개 변수 · {parse_values:,}건"),
        ('duplicate',relation_count,f"중복·관계 확인\n{relation_count:,}개 변수"),
    ]
    cards=[(issue,label) for issue,count,label in card_candidates if count>0]
    active_key='review_issue_'+key
    if st.session_state.get(active_key) not in {issue for issue,_ in cards}:st.session_state[active_key]=None
    with st.container():
        if cards:
            card_columns=st.columns(len(cards),gap='small')
            for slot,(issue,label) in zip(card_columns,cards):
                if slot.button(label,key='card_'+key+'_'+issue,use_container_width=True):
                    st.session_state[active_key]=None if st.session_state.get(active_key)==issue else issue
                    st.rerun()
        else:st.success('현재 기준에서 우선 확인할 변수는 발견되지 않았습니다.')
    search_col,type_col,sort_col,target_col=st.columns([1.4,1,1,1],gap='small')
    with search_col:query=st.text_input('변수 검색',placeholder='변수명을 입력하세요',key='review_search_'+key)
    with type_col:
        role=st.selectbox('변수 유형',['전체','수치형','범주형','날짜','텍스트·ID'],key='review_role_'+key)
    with sort_col:
        order=st.selectbox('정렬',['우선순위','원래 순서','변수명'],key='review_order_'+key)
    with target_col:
        target_only=st.checkbox('타깃 관련 변수만',key='review_target_'+key,disabled=not targets,help='사용자나 메타데이터로 타깃이 확인된 경우에만 사용할 수 있습니다.')
    show_all=st.toggle('모든 변수 보기',value=False,key='review_all_'+key,help='끄면 확인이 필요한 변수만 표시합니다.')
    role_key={'수치형':'numeric','범주형':'categorical','날짜':'datetime','텍스트·ID':'text_id'}.get(role)
    active=st.session_state.get(active_key)
    filtered=[]
    for row in rows:
        if query and query.casefold() not in row['name'].casefold():continue
        if role_key and not (row['role']==role_key or role_key=='text_id' and row['role'] in {'text','id'}):continue
        if not show_all and not row['issues']:continue
        if active=='duplicate' and not row['issues']&{'duplicate','relation'}:continue
        if active and active!='duplicate' and active not in row['issues']:continue
        if target_only and not row['target']:continue
        filtered.append(row)
    if order=='우선순위':filtered.sort(key=lambda row:(PRIORITY_RANK.get(row['priority'],2),row['order']))
    elif order=='변수명':filtered.sort(key=lambda row:row['name'].casefold())
    else:filtered.sort(key=lambda row:row['order'])
    if not targets:st.caption('확정된 타깃이 없어 타깃 필터는 비활성화했습니다.')
    if not filtered:
        st.info('현재 조건에 맞는 변수가 없습니다. 검색어나 필터를 바꿔 보세요.')
        return []
    role_names={'numeric':'수치형','categorical':'범주형','datetime':'날짜','text':'텍스트','id':'식별자'}
    table=pd.DataFrame([{
        '변수':row['name'],'역할':role_names.get(row['role'],'미정'),
        '주요 확인 사항':' · '.join(row['notes'][:2]) if row['notes'] else '추가 확인 사항 없음',
        '우선순위':PRIORITY_LABELS.get(row['priority'],'확인 권장'),
    } for row in filtered])
    event=st.dataframe(table,hide_index=True,use_container_width=True,height=min(42+len(table)*35,330),
        on_select='rerun',selection_mode='single-row',key='review_table_'+key,
        column_config={'변수':st.column_config.TextColumn(width='medium'),'주요 확인 사항':st.column_config.TextColumn(width='large')})
    selection=getattr(event,'selection',None);selected_rows=getattr(selection,'rows',[]) if selection else []
    if selected_rows:
        st.session_state['review_detail_'+key]=filtered[selected_rows[0]]['id']
    return [row['id'] for row in filtered]


def profiles(state):
    with st.container(border=True):
        section(3,'변수별 진단')
        columns=state['profile'].get('columns',[])
        if not columns:return
        review_ids=review_index(state,columns)
        if not review_ids:return
        def formatted(value,percent=False):
            if value is None:return '계산 불가'
            if isinstance(value,bool):return '예' if value else '아니요'
            if isinstance(value,(int,float)):
                return f'{value:.1%}' if percent else f'{value:,.5g}' if isinstance(value,float) else f'{value:,}'
            return str(value)
        filtered=[c for c in columns if c['id'] in review_ids]
        counts={c['name']:sum(other['name']==c['name'] for other in columns) for c in columns}
        positions={c['id']:i+1 for i,c in enumerate(state['schema'])}
        def column_label(c):
            label=c['name'] or '이름 없는 컬럼'
            return f"{label} ({positions.get(c['id'],'?')}번째 열)" if counts.get(c['name'],0)>1 or not c['name'] else label
        detail_key='review_detail_'+state['id']
        if st.session_state.get(detail_key) not in review_ids:st.session_state[detail_key]=review_ids[0]
        cid=st.selectbox('상세히 볼 변수',review_ids,format_func=lambda value:column_label(next(item for item in columns if item['id']==value)),key=detail_key)
        c=next(item for item in columns if item['id']==cid)
        role_label={'numeric':'수치형','categorical':'범주형','datetime':'날짜','text':'텍스트','id':'식별자'}.get(c.get('role'),'미정')
        dtype_label={'object':'문자열·혼합','string':'문자열'}.get(c.get('dtype'),c.get('dtype','미정'))
        st.caption(f"{role_label} · 저장 자료형: {dtype_label}"+(f" · 단위: {c['unit']}" if c.get('unit') else ''))
        if c.get('description'):st.write(polite_analysis_text(c['description']))
        metrics=st.columns(4)
        for m,label,key in zip(metrics,['비결측값','결측값','결측률','고유값'],['valid','missing','missing_rate','unique']):
            m.metric(label,formatted(c.get(key),percent=key=='missing_rate'))
        stats=c.get('stats') or {}
        if not c.get('valid'):
            st.info('비결측값이 없어 분포를 계산하지 않았습니다.')
        elif stats.get('parse_failures'):
            st.caption(f"비결측값 중 {stats['parse_failures']:,}건은 지정한 형식으로 해석되지 않아 해당 분포 계산에서 제외했습니다.")
        hist=c.get('histogram');freq=c.get('frequency')
        if hist:
            data=pd.DataFrame(hist)
            unit=f" ({c['unit']})" if c.get('unit') else ''
            fig=go.Figure(go.Bar(x=(data['lower']+data['upper'])/2,y=data['count'],width=(data['upper']-data['lower'])*.94,marker_color='#3182f6',customdata=data[['lower','upper']],hovertemplate='%{customdata[0]:.4g} ~ %{customdata[1]:.4g}<br>%{y:,}건<extra></extra>'))
            fig.update_layout(xaxis_title=c['name']+unit,yaxis_title='건수')
            st.plotly_chart(chart_style(fig),use_container_width=True,key='hist_'+c['id'])
            box=c.get('boxplot',{})
            if box:
                fig=go.Figure(go.Box(q1=[box['q1']],median=[box['median']],q3=[box['q3']],lowerfence=[box['whisker_low']],upperfence=[box['whisker_high']],orientation='h',name=c['name'],marker_color='#3182f6',boxpoints=False))
                fig.update_layout(xaxis_title=c['name']+unit)
                fig=chart_style(fig);fig.update_layout(height=150)
                st.plotly_chart(fig,use_container_width=True,key='box_'+c['id'])
                st.caption(f"상자: 1~3사분위수 · 중앙선: 중앙값 · 수염: IQR 경계 안의 최솟값·최댓값. 극단값 후보 {box['outlier_count']:,}개의 개별 점은 생략했습니다.")
        if freq:
            data=pd.DataFrame(freq if isinstance(freq,list) else [])
            if not data.empty:
                fig=px.bar(data,x='value',y='count',labels={'value':c['name'],'count':'건수'},color_discrete_sequence=['#3182f6'])
                fig.update_xaxes(type='category')
                st.plotly_chart(chart_style(fig),use_container_width=True,key='freq_'+c['id'])
                chart=c.get('chart',{})
                if chart.get('hidden_categories'):
                    st.caption(f"빈도 상위 {len(data):,}개 범주 표시 · 나머지 {chart['hidden_categories']:,}개 범주, {chart.get('hidden_valid',0):,}건은 그래프에서 생략했습니다.")
                if chart.get('labels_truncated'):
                    st.caption('긴 값은 앞 200자만 표시합니다. 원본 값과 빈도 계산은 그대로 보존됩니다.')
                table=pd.DataFrame({'값':data['value'],'건수':data['count'],'비결측값 내 비율':data['rate_valid'].map(lambda x:f'{x:.1%}'),'전체 행 대비 비율':data['rate_all'].map(lambda x:f'{x:.1%}')})
                with st.expander('빈도표'):st.dataframe(table,hide_index=True,use_container_width=True)
        rare_frequency=c.get('rare_frequency') or []
        if stats.get('rare_categories'):
            st.markdown('**희소 범주**')
            st.caption(f"비결측값의 1% 미만인 범주가 {stats['rare_categories']:,}개이며, 모두 {stats.get('rare_rows',0):,}건입니다. 드문 값이라는 이유만으로 기타 범주로 합치지 않습니다.")
            if rare_frequency:
                rare_table=pd.DataFrame({
                    '값':[item['value'] for item in rare_frequency],
                    '건수':[item['count'] for item in rare_frequency],
                    '비결측값 내 비율':[f"{item['rate_valid']:.2%}" for item in rare_frequency],
                    '전체 행 대비 비율':[f"{item['rate_all']:.2%}" for item in rare_frequency],
                })
                st.dataframe(rare_table,hide_index=True,use_container_width=True,height=min(38+len(rare_table)*36,290))
                if stats['rare_categories']>len(rare_frequency):
                    st.caption(f"희소 범주 중 빈도가 높은 {len(rare_frequency):,}개를 표시했습니다. 나머지 {stats['rare_categories']-len(rare_frequency):,}개도 계산에는 포함됩니다.")
            elif stats.get('rare_examples'):
                st.write(' · '.join(str(value) for value in stats['rare_examples']))
                st.caption('이전 계산 결과에 저장된 값 예시입니다. 새로 점검하면 범주별 건수와 비율도 함께 표시됩니다.')
        if c.get('date_counts'):
            data=pd.DataFrame(c['date_counts'])
            period_label={'D':'일별','W':'주별','M':'월별'}.get(c.get('chart',{}).get('period'),'기간별')
            st.plotly_chart(chart_style(px.bar(data,x='period',y='count',labels={'period':period_label+' 기간','count':'건수'},color_discrete_sequence=['#597df3'])),use_container_width=True,key='date_'+c['id'])
            if c.get('chart',{}).get('hidden_periods'):
                st.caption(f"앞 500개 기간 표시 · 이후 {c['chart']['hidden_periods']:,}개 기간, {c['chart'].get('hidden_valid',0):,}건은 생략했습니다.")
        chart=c.get('chart',{})
        if chart:
            basis='표본 기준' if chart.get('sampled') else '전체 데이터 기준'
            st.caption(f"{basis} · {chart.get('rows',c.get('rows',0)):,}행 중 {chart.get('included',c.get('valid',0)):,}건으로 계산 · 결측 {chart.get('excluded_missing',0):,}건, 형식 오류·무한값 {chart.get('excluded_invalid',0):,}건 제외")
        if stats:
            stats_rows=[{'항목':STAT_NAMES[k],'값':formatted(v,percent=k=='unique_ratio')} for k,v in stats.items() if k in STAT_NAMES]
            with st.expander('요약 통계',expanded=False):
                st.dataframe(pd.DataFrame(stats_rows),hide_index=True,use_container_width=True)
                if c.get('role')=='numeric':
                    st.caption('표준편차: 표본 기준(ddof=1) · 분위수: 선형 보간 · 첨도: 정규분포=0 기준 · IQR: 1.5배 · Z-score: 절댓값 3 초과')
                    st.caption('극단값 후보와 음수는 오류 판정이 아닙니다. 변수의 의미와 분포를 함께 확인하세요.')
                elif c.get('role')=='datetime':
                    st.caption('날짜는 UTC로 비교합니다. 미래 날짜·긴 관측 간격은 수집 방식과 변수 의미에 따라 정상일 수 있습니다.')
                else:
                    st.caption('고유값 비율과 희소 범주는 비결측값 기준입니다. 희소 범주 기준은 1% 미만이며 자동 통합하지 않습니다.')
                if c.get('patterns'):
                    st.dataframe(pd.DataFrame(c['patterns']).rename(columns={'pattern':'표기 형식','count':'건수'}),hide_index=True,use_container_width=True)
        evidence=[e for e in state['profile'].get('evidence',[]) if c['id'] in e.get('columns',[]) and e.get('kind') not in ('overview','column_profile')]
        if evidence:
            with st.expander(f'점검 근거 {len(evidence)}건'):
                for e in evidence:
                    st.write(e.get('summary',e.get('kind','')))
                    if e.get('sampled'):st.caption(f"표본 {e.get('details',{}).get('examined_rows',0):,}행에서 확인한 결과입니다.")
                    if e.get('row_ids'):
                        if st.button('해당 행 보기',key='rows_'+e['id']):
                            try:
                                frame=read_frame(state);ids=e['row_ids'][:30]
                                related=[key for key in e.get('columns',[]) if key in frame.columns][:12]
                                if c['id'] not in related:related=[c['id']]+related[:11]
                                view=frame.loc[frame.index.intersection(ids),related].copy()
                                view.columns=[column_label(next(item for item in columns if item['id']==key)) for key in related]
                                view.index=view.index+1;view.index.name='원본 데이터 행'
                                st.caption('원본 데이터의 행 번호입니다(헤더 제외). 최대 30행·관련 컬럼 12개를 표시합니다.')
                                st.dataframe(view,use_container_width=True)
                            except Exception as exc:st.error(str(exc))


QUALITY_GROUPS=[
    ('결측 패턴',{'missing','grouped_missing','co_missing'}),
    ('이상치·범위',{'outlier_candidate','negative_values','rule_check','date_order'}),
    ('중복',{'duplicate_rows','key_duplicates','identical_columns'}),
    ('변수 관계',{'correlation','relation_residual','time_profile'}),
    ('형식·희소 범주',{'parse_failure','ambiguous_date','category_variants','headers','invalid_definition'}),
]


def quality_evidence_copy(item,names):
    """Turn deterministic evidence into short analyst-facing copy."""
    kind=item.get('kind','');details=item.get('details') or {}
    columns=[names.get(cid,cid) for cid in item.get('columns',[])]
    joined=', '.join(columns) or '관련 컬럼'
    count=item.get('count')
    if kind=='missing':
        rate=details.get('rate')
        body=f"{joined}에 결측값 {int(count or 0):,}건"+(f"({rate:.1%})이 있습니다." if isinstance(rate,(int,float)) else '이 있습니다.')
        return f'{joined} 결측값',body
    if kind=='grouped_missing':
        groups=details.get('groups') or []
        top=groups[0] if groups else None
        if top:
            labels=', '.join(f"{names.get(cid,cid)}={value}" for cid,value in top.get('group',{}).items())
            overall=details.get('overall_missing_rate')
            comparison=f" 전체 결측률은 {overall:.1%}입니다." if isinstance(overall,(int,float)) else ''
            return f'{columns[0] if columns else joined}의 집단별 결측',f"{labels}에서 결측률이 {top.get('rate',0):.1%}({top.get('missing',0):,}/{top.get('rows',0):,}건)로 가장 높습니다.{comparison}"
        return f'{joined}의 집단별 결측','집단별 결측률을 비교했지만 표시할 집단이 없습니다.'
    if kind=='co_missing':
        pairs=[pair for pair in details.get('pairs',[]) if pair.get('both_missing')]
        if pairs:
            top=pairs[0];pair_names=[names.get(cid,cid) for cid in top['columns']]
            return '함께 발생한 결측',f"{pair_names[0]}와 {pair_names[1]}가 함께 결측인 행이 {top['both_missing']:,}건입니다. 함께 비는 컬럼 조합은 수집 과정이나 적용 대상의 차이를 확인할 단서입니다."
        return '함께 발생한 결측','검사한 컬럼 조합에서는 동시에 결측인 행이 확인되지 않았습니다.'
    if kind=='outlier_candidate':
        lower,upper=details.get('lower'),details.get('upper')
        bounds=f" 기준 범위는 {lower:,.4g}~{upper:,.4g}입니다." if isinstance(lower,(int,float)) and isinstance(upper,(int,float)) else ''
        return f'{joined}의 극단값 후보',f"IQR 기준으로 {int(count or 0):,}건을 확인했습니다.{bounds} 통계적으로 드문 값이며 오류로 확정한 결과는 아닙니다."
    if kind=='negative_values':
        return f'{joined}의 음수',f"음수 {int(count or 0):,}건이 있습니다. 환불·변환값처럼 정상적인 의미일 수 있어 변수 정의와 함께 판단해야 합니다."
    if kind=='rule_check':
        return f'{joined}의 허용 범위',f"사용자가 지정한 허용 기준을 벗어난 값이 {int(count or 0):,}건입니다."
    if kind=='date_order':
        return f'{joined}의 날짜 순서',f"종료일이 시작일보다 빠른 행이 {int(count or 0):,}건입니다. 두 컬럼이 실제 시작·종료 시점을 뜻하는지 먼저 확인해야 합니다."
    if kind=='duplicate_rows':
        participants=details.get('participants',0)
        return '완전히 같은 행',f"앞선 행과 모든 값이 같은 행이 {int(count or 0):,}건이며, 관련된 전체 행은 {participants:,}건입니다. 반복 관측인지 중복 입력인지 확인한 뒤 처리합니다."
    if kind=='key_duplicates':
        return f'{joined}의 키 중복',f"결측이 없는 키를 기준으로 중복으로 추가된 행이 {details.get('extra_rows',int(count or 0)):,}건입니다. 같은 대상의 반복 기록일 수 있어 관측 단위를 함께 확인해야 합니다."
    if kind=='identical_columns':
        return f'{joined}의 값 일치',f"전체 행과 자료형이 같은 컬럼 {len(columns):,}개입니다. 값이 같아도 업무 의미가 다를 수 있으므로 자동으로 삭제하지 않습니다."
    if kind=='correlation':
        pearson=details.get('pearson');spearman=details.get('spearman');pairs=details.get('complete_pairs',0)
        values=[]
        if isinstance(pearson,(int,float)):values.append(f'피어슨 {pearson:.3f}')
        if isinstance(spearman,(int,float)):values.append(f'스피어만 {spearman:.3f}')
        measured=', '.join(values) if values else '상관계수 계산 불가'
        return f'{joined}의 관계',f"비결측 쌍 {pairs:,}건에서 {measured}로 계산됐습니다. 함께 움직이는 정도이며 인과관계를 뜻하지 않습니다."
    if kind=='relation_residual':
        suitable=details.get('suitable')
        if suitable:
            return f'{joined}의 관계 이탈 후보',f"두 변수의 일반적인 선형 관계에서 크게 벗어난 행이 {int(count or 0):,}건입니다. 집단 차이와 비선형 관계를 함께 확인해야 합니다."
        return f'{joined}의 관계 이탈 검사','두 변수의 선형 관계가 약해 잔차 기준의 이상치 판정을 적용하지 않았습니다.'
    if kind=='time_profile':
        periods=details.get('periods') or []
        return f'{joined}의 기간별 변화',f"{len(periods):,}개 기간의 건수와 분포를 비교했습니다. 변화의 원인이 실제 현상인지 수집 방식인지 추가 맥락과 함께 판단합니다."
    if kind=='parse_failure':
        return f'{joined}의 형식 확인',f"결측값이 아닌 값 중 {int(count or 0):,}건을 현재 지정된 자료형으로 읽지 못했습니다. 원래 표기를 확인한 뒤 변환 여부를 정합니다."
    if kind=='ambiguous_date':
        return f'{joined}의 날짜 표기',f"일·월 순서에 따라 해석이 달라질 수 있는 값이 {int(count or 0):,}건입니다."
    if kind=='category_variants':
        return f'{joined}의 표기 차이',f"앞뒤 공백·연속 공백·영문 대소문자만 다른 후보가 {int(count or 0):,}개입니다. 같은 의미인지 확인하기 전에는 합치지 않습니다."
    return joined,polite_analysis_text(item.get('summary') or kind)


def quality_patterns(state):
    """Show where each quality and multivariate result lives without rerunning analysis."""
    profile=state.get('profile') or {};evidence=profile.get('evidence') or []
    names={column['id']:column.get('name') or column['id'] for column in state.get('schema',[])}
    columns=profile.get('columns') or []
    with st.container(border=True):
        section(4,'품질 패턴')
        st.markdown('<div class="section-subtitle">위에서 고른 변수를 기준으로 결측·이상치·중복과 변수 간 관계의 계산 근거를 확인할 수 있습니다.</div>',unsafe_allow_html=True)
        tabs=st.tabs([label for label,_ in QUALITY_GROUPS])
        for tab,(label,kinds) in zip(tabs,QUALITY_GROUPS):
            with tab:
                items=[item for item in evidence if item.get('kind') in kinds]
                if label=='형식·희소 범주':
                    for column in columns:
                        stats=column.get('stats') or {}
                        if stats.get('rare_categories'):
                            items.append({'id':'rare_'+column['id'],'kind':'rare_category','columns':[column['id']],
                                          'count':stats.get('rare_rows',0),'details':stats})
                if not items:
                    st.caption('현재 자동 점검에서 해당 패턴이 확인되지 않았습니다.')
                    continue
                for item in items:
                    if item.get('kind')=='rare_category':
                        column_name=names.get(item['columns'][0],item['columns'][0]);details=item['details']
                        title=f'{column_name}의 희소 범주'
                        body=f"비결측값의 1% 미만인 범주가 {details.get('rare_categories',0):,}개이며, 모두 {details.get('rare_rows',0):,}건입니다. 값과 비율은 위의 변수별 진단에서 확인할 수 있습니다."
                    else:
                        title,body=quality_evidence_copy(item,names)
                    sample=' · 표본 계산' if item.get('sampled') else ''
                    st.markdown(f'<div class="pattern-row"><strong>{html.escape(str(title))}</strong><p>{html.escape(str(body))}</p><span>{html.escape(sample.lstrip(" ·"))}</span></div>',unsafe_allow_html=True)
                    if item.get('row_ids'):
                        if st.button('문제 행 보기',key='quality_rows_'+str(item.get('id'))):
                            try:
                                frame=read_frame(state);ids=item['row_ids'][:30]
                                related=[cid for cid in item.get('columns',[]) if cid in frame.columns][:12]
                                view=frame.loc[frame.index.intersection(ids),related].copy()
                                view.columns=[names.get(cid,cid) for cid in related]
                                view.index=view.index+1;view.index.name='원본 데이터 행'
                                st.dataframe(view,use_container_width=True)
                            except Exception as exc:st.error(str(exc))
        deep=profile.get('deep') or {}
        if deep.get('performed'):
            scope=deep.get('scope') or '현재 데이터의 변수 유형과 분석 목적을 기준으로 후보를 골라 검사했습니다.'
            sample=' 일부 검사는 최대 50,000행의 고정 표본으로 계산했습니다.' if deep.get('sampled') else ' 모든 자동 검사는 전체 행을 기준으로 계산했습니다.'
            st.caption(f"자동 검사 {len(deep.get('checks') or []):,}개 · {scope}.{sample}")


def polite_analysis_text(value):
    """Make stored report prose comfortable to read without changing its meaning."""
    text=str(value or '').strip()
    replacements=[
        ('완료된 행 검사의 생략된 원문과 실패 위치를 확인할 때까지','원래 값과 문제가 발생한 행을 확인할 때까지'),
        ('발생했다고 볼 수는 없다.','발생했다고 단정하기는 어렵습니다.'),
        ('이 검사로 알 수 없다.','현재 검사만으로는 알기 어렵습니다.'),
        ('집계 기준 확인 없이 자동 합산해 채우지 않는다.','집계 기준을 확인하기 전에는 자동으로 합산해 채우지 않는 편이 좋습니다.'),
        ('errors=coerce로 결측값을 늘리지 않고','읽히지 않는 값을 자동으로 결측값으로 바꾸지 않고'),
        ('errors=raise 변환안만 유지한다.','모든 값이 정상적으로 읽히는 컬럼만 변환 후보로 남겨두는 편이 좋습니다.'),
        ('errors=coerce','읽히지 않는 값을 결측값으로 바꾸는 방식'),
        ('errors=raise','변환 실패 시 중단하는 방식'),
        ('numeric 형식으로 해석되지 않는 값','숫자로 읽히지 않는 값'),
        ('numeric으로 보완됐지만','숫자형으로 분류했지만'),
        ('실제 자료형은 object이고','현재 저장 형식은 문자열이며'),
        ('숫자 해석 실패','숫자로 읽히지 않는 값'),
        ('해당 컬럼의 변환을 보류한다.','해당 컬럼은 원래 값을 확인한 뒤 변환하는 편이 안전합니다.'),
        ('자동 합산해 채우지 않는다.','확인 전에는 자동으로 합산해 채우지 않는 편이 좋습니다.'),
        ('확정할 수 없다.','현재 정보만으로는 확정하기 어렵습니다.'),
        ('알 수 없다.','현재 정보만으로는 알기 어렵습니다.'),
    ]
    for old,new in replacements:text=text.replace(old,new)
    cleanups=[
        ('이 검사로 현재 정보만으로는','현재 검사만으로는'),
        ('발생했다고 같다고 단정하기는 어렵습니다.','발생했다고 단정하기는 어렵습니다.'),
        ('집계 기준 확인 없이 확인 전에는','집계 기준을 확인하기 전에는'),
        ('기존에 해석 가능한 것으로 검토된 컬럼의 모든 값이 정상적으로 읽히는 컬럼만','모든 값이 정상적으로 읽히는 컬럼만'),
        ('변환 실패 시 중단하는 방식 변환안만','변환 실패 시 중단하는 방식만'),
        ('원래 값과 문제가 발생한 행을 확인할 때까지 해당 컬럼은 원래 값을 확인한 뒤 변환하는 편이 안전합니다.','원래 값과 문제가 발생한 행을 확인한 뒤 해당 컬럼을 변환하는 편이 안전합니다.'),
    ]
    for old,new in cleanups:text=text.replace(old,new)
    # Older saved summaries used terse report endings. Keep their meaning while
    # presenting the same polite tone as the current interface.
    polite_endings=[
        (r'명시되지 않았다(?=[.!?]|$)','명시되지 않았습니다'),
        (r'확인되지 않았다(?=[.!?]|$)','확인되지 않았습니다'),
        (r'포함되지 않았다(?=[.!?]|$)','포함되지 않았습니다'),
        (r'추정된다(?=[.!?]|$)','추정됩니다'),
        (r'판단된다(?=[.!?]|$)','판단됩니다'),
        (r'보인다(?=[.!?]|$)','보입니다'),
        (r'활용할 수 있다(?=[.!?]|$)','활용할 수 있습니다'),
        (r'확인할 수 있다(?=[.!?]|$)','확인할 수 있습니다'),
        (r'알 수 있다(?=[.!?]|$)','알 수 있습니다'),
        (r'있다(?=[.!?]|$)','있습니다'),
        (r'없다(?=[.!?]|$)','없습니다'),
        (r'필요하다(?=[.!?]|$)','필요합니다'),
        (r'가능하다(?=[.!?]|$)','가능합니다'),
        (r'어렵다(?=[.!?]|$)','어렵습니다'),
        (r'중요하다(?=[.!?]|$)','중요합니다'),
        (r'나타낸다(?=[.!?]|$)','나타냅니다'),
        (r'의미한다(?=[.!?]|$)','의미합니다'),
        (r'사용한다(?=[.!?]|$)','사용합니다'),
        (r'기록한다(?=[.!?]|$)','기록합니다'),
        (r'포함한다(?=[.!?]|$)','포함합니다'),
        (r'유지한다(?=[.!?]|$)','유지합니다'),
        (r'확인한다(?=[.!?]|$)','확인합니다'),
        (r'해당한다(?=[.!?]|$)','해당합니다'),
        (r'이다(?=[.!?]|$)','입니다'),
        (r'데이터다(?=[.!?]|$)','데이터입니다'),
    ]
    for pattern,replacement in polite_endings:text=re.sub(pattern,replacement,text)
    return text


def friendly_issue_title(value):
    text=str(value or '점검 결과')
    for old,new in [
        ('숫자 해석 실패','숫자로 읽히지 않는 값'),
        ('형식 해석 실패','형식이 맞지 않는 값'),
        ('단위 미확정','단위 확인 필요'),
        ('실제 자료형','현재 저장 형식'),
    ]:text=text.replace(old,new)
    return text


def friendly_fact(value):
    """Summarize repetitive machine evidence; the full evidence stays available below."""
    raw=str(value or '').strip()
    parse_matches=re.findall(r'([^.:]+):\s*(?:numeric|integer) 형식으로 해석되지 않는 값\s*([\d,]+)건\.?',raw)
    if parse_matches:
        names=[name.strip() for name,_ in parse_matches if name.strip()]
        counts=[int(count.replace(',','')) for _,count in parse_matches]
        shown=', '.join(names[:3])
        if len(names)>3:shown+=f' 등 {len(names)}개 컬럼'
        elif len(names)==1:shown+=' 컬럼'
        else:shown+=' 컬럼'
        if counts and len(set(counts))==1:
            return f'{shown}에서 숫자로 읽히지 않는 값이 각각 {counts[0]:,}건씩 확인됐습니다.'
        return f'{shown}에서 숫자로 읽히지 않는 값이 모두 {sum(counts):,}건 확인됐습니다.'
    sentences=[]
    generic_profile=False
    for sentence in re.split(r'(?<=\.)\s+',raw):
        clean=sentence.strip()
        if not clean or clean.startswith('의 분포와 품질') or clean.startswith('의 집단별 결측률'):continue
        if '의 분포와 품질을 점검했습니다.' in clean or '의 집단별 결측률을 비교했습니다.' in clean:
            generic_profile=True
            continue
        sentences.append(clean)
    if sentences:return polite_analysis_text(' '.join(sentences))
    if generic_profile:return '관련 컬럼의 분포와 결측 패턴을 함께 확인했습니다.'
    return polite_analysis_text(raw)


def finding_html(item):
    if isinstance(item,str):
        return f'<div class="issue-row"><div class="issue-body">{html.escape(item)}</div></div>'
    title=friendly_issue_title(item.get('title') or item.get('summary') or '점검 결과')
    raw_fact=readable(item.get('fact')) if item.get('fact') else ''
    fact=friendly_fact(raw_fact)
    body=polite_analysis_text(item.get('interpretation') or item.get('description') or item.get('detail') or '')
    recommendation=polite_analysis_text(item.get('recommendation') or '')
    priority=item.get('priority','medium')
    dot='high' if priority=='high' else 'low' if priority=='low' else ''
    tag={'high':'우선 확인','medium':'확인 필요','low':'참고'}.get(priority,'확인 필요')
    detail=''
    if raw_fact and raw_fact!=fact:
        detail=f'<details><summary>계산 근거 보기</summary><p>{html.escape(raw_fact)}</p></details>'
    return ''.join([
        '<div class="issue-row">',
        f'<div class="issue-title"><span class="issue-dot {dot}"></span><strong>{html.escape(str(title))}</strong><span class="issue-tag">{tag}</span></div>',
        f'<div class="issue-block"><b>확인된 내용</b><p>{html.escape(fact)}</p></div>' if fact else '',
        f'<div class="issue-block"><b>현재 판단</b><p>{html.escape(str(body))}</p></div>' if body else '',
        f'<div class="issue-block issue-rec"><b>이렇게 진행해 보세요</b><p>{html.escape(str(recommendation))}</p></div>' if recommendation else '',
        detail,'</div>'
    ])


def findings(state):
    result=state.get('analysis',{})
    items=result.get('findings',[])
    for item in items[:3]:
        st.markdown(finding_html(item),unsafe_allow_html=True)
    if len(items)>3:
        with st.expander(f'그 밖의 점검 결과 {len(items)-3}개'):
            for item in items[3:]:st.markdown(finding_html(item),unsafe_allow_html=True)
    if not items and result.get('summary'):
        st.write(result['summary'])


OPERATIONS={'rename':'컬럼명 변경','cast':'자료형 변환','unit':'단위 변환','fill_missing':'결측값 대치','clip':'범위 제한','log':'로그 변환','drop_columns':'컬럼 제거','deduplicate':'중복 행 처리','category_map':'범주 표기 통일','missing_indicator':'결측 표시 변수','drop_rows':'조건별 행 제외','set_missing':'조건별 결측 처리','replace':'조건별 값 대체'}


def manual_rule(state):
    with st.expander('처리 규칙 직접 지정'):
        st.caption('추천을 수정하거나 명확한 처리 규칙을 직접 추가할 수 있습니다. 실제 변경 전 미리보기를 거칩니다.')
        op=st.selectbox('처리 방법',['rename','cast','unit','fill_missing','deduplicate'],format_func=OPERATIONS.get,key='manual_op_'+state['id'])
        cid=st.selectbox('대상 컬럼',[c['id'] for c in state['schema']],format_func=lambda x:next(c['name'] for c in state['schema'] if c['id']==x),key='manual_col_'+state['id'])
        dtype=st.selectbox('변환할 자료형',['numeric','integer','string','datetime'],format_func={'numeric':'숫자','integer':'정수','string':'문자열','datetime':'날짜·시간'}.get) if op=='cast' else None
        method=st.selectbox('대치 기준',['median','mode','constant'],format_func={'median':'중앙값','mode':'최빈값','constant':'직접 지정'}.get) if op=='fill_missing' else None
        with st.form('manual_rule_'+state['id']):
            params={}
            if op=='rename':params={'names':{cid:st.text_input('새 컬럼명').strip()}}
            elif op=='cast':
                params={'dtype':dtype,'errors':'raise'}
                if dtype=='datetime':
                    params['format']=st.selectbox('현재 날짜 표기',['%Y-%m-%d','%Y/%m/%d','%Y%m%d','%d/%m/%Y','%m/%d/%Y','ISO8601','mixed'],format_func={'%Y-%m-%d':'2026-09-17','%Y/%m/%d':'2026/09/17','%Y%m%d':'20260917','%d/%m/%Y':'17/09/2026 (일/월/년)','%m/%d/%Y':'09/17/2026 (월/일/년)','ISO8601':'ISO 8601 날짜·시간','mixed':'여러 형식 혼용'}.get)
                st.caption('변환할 수 없는 값이 있으면 적용을 중단합니다. 원본 값은 유지됩니다.')
            elif op=='unit':
                params={'factor':st.number_input('곱할 배율',value=1.0,format='%.6f'),'from_unit':st.text_input('현재 단위'),'to_unit':st.text_input('변환 후 단위')}
            elif op=='fill_missing':
                params={'method':method}
                if method=='constant':params['value']=st.text_input('결측값에 넣을 값')
            else:
                params={'keep':st.selectbox('같은 값이 반복될 때',['first','last'],format_func={'first':'첫 번째 행 유지','last':'마지막 행 유지'}.get),'key_missing':'keep'}
                st.caption('대상 컬럼의 값이 같은 행을 중복으로 봅니다. 해당 값이 결측인 행은 유지합니다.')
            submitted=st.form_submit_button('미리보기 규칙으로 추가')
        if submitted:
            try:
                rule=dict(id='manual_'+str(uuid.uuid4())[:8],operation=op,columns=[cid],params=params,reason='사용자가 직접 지정한 처리 규칙',evidence_ids=[],phase='deep' if state['stage']=='deep_review' else 'basic')
                st.session_state.setdefault('manual_'+state['id'],[]).append(rule)
                st.success('규칙을 추가했습니다. 아래에서 선택한 뒤 미리보기를 생성하세요.')
            except Exception as exc:st.error(str(exc))


def dialogue_panel(state,service,busy):
    analysis=state.get('analysis') or {};messages=state.get('messages') or []
    question=analysis.get('question')
    context=analysis.get('question_context') or {}
    latest_user=next((message for message in reversed(messages) if message.get('role')=='user'),None)
    decisions=analysis.get('decisions') or []
    with st.container(border=True):
        st.markdown('<div class="decision-title"><span class="decision-dot"></span>확인이 필요한 내용</div>',unsafe_allow_html=True)
        if context.get('situation'):
            st.markdown(f'<div class="dialogue-section"><b>확인한 상황</b><p>{html.escape(polite_analysis_text(context["situation"]))}</p></div>',unsafe_allow_html=True)
        if context.get('judgment') or context.get('recommendation'):
            judgment=polite_analysis_text(context.get('judgment') or context.get('recommendation'))
            st.markdown(f'<div class="dialogue-section"><b>현재 판단과 추천</b><p>{html.escape(judgment)}</p></div>',unsafe_allow_html=True)
        if latest_user:
            st.markdown(f'<div class="dialogue-answer"><b>사용자 답변</b><p>{html.escape(str(latest_user.get("content","")))}</p></div>',unsafe_allow_html=True)
            reflected=' '.join(polite_analysis_text(item.get('summary','')) for item in decisions if isinstance(item,dict) and item.get('summary'))
            if not reflected:reflected=polite_analysis_text(analysis.get('summary',''))
            if reflected:
                st.markdown(f'<div class="dialogue-section reflected"><b>답변을 반영한 판단</b><p>{html.escape(reflected)}</p></div>',unsafe_allow_html=True)
        if question:
            st.markdown(f'<div class="decision-message"><b>다음 확인</b><br>{html.escape(polite_analysis_text(question))}</div>',unsafe_allow_html=True)
            if context.get('decision_impact'):st.caption('답변에 따라 달라지는 점 · '+polite_analysis_text(context['decision_impact']))
        elif busy:
            st.info('답변을 반영해 판단과 다음 질문을 정리하고 있습니다.')
        else:
            st.caption('현재 분석에 영향을 주는 추가 질문은 없습니다.')
        if len(messages)>2:
            with st.expander('이전 대화 보기'):
                for message in messages[:-2]:
                    with st.chat_message(message['role']):st.write(message['content'])
        if state['stage']!='outputs':
            with st.form('reply_'+state['id'],clear_on_submit=True):
                answer=st.text_area('답변 또는 추가 요청',placeholder='추가 설명을 입력하세요. 모르면 “모름”이라고 답해도 됩니다.',height=88,disabled=busy,label_visibility='collapsed')
                if st.form_submit_button('답변 보내기',type='primary',disabled=busy,use_container_width=True):action(service.reply,state,answer)
            st.caption('답변은 정리된 판단으로 반영되며, 필요한 경우 이어서 질문합니다.')


def render_change_preview(state,preview):
    impact=preview.get('impact') or {};before,after=impact.get('before',{}),impact.get('after',{})
    st.markdown('<div class="change-heading"><strong>변경 전후</strong><span>선택한 규칙을 원본의 복사본에 순서대로 적용한 결과입니다.</span></div>',unsafe_allow_html=True)
    summary=st.columns(4)
    summary[0].metric('행',f"{after.get('rows',0):,}",delta=f"{after.get('rows',0)-before.get('rows',0):+,}")
    summary[1].metric('컬럼',f"{after.get('columns',0):,}",delta=f"{after.get('columns',0)-before.get('columns',0):+,}")
    summary[2].metric('결측값',f"{after.get('missing_cells',0):,}",delta=f"{after.get('missing_cells',0)-before.get('missing_cells',0):+,}",delta_color='inverse')
    summary[3].metric('값이 달라진 행',f"{impact.get('changed_rows',0):,}")
    names={column['id']:column.get('name') or column['id'] for column in state.get('schema',[])}
    for column in preview.get('schema',[]):names[column['id']]=column.get('name') or column['id']
    rules=(preview.get('manifest') or {}).get('rules') or []
    steps=impact.get('steps') or []
    def stat(value):
        return f'{value:,.4g}' if isinstance(value,(int,float)) and pd.notna(value) else '—'
    for index,step in enumerate(steps):
        rule=rules[index] if index<len(rules) else {}
        operation=OPERATIONS.get(step.get('operation'),step.get('operation','처리 규칙'))
        target=', '.join(names.get(cid,cid) for cid in rule.get('columns',[])) or '전체 행'
        changed=int(step.get('changed_rows') or 0);removed=int(step.get('removed_rows') or 0)
        with st.expander(f'{index+1}. {operation} · {target}',expanded=len(steps)<=3):
            if rule.get('reason'):st.caption(polite_analysis_text(rule['reason']))
            metrics=st.columns(4)
            metrics[0].metric('값이 달라진 행',f'{changed:,}')
            metrics[1].metric('변경된 셀',f"{int(step.get('changed_cells') or 0):,}")
            metrics[2].metric('제외된 행',f'{removed:,}')
            step_before,step_after=step.get('before',{}),step.get('after',{})
            metrics[3].metric('결측값',f"{step_after.get('missing_cells',0):,}",delta=f"{step_after.get('missing_cells',0)-step_before.get('missing_cells',0):+,}",delta_color='inverse')
            details=step.get('details') or {}
            if 'parse_failures' in details:st.caption(f"변환하지 못한 값 · {int(details['parse_failures']):,}건")
            if 'filled' in details:st.caption(f"대치한 결측값 · {int(details['filled']):,}건 · 남은 결측값 {int(details.get('unfilled',0)):,}건")
            if not changed and not removed and not step.get('added_columns') and not step.get('removed_columns') and not step.get('definitions_changed'):
                st.info('이 규칙으로 실제 값이나 컬럼 정의가 바뀌지 않았습니다.')
            comparisons=[]
            for cid in rule.get('columns',[]):
                old=(step_before.get('numeric') or {}).get(cid);new=(step_after.get('numeric') or {}).get(cid)
                if old and new:
                    comparisons.append({'변수':names.get(cid,cid),'평균':f"{stat(old.get('mean'))} → {stat(new.get('mean'))}",'중앙값':f"{stat(old.get('median'))} → {stat(new.get('median'))}",'최솟값·최댓값':f"{stat(old.get('min'))}~{stat(old.get('max'))} → {stat(new.get('min'))}~{stat(new.get('max'))}"})
            if comparisons:st.dataframe(pd.DataFrame(comparisons),hide_index=True,use_container_width=True)
            if step.get('examples'):
                examples=[]
                for item in step['examples']:
                    row=item.get('row_id');row=row+1 if isinstance(row,int) else row
                    examples.append({'원본 데이터 행':row,'변수':names.get(item.get('column'),item.get('column')),'변경 전':readable(item.get('before')),'변경 후':readable(item.get('after'))})
                st.dataframe(pd.DataFrame(examples),hide_index=True,use_container_width=True)
    if impact.get('added_columns') or impact.get('removed_columns'):
        added=', '.join(names.get(cid,cid) for cid in impact.get('added_columns',[])) or '없음'
        removed_names=', '.join(names.get(cid,cid) for cid in impact.get('removed_columns',[])) or '없음'
        st.caption(f'추가된 컬럼 · {added} / 제외된 컬럼 · {removed_names}')


def review(state,service,busy):
    phase='deep' if state['stage'] in ('deep_review','outputs') else 'basic'
    with st.container(border=True):
        heading='심층 점검 결과' if phase=='deep' else '먼저 확인할 문제'
        subtitle='분석 결과에 영향을 주는 항목만 추렸어요.' if phase=='basic' else '변수 간 관계와 처리 영향을 함께 확인합니다.'
        st.markdown(f'<div class="quality-head"><strong>{heading}</strong><span>{subtitle}</span></div>',unsafe_allow_html=True)
        findings(state)
        if state['ai_status']=='failed':
            st.warning('계산 결과는 준비됐지만 해석을 마치지 못했습니다.')
            with st.expander('오류 내용 보기'):st.write(state.get('ai_error','연결을 확인해 주세요.'))
            if st.button('해석 다시 요청',disabled=busy):action(service.retry,state)
        dialogue_panel(state,service,busy)
        if state['stage']!='outputs':
            manual_rule(state)
            rules=state.get('recipes',[])+st.session_state.get('manual_'+state['id'],[])
            if rules:
                st.markdown('<div class="rules-title">처리 후보</div>',unsafe_allow_html=True)
                names={c['id']:c['name'] for c in state['schema']}
                def rule_label(index):
                    r=rules[index]
                    return OPERATIONS.get(r['operation'],r['operation'])+' · '+', '.join(names.get(c,c) for c in r.get('columns',[]))
                chosen=st.multiselect('미리볼 규칙',list(range(len(rules))),format_func=rule_label,key='rules_'+state['id']+'_'+str(state['revision']))
                for i in chosen:
                    r=rules[i]
                    st.caption(r.get('reason',''))
                    with st.expander(rule_label(i)+' 설정'):st.json(r['params'])
                if st.button('변경 미리보기',disabled=busy or not chosen):action(service.preview,state,[rules[i] for i in chosen])
            p=state.get('preview')
            if p:
                render_change_preview(state,p)
                st.caption('현재 미리보기의 규칙과 순서가 그대로 적용됩니다. 원본은 보존됩니다.')
                if st.button('확인한 규칙 승인·적용',type='primary',disabled=busy):action(service.approve,state)
            label='현재 내용으로 심층 진단 진행' if phase=='basic' else '검토 마치고 결과 받기'
            action_note,action_button=st.columns([2.1,1],gap='medium')
            with action_note:
                st.markdown('<div class="safe-note">원본 데이터는 변경되지 않습니다. 보류한 항목은 그대로 남습니다.</div>',unsafe_allow_html=True)
            with action_button:
                if st.button(label,disabled=busy,use_container_width=True,type='primary'):action(service.advance,state)


def outputs(state,service,busy):
    with st.container(border=True):
        section(6,'결과 받기')
        with st.expander('추가 설명이나 수정 사항 반영'):
            with st.form('reopen_'+state['id'],clear_on_submit=True):
                update=st.text_area('추가로 반영할 내용',placeholder='정의가 바뀌었거나 더 확인하고 싶은 내용을 적어 주세요.',disabled=busy)
                if st.form_submit_button('내용 반영하고 검토 이어가기',disabled=busy):action(service.reply,state,update)
        title=st.text_input('노트북 제목',value=state['name']+' 데이터 점검',key='notebook_title_'+state['id'])
        if st.button('최신 결과로 산출물 생성',type='primary',disabled=busy):action(service.export,state,title)
        for artifact in state.get('artifacts',[]):
            path=registered_path(state,artifact['path'])
            st.download_button(artifact.get('label',artifact['kind']),path.read_bytes(),file_name=path.name,mime=artifact['mime'],key='download_'+artifact['kind'],use_container_width=True)


def ai_usage_summary(state):
    """Summarize recorded prompt size without presenting it as billing usage."""
    records=[]
    records.extend(item for item in state.get('understanding',{}).get('request_metrics',[]) if isinstance(item,dict))
    latest=state.get('analysis',{}).get('request_metrics')
    if isinstance(latest,dict):records.append(latest)
    chars=sum(int(item.get('input_chars') or 0) for item in records)
    if not chars:return None
    # Korean, JSON punctuation and model tokenizers vary considerably. Keep a
    # deliberately broad range instead of implying API billing precision.
    low=max(1,(chars+3)//4)
    high=max(low,(chars*6+4)//5)
    models=[]
    for item in records:
        model=item.get('model')
        if model and model not in models:models.append(str(model))
    return {'calls':sum(int(item.get('requests') or 1) for item in records),
            'chars':chars,'low':low,'high':high,'models':models}


def workspace(repo,service,pid):
    try:state=repo.load(pid)
    except Exception as exc:st.error(str(exc));return
    busy=state['status'] in ('queued','running')
    @st.fragment(run_every=1.5 if busy else None)
    def monitor():
        latest=repo.load(pid)
        if latest['status']!=state['status'] or latest['stage']!=state['stage'] or latest.get('ai_status')!=state.get('ai_status') or latest['version_id']!=state['version_id'] or latest.get('understanding')!=state.get('understanding'):
            st.rerun()
        if latest['status'] in ('queued','running'):
            progress='전체 데이터 설명과 컬럼별 의미를 작성하고 있습니다.' if latest.get('understanding',{}).get('status')=='pending' else (f"{latest['filename']}의 결측 패턴과 정제 후보를 검토하고 있습니다." if latest['stage']=='basic_review' else '데이터를 점검하고 있습니다. 결과가 준비되면 아래에 표시됩니다.')
            st.info('작업 대기 중입니다. 먼저 시작된 분석이 있으면 완료된 뒤 자동으로 이어집니다.' if latest['status']=='queued' else progress,icon='⏳')
            if not repo.worker_alive():st.warning('작업 프로세스가 응답하지 않습니다. 이 폴더의 시작.cmd를 실행해 주세요.')
    display_name=state['name'].replace('_',' ')
    st.markdown(f'<div class="page-kicker">데이터 점검 &nbsp;/&nbsp; <b>{html.escape(display_name)}</b></div>',unsafe_allow_html=True)
    st.title(display_name)
    status_label,status_class={
        'not_called':('분석 준비','pending'),'pending':('분석 중','pending'),
        'completed':('분석 완료',''),'failed':('일부 분석 실패','failed')
    }.get(state['ai_status'],('상태 확인','pending'))
    if state.get('understanding',{}).get('status')=='pending':status_label,status_class='데이터 설명 작성 중','pending'
    elif state.get('understanding',{}).get('status')=='failed':status_label,status_class='데이터 설명 확인 필요','failed'
    st.markdown(
        f'<div class="workspace-meta"><span>{html.escape(state["filename"])}</span><span>·</span>'
        f'<span class="version-pill">{html.escape(state["version_id"])} · 원본 보존</span>'
        f'<span class="status-pill {status_class}">{status_label}</span></div>',unsafe_allow_html=True)
    stage_navigation(state)
    with st.expander('분석 설정·버전 이력'):
        st.write('분석 목적 · '+(state['goal'] or '미정'))
        effort=state.get('settings',{}).get('reasoning_effort','medium')
        st.write('AI 분석 강도 · '+{'low':'빠르게','medium':'균형 있게','high':'꼼꼼하게'}.get(effort,effort))
        usage=ai_usage_summary(state)
        if usage:
            st.write(f"기록된 AI 입력량 · 약 {usage['low']:,}~{usage['high']:,} 토큰 ({usage['calls']:,}회 요청)")
            if usage['models']:st.caption('사용 모델 · '+', '.join(usage['models']))
            st.caption('실제로 전송한 입력 글자 수를 바탕으로 계산한 넓은 추정 범위입니다. 정확한 토큰 수, 과금량 또는 남은 구독량을 뜻하지 않습니다.')
        else:
            st.caption('AI 요청이 완료되면 입력량의 예상 범위를 여기에 표시합니다.')
        if state['versions']:
            target=st.selectbox('데이터 버전',[v['id'] for v in state['versions']],index=next(i for i,v in enumerate(state['versions']) if v['id']==state['version_id']))
            if st.button('선택한 버전 복원',disabled=target==state['version_id']):action(service.restore,state,target)
    monitor()
    if busy:
        if st.button('현재 작업 취소',type='tertiary'):action(service.cancel,state)
    if state.get('error'):
        st.error(state['error'])
        if st.button('진단·해석 다시 요청',disabled=busy):action(service.retry,state)
    if state.get('profile'):
        overview(state);explanation(state,service,busy);profiles(state);quality_patterns(state)
    if state['stage'] in ('deep_review','outputs'):
        with st.container(border=True):
            section(5,'기본 정제 결과')
            if state.get('lineage'):
                st.caption(f"{len(state['lineage'])}개 정제 버전을 보관하고 있습니다. 변경 내역은 보고서와 노트북에 포함됩니다.")
            else:st.caption('원본을 유지하고 심층 진단으로 진행했습니다.')
    if state['stage'] in ('basic_review','deep_review','outputs') and (state.get('analysis') or state.get('ai_status') in ('pending','failed')):
        review(state,service,busy)
    if state['stage']=='outputs':outputs(state,service,busy)


def recent_project_status(project):
    """Return a short, honest status for the recent-work list."""
    status=project.get('status');stage=project.get('stage');ai_status=project.get('ai_status')
    understanding=project.get('understanding_status')
    if status in {'queued','running'} or understanding=='pending':return '진행 중','running'
    if status in {'failed','partial'} or ai_status=='failed' or understanding=='failed':return '확인 필요','failed'
    if stage=='outputs':return '완료','completed'
    if status in {'needs_input','needs_approval'}:return '검토 중','review'
    if stage in {'basic_review','deep_review','profiling'}:return '검토 중','review'
    return '준비','ready'


def recent_project_date(value):
    if not value:return '생성일 확인 불가'
    if isinstance(value,str):
        try:value=dt.datetime.fromisoformat(value.replace('Z','+00:00'))
        except ValueError:return str(value)[:10]
    if isinstance(value,dt.datetime):
        try:value=value.astimezone()
        except (ValueError,OSError):pass
        return value.strftime('%Y.%m.%d')
    return str(value)[:10]


def recent_projects_sidebar(repo,service):
    projects=repo.list_projects();selected=st.query_params.get('project')
    if projects:
        st.markdown('<div class="sidebar-label">최근 작업</div>',unsafe_allow_html=True)
        for project in projects[:8]:
            label,status_class=recent_project_status(project)
            busy=project.get('status') in {'queued','running'} or project.get('understanding_status')=='pending'
            active=' active' if selected==project['id'] else ''
            filename=project.get('filename') or '원본 파일명 없음'
            created=recent_project_date(project.get('created_at'))
            card=''.join([
                f'<a class="recent-project-card{active}" href="?project={html.escape(project["id"],quote=True)}">',
                '<span class="recent-project-title">',
                f'<i class="recent-status {status_class}"></i><b>{html.escape(project["name"])}</b></span>',
                f'<span class="recent-project-file">{html.escape(filename)}</span>',
                f'<span class="recent-project-meta">{created}<em>{label}</em></span></a>',
            ])
            card_col,menu_col=st.columns([.84,.16],gap='small',vertical_alignment='center')
            with card_col:st.markdown(card,unsafe_allow_html=True)
            with menu_col:
                with st.popover('⋯',help=f'{project["name"]} 관리',use_container_width=True):
                    st.markdown('**작업 관리**')
                    st.caption(f'{filename} · {created} 생성')
                    if busy:st.info('분석이 끝난 뒤 이름을 바꾸거나 삭제할 수 있습니다.')
                    with st.form('rename_project_'+project['id'],border=False):
                        new_name=st.text_input('작업 이름',value=project['name'],max_chars=160)
                        rename=st.form_submit_button('이름 저장',disabled=busy,use_container_width=True)
                    if rename:
                        try:service.rename_project(project,new_name)
                        except Exception as exc:st.error(str(exc))
                        else:st.rerun()
                    confirm=st.checkbox('목록에서 삭제할게요',key='confirm_archive_'+project['id'],disabled=busy)
                    if st.button('목록에서 삭제',key='archive_project_'+project['id'],disabled=busy or not confirm,use_container_width=True):
                        try:service.archive_project(project)
                        except Exception as exc:st.error(str(exc))
                        else:
                            if selected==project['id']:st.query_params.clear()
                            st.rerun()
    archived=repo.list_archived_projects()
    if archived:
        with st.expander(f'삭제한 작업 {len(archived)}개',expanded=False):
            st.caption('원본과 분석 이력은 보관되어 있습니다.')
            for project in archived:
                st.markdown(f'<div class="archived-project"><b>{html.escape(project["name"])}</b><span>{html.escape(project.get("filename") or "원본 파일명 없음")} · {recent_project_date(project.get("archived_at"))} 삭제</span></div>',unsafe_allow_html=True)
                if st.button('되돌리기',key='restore_project_'+project['id'],use_container_width=True):
                    try:service.restore_project(project)
                    except Exception as exc:st.error(str(exc))
                    else:st.rerun()


with st.sidebar:
    st.markdown('<div class="brand"><span class="brand-mark"></span>DataPrep Studio</div>',unsafe_allow_html=True)
    st.markdown('<div class="sidebar-sub">데이터 진단·정제 워크스페이스</div>',unsafe_allow_html=True)
    st.divider()
try:
    repo,service=backend()
except Exception:
    st.title('작업 공간을 연결해 주세요')
    st.error('PostgreSQL에 연결할 수 없습니다. 이 프로토타입 폴더의 .env 설정과 PostgreSQL 실행 상태를 확인해 주세요.')
    st.caption('연결 정보는 화면에 표시하지 않습니다. 시작.cmd에서 연결 상태를 확인할 수 있습니다.')
    st.stop()
with st.sidebar:
    if st.button('＋ 새 데이터 점검',use_container_width=True,type='primary'):st.query_params.clear();st.rerun()
    recent_projects_sidebar(repo,service)
    st.divider()
    st.markdown('<div class="storage-status">PostgreSQL 연결됨</div>',unsafe_allow_html=True)
    connection_panel()
pid=st.query_params.get('project')
if pid:workspace(repo,service,pid)
else:upload(service)
