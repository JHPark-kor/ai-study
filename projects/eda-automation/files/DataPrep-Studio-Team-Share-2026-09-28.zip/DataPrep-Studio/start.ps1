$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$localPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
$sharedPython = Join-Path (Split-Path $PSScriptRoot -Parent) '.venv\Scripts\python.exe'
if (Test-Path -LiteralPath $localPython) { $runtime = $localPython }
elseif (Test-Path -LiteralPath $sharedPython) { $runtime = $sharedPython }
else { throw 'Python 환경이 없습니다. setup.ps1을 먼저 실행해 주세요.' }
& $runtime -c 'from studio.repository import Repository; Repository().initialize()'
if ($LASTEXITCODE -ne 0) { throw 'PostgreSQL 연결 설정을 확인해 주세요.' }
Write-Host 'PostgreSQL connected'
$logPath = Join-Path $PSScriptRoot 'logs'
$runPath = Join-Path $PSScriptRoot 'run'
New-Item -ItemType Directory -Path $logPath,$runPath -Force | Out-Null
$launchItems = @(
    @{Name='worker'; Args=@(('"' + (Join-Path $PSScriptRoot 'worker.py') + '"'))},
    @{Name='web'; Args=@('-m','streamlit','run',('"' + (Join-Path $PSScriptRoot 'app.py') + '"'),'--server.port','8502','--server.address','127.0.0.1','--server.headless','true','--server.fileWatcherType','none','--browser.gatherUsageStats','false')}
)
foreach ($item in $launchItems) {
    $record = Join-Path $runPath ($item.Name + '.json')
    $alreadyRunning = $false
    if (Test-Path -LiteralPath $record) {
        try {
            $saved = Get-Content -LiteralPath $record -Raw | ConvertFrom-Json
            $existingProcess = Get-Process -Id $saved.pid -ErrorAction SilentlyContinue
            $savedTicks = if ($saved.startedTicks) { [long]$saved.startedTicks } else { ([datetime]$saved.started).ToUniversalTime().Ticks }
            if ($existingProcess -and $existingProcess.StartTime.ToUniversalTime().Ticks -eq $savedTicks) { $alreadyRunning = $true }
        } catch {
            Write-Warning ("손상된 실행 기록을 새로 만듭니다: " + $record)
        }
    }
    if (-not $alreadyRunning) {
        $child = Start-Process -FilePath $runtime -ArgumentList $item.Args -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logPath ($item.Name + '.out.log')) -RedirectStandardError (Join-Path $logPath ($item.Name + '.err.log')) -PassThru
        @{pid=$child.Id;startedTicks=[string]$child.StartTime.ToUniversalTime().Ticks} | ConvertTo-Json | Set-Content -LiteralPath $record -Encoding UTF8
    }
}
Write-Host 'DataPrep Studio: http://127.0.0.1:8502'
if (-not $env:STUDIO_NO_BROWSER) { Start-Process 'http://127.0.0.1:8502' }
