# 개발 인수인계

## 제품의 기준

DataPrep Studio는 분석가가 본격적인 분석에 들어가기 전에 데이터를 이해하고 품질 문제와 정제 후보를 검토하는 로컬 웹 앱입니다. Python이 계산 근거를 만들고, Codex가 목적과 메타데이터를 함께 읽어 의미·해석·질문·추천을 작성합니다. 데이터 변경은 사용자가 영향 미리보기를 확인하고 승인한 뒤에만 새 버전에 적용합니다.

현재 요구사항과 수용 기준은 `specs/001-team-prototype/spec.md`, 구조와 결정은 `plan.md`, 작업 상태는 `tasks.md`, 검증 증거는 `validation.md`를 기준으로 합니다.

## 코드 지도

| 위치 | 역할 |
|---|---|
| `app.py`, `studio/styles.py` | 한 화면 UI, 단계별 결과와 대화·승인 |
| `worker.py` | 오래 걸리는 진단·AI·정제 작업 실행 |
| `studio/analysis_loader.py` | CSV·Excel·구분자 텍스트·ARFF·TS·ZIP의 검증, 원본 표현과 재현 설정 보존 |
| `studio/analysis.py` | 프로파일링과 품질 근거 계산 |
| `studio/ai.py` | Codex에 전달할 맥락과 응답 계약 |
| `studio/codex_client.py` | 로컬 Codex App Server와 ChatGPT 로그인 |
| `studio/service.py` | 프로젝트 상태, 답변 반영, 승인과 산출물 흐름 |
| `studio/cleaning.py` | 미리보기와 승인된 정제 실행 |
| `studio/repository.py` | PostgreSQL 저장과 작업 상태 |
| `studio/exports.py` | 보고서·데이터 사전·노트북·ZIP |
| `tests/` | 계산, 대화, 승인, 복원, 산출물 회귀 검사 |

## 변경 순서

1. 현재 요청이 해결할 사용자 문제와 관련 FR·AC를 확인합니다.
2. 화면 문구만 바꾸는 일인지, 계산·대화·상태·산출물까지 바뀌는 일인지 범위를 정합니다.
3. 범위가 달라졌다면 명세와 `plan.md`의 결정 기록을 먼저 갱신합니다.
4. 코드를 수정하고 관련 테스트를 실행합니다.
5. 실행한 검사와 아직 하지 않은 검사를 `validation.md`에 나눠 기록합니다.

질문 생성, 사용자 답변, 계산 근거, 데이터 사전, 보고서, 노트북은 같은 프로젝트 버전을 가리켜야 합니다. 프롬프트만 고쳐서 이전 계산이나 산출물과 의미가 어긋나지 않게 확인하세요.

## 지켜야 할 경계

- 원본 파일은 수정하지 않습니다.
- 기본·심층 정제 모두 미리보기와 명시적 승인 뒤 새 버전에 적용합니다.
- Python 계산 결과와 Codex 해석을 구분합니다.
- 로그인 확인, 실제 AI 응답 성공, 전체 분석 성공을 같은 증거로 보지 않습니다.
- 특정 예제 데이터의 컬럼명이나 값에 맞춘 규칙을 제품 코드에 넣지 않습니다.
- `.env`, 데이터, 로그, 실행 PID, Codex 인증 파일을 커밋하거나 공유하지 않습니다.
- 제품에서 실행하는 분석 세션에 이 저장소의 개발 지침을 분석 맥락으로 전달하지 않습니다.

## 로컬 실행

`TEAM_SETUP.md`의 절차로 환경을 만들고 `시작.cmd`를 실행합니다. 화면은 `http://127.0.0.1:8502`에서 열립니다. Streamlit과 worker는 각각 `logs/`에 로그를 남기고 `run/`에 현재 프로세스 정보를 저장합니다.

공유본을 다시 만들 때는 다음을 실행합니다.

```powershell
.\make_share_package.ps1
```

완성된 ZIP은 `dist/`에 생성됩니다. 스크립트는 허용된 소스만 복사하므로 새 파일을 배포하려면 허용 목록을 명시적으로 갱신해야 합니다.

공유 전에는 ZIP 자체를 다시 검사합니다.

```powershell
.\.venv\Scripts\python.exe .\verify_share_package.py .\dist\DataPrep-Studio-Team-Share-YYYY-MM-DD.zip
```
