"""Check local prerequisites without printing credentials or account details."""
from __future__ import annotations

import platform
import sys


def main() -> int:
    print(f"[확인] Python {platform.python_version()}")

    database_ok = False
    try:
        from studio.repository import Repository

        repository = Repository()
        repository.initialize()
        database_ok = repository.check()
        print("[확인] PostgreSQL 연결 및 스키마 준비 완료")
    except Exception as exc:  # The exact driver message helps with local setup.
        print(f"[필요] PostgreSQL 연결을 확인해 주세요: {exc}")

    codex_ok = False
    try:
        from studio.codex_client import check_connection, executable

        print(f"[확인] Codex 실행 파일: {executable()}")
        connection = check_connection(refresh=True)
        codex_ok = bool(connection.get("connected") and connection.get("mode") == "chatgpt")
        if codex_ok:
            print("[확인] 이 Windows 사용자 환경의 ChatGPT 로그인이 연결되어 있습니다.")
        else:
            print("[필요] 시작.cmd 실행 후 웹 화면의 '연결 설정'에서 본인의 ChatGPT 계정으로 로그인해 주세요.")
            if connection.get("error"):
                print(f"       연결 확인 결과: {connection['error']}")
    except Exception as exc:
        print(f"[필요] Codex 설치 또는 실행 경로를 확인해 주세요: {exc}")

    if not database_ok:
        return 1
    return 0 if codex_ok else 2


if __name__ == "__main__":
    sys.exit(main())
