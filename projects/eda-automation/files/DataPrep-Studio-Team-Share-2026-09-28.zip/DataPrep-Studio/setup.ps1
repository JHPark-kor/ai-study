$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) {
    if (Get-Command py -ErrorAction SilentlyContinue) { py -3 -m venv .venv }
    elseif (Get-Command python -ErrorAction SilentlyContinue) { python -m venv .venv }
    else { throw 'Python 3.11 이상을 먼저 설치해 주세요.' }
}
& '.\.venv\Scripts\python.exe' -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw '패키지 설치 실패' }
if (-not (Test-Path -LiteralPath '.env')) { Copy-Item -LiteralPath '.env.example' -Destination '.env' }
$codexResult = & '.\.venv\Scripts\python.exe' -c "from studio.codex_client import executable; print(executable())" 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host ('Codex 확인: ' + ($codexResult | Select-Object -Last 1))
} else {
    Write-Warning 'Codex 실행 파일을 찾지 못했습니다. Codex 앱 또는 CLI를 설치한 뒤 다시 확인해 주세요.'
}
Write-Host '설치가 끝났습니다.'
Write-Host '1) .env에 이 PC의 PostgreSQL 연결 정보를 입력합니다.'
Write-Host '2) 환경확인.cmd로 연결 상태를 확인합니다.'
Write-Host '3) 시작.cmd를 실행하고 웹 화면에서 본인의 ChatGPT 계정으로 로그인합니다.'
