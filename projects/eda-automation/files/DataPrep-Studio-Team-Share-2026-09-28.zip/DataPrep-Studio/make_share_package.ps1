param(
    [string]$OutputDirectory = (Join-Path $PSScriptRoot 'dist')
)

$ErrorActionPreference = 'Stop'
$projectRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$outputRoot = [System.IO.Path]::GetFullPath($OutputDirectory)
$packageName = 'DataPrep-Studio-Team-Share-' + (Get-Date -Format 'yyyy-MM-dd')
$stagingContainer = Join-Path $outputRoot 'package-staging'
$stagingRoot = Join-Path $stagingContainer 'DataPrep-Studio'
$zipPath = Join-Path $outputRoot ($packageName + '.zip')

function Assert-Within([string]$Child, [string]$Parent) {
    $parentPrefix = [System.IO.Path]::GetFullPath($Parent).TrimEnd('\') + '\'
    $childPath = [System.IO.Path]::GetFullPath($Child)
    if (-not $childPath.StartsWith($parentPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "안전하지 않은 출력 경로입니다: $childPath"
    }
}

function Get-ProjectRelativePath([string]$FullPath) {
    $rootPrefix = $projectRoot.TrimEnd('\') + '\'
    $absolutePath = [System.IO.Path]::GetFullPath($FullPath)
    if (-not $absolutePath.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "프로젝트 밖의 파일은 공유본에 넣을 수 없습니다: $absolutePath"
    }
    return $absolutePath.Substring($rootPrefix.Length)
}

New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null
Assert-Within $stagingContainer $outputRoot
if (Test-Path -LiteralPath $stagingContainer) {
    Remove-Item -LiteralPath $stagingContainer -Recurse -Force
}
New-Item -ItemType Directory -Path $stagingRoot -Force | Out-Null

$files = @(
    '.env.example', '.gitignore', 'AGENTS.md', 'CONTRACTS.md', 'DEVELOPMENT.md',
    'README.md', 'TEAM_SETUP.md', 'requirements.txt', 'app.py', 'worker.py',
    'check_environment.py', 'check-environment.ps1', 'verify_share_package.py', 'setup.ps1', 'start.ps1', 'stop.ps1',
    'make_share_package.ps1'
)
$directories = @('.specify', '.streamlit', 'design', 'samples', 'specs', 'studio', 'tests')
$blockedNames = @('.env', 'secrets.toml')
$blockedSegments = @('.venv', '__pycache__', '.pytest_cache', 'data', 'logs', 'run', 'dist', '.codex', '.git')

foreach ($file in $files) {
    $source = Join-Path $projectRoot $file
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "필수 파일이 없습니다: $file" }
    $target = Join-Path $stagingRoot $file
    $targetParent = Split-Path $target -Parent
    New-Item -ItemType Directory -Path $targetParent -Force | Out-Null
    Copy-Item -LiteralPath $source -Destination $target
}

# CMD launchers are discovered by extension so Windows PowerShell 5.1 does not
# have to decode Korean file names from this script before copying them.
Get-ChildItem -LiteralPath $projectRoot -Filter '*.cmd' -File | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $stagingRoot $_.Name)
}

foreach ($directory in $directories) {
    $sourceDirectory = Join-Path $projectRoot $directory
    if (-not (Test-Path -LiteralPath $sourceDirectory -PathType Container)) { throw "필수 폴더가 없습니다: $directory" }
    Get-ChildItem -LiteralPath $sourceDirectory -Recurse -File -Force | ForEach-Object {
        $relative = Get-ProjectRelativePath $_.FullName
        $segments = $relative -split '[\\/]'
        if ($blockedNames -contains $_.Name) { return }
        if (@($segments | Where-Object { $blockedSegments -contains $_ }).Count -gt 0) { return }
        $target = Join-Path $stagingRoot $relative
        New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
        Copy-Item -LiteralPath $_.FullName -Destination $target
    }
}

# Remove this PC's user-profile prefix from text copied into the share package.
# The development source stays unchanged; only the staging copy is portable.
$profileBackslash = [System.IO.Path]::GetFullPath($env:USERPROFILE).TrimEnd('\')
$profileSlash = $profileBackslash.Replace('\', '/')
$portableTextExtensions = @('.py', '.md', '.ps1', '.cmd', '.toml', '.json', '.txt', '.example')
Get-ChildItem -LiteralPath $stagingRoot -Recurse -File -Force | Where-Object {
    $portableTextExtensions -contains $_.Extension.ToLowerInvariant()
} | ForEach-Object {
    $content = Get-Content -LiteralPath $_.FullName -Raw -Encoding UTF8
    $portable = $content.Replace($profileBackslash, '%USERPROFILE%').Replace($profileSlash, '%USERPROFILE%')
    if ($portable -ne $content) {
        [System.IO.File]::WriteAllText($_.FullName, $portable, [System.Text.UTF8Encoding]::new($false))
    }
}

$entries = Get-ChildItem -LiteralPath $stagingRoot -Recurse -File | Sort-Object FullName | ForEach-Object {
    [ordered]@{
        path = $_.FullName.Substring($stagingRoot.TrimEnd('\').Length + 1).Replace('\', '/')
        size = $_.Length
        sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    }
}
$manifest = [ordered]@{
    package = 'DataPrep Studio team source'
    created_at = (Get-Date).ToString('o')
    authentication = 'Each Windows user signs in with their own local Codex/ChatGPT account. No credential is bundled.'
    excluded = @('.env', '.venv', '.codex', 'data', 'logs', 'run', 'dist', '__pycache__', '.pytest_cache', '.git', 'secrets.toml')
    files = @($entries)
}
$manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stagingRoot 'package_manifest.json') -Encoding UTF8

Add-Type -AssemblyName System.IO.Compression.FileSystem
if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
[System.IO.Compression.ZipFile]::CreateFromDirectory($stagingContainer, $zipPath, [System.IO.Compression.CompressionLevel]::Optimal, $false)
Remove-Item -LiteralPath $stagingContainer -Recurse -Force

$zipHash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host "공유본: $zipPath"
Write-Host "SHA-256: $zipHash"
