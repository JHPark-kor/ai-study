# 구현 모듈 계약

2026-09-16. 사용자 지시에 따라 기존 dataprep-workbench와 나란한 독립 폴더이다.
구현 기준은 specs/001-team-prototype/이다. 기존 설계를 이 폴더로 복사한 뒤 실제 구현에 맞게 유지한다.

## 공통 자료

DataFrame 컬럼은 c0001 형식의 고정 ID, index는 원본 행 순서의 정수이다.
표시 이름은 schema의 name이며 원래 이름은 original_name에 보존한다.
schema: [{id, name, original_name, dtype, role, description, unit, ...}].
role: numeric / categorical / datetime / text / id. 추가 키는 허용한다.
모든 저장 dict는 JSON 직렬화 가능해야 한다(NaN, numpy scalar, Timestamp는 정규화).

project state:
id, name, goal, source_info, metadata_text, revision, version_id, stage,
schema, ingest, profile, context, analysis, messages, recipes, preview,
lineage, versions, artifacts, ai_status, status, error.
context: {goal, definitions: {column_id: {...}}, dataset_description, source, collection_period,
observation_unit, decisions: [], unresolved: [], ...}.
messages: [{id, role: user/assistant, content, created_at, issue_ids: [], ...}].
lineage: [{version_id, parent_version, manifest, impact, approved_at}].
versions: [{id, label, path, schema, frame_hash, parent_id, lineage, ...}].
Paths are backend-generated registered paths only. User uploads never execute Python/pickle/SQL.

## analysis.py (담당: 진단)

- load_dataset(raw: bytes, filename: str, settings: dict|None=None) -> (frame, schema, ingest)
- read_metadata(raw: bytes|None, filename: str|None, text: str, schema: list) -> dict
  returns definitions (by column ID), dataset fields, warnings/unmatched; preserve source.
- profile_dataset(frame, schema, context=None, deep=False) -> dict
  overview: {rows, columns, missing_cells, duplicate_rows, memory_bytes, types}
  columns: list with id/name/role/dtype/valid/missing/unique, stats/frequency/histogram as applicable
  evidence: [{id, kind, columns:[IDs], summary, count, details, row_ids, sampled, ...}]
  all numeric facts have evidence IDs; frame unchanged.
- investigate(frame, schema, request: dict, context=None) -> list[evidence]
  bounded, whitelisted additional checks, no eval.

## cleaning.py + exports.py (담당: 정제)

rule: {id, operation, columns:[IDs], params:{}, reason, evidence_ids:[], phase:basic/deep}.
Cleaning module documents supported operation/params and validates strictly.
- preview(frame, schema, rules, context=None) -> dict with frame, schema, manifest, impact, frame_hash
- apply_manifest(frame, schema, manifest) -> (frame, schema)
- hash_frame(frame, schema) -> str
manifest contains frozen rules/parameters, operation version, source/output hashes, environment.
Copy-on-write; approved manifests alone are executable. Never modify input frame/schema.
- build_exports(state, frame, original_bytes, output_dir, title) -> list[{kind,label,path,mime}]
  outputs report.html, dictionary.html/csv, notebook.ipynb, data.csv, manifest.json.
  Notebook standalone: load original + ALL lineage manifests, human-readable section titles,
  executable source of same operations. Agents coordinate source loader reuse without legacy imports.

## ai.py + codex_client.py (담당: Codex)

- analyze(context, profile, messages, phase='basic', thread_id=None) -> dict
  {summary, dataset_description, definitions:{ID: {...}}, findings:[], question:str|null,
   recipes:[rule], investigations:[{kind,...}], resolved_issue_ids:[],
   unresolved:[], thread_id, model, ...}
  phase: basic/deep/followup/synthesis. Receives computed evidence. Validate IDs/operations.
  Structured context patches must be returned, not silently applied. No raw data modification.
- check_connection() -> {mode, plan, ...}; no API key fallback; same ChatGPT App Server.
- login helpers: agent chooses API and documents for root UI integration.
  Account credentials never logged or stored in project DB.

## Root-owned modules

config.py / repository.py / service.py / worker.py / app.py / UI/styles / launchers.
PostgreSQL durable state and leased jobs. No silent memory/SQLite production fallback.
Dedicated in-memory fake is permitted in tests only. Tests use synthetic data.
Every worker publish checks job lease token, dataset version and context revision.
Cleaning approval binds exact preview/manifest; per-project mutation serialized.
