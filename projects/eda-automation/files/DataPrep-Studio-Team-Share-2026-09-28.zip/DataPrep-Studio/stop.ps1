$ErrorActionPreference = 'Stop'

function Stop-VerifiedProcessTree {
    param([System.Diagnostics.Process]$RootProcess)

    # Start-Process can launch a Python shim which then owns the real worker or
    # Streamlit process. Enumerate only descendants of the already verified PID
    # and stop children first so no app-server process is left behind.
    $descendants = @()
    try {
        $processes = @(Get-CimInstance Win32_Process)
        $frontier = @([int]$RootProcess.Id)
        while ($frontier.Count -gt 0) {
            $children = @($processes | Where-Object { [int]$_.ParentProcessId -in $frontier })
            if ($children.Count -eq 0) { break }
            $descendants += $children
            $frontier = @($children | ForEach-Object { [int]$_.ProcessId })
        }
    } catch {
        Write-Warning '자식 프로세스 목록을 확인하지 못해 기록된 프로세스만 종료합니다.'
    }
    $descendantIds = @($descendants | Select-Object -ExpandProperty ProcessId)
    [array]::Reverse($descendantIds)
    foreach ($processId in $descendantIds) {
        Stop-Process -Id ([int]$processId) -Force -ErrorAction SilentlyContinue
    }
    Stop-Process -Id $RootProcess.Id -Force -ErrorAction SilentlyContinue
    try { $RootProcess.WaitForExit(5000) | Out-Null } catch {}
}

foreach ($name in @('web','worker')) {
    $record = Join-Path $PSScriptRoot ('run\' + $name + '.json')
    if (Test-Path -LiteralPath $record) {
        $saved = Get-Content -LiteralPath $record -Raw | ConvertFrom-Json
        $child = Get-Process -Id $saved.pid -ErrorAction SilentlyContinue
        $savedTicks = if ($saved.startedTicks) { [long]$saved.startedTicks } else { ([datetime]$saved.started).ToUniversalTime().Ticks }
        if ($child -and $child.StartTime.ToUniversalTime().Ticks -eq $savedTicks) {
            Stop-VerifiedProcessTree -RootProcess $child
        }
        Remove-Item -LiteralPath $record
    }
}
Write-Host 'DataPrep Studio stopped.'
