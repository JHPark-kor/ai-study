# 팀원 설치와 실행 안내

이 압축파일에는 DataPrep Studio의 소스 코드, 명세, 테스트와 합성 예제가 들어 있습니다. 업로드한 데이터, PostgreSQL 내용, `.env`, 로그, Codex 로그인 정보는 들어 있지 않습니다.

## 먼저 준비할 것

- Windows 10 또는 11
- Python 3.11 이상
- PostgreSQL
- Codex 앱 또는 Codex CLI
- Codex를 사용할 수 있는 본인의 ChatGPT 계정

## 처음 한 번만 설정하기

1. 압축파일을 원하는 폴더에 풉니다. OneDrive 동기화 중인 폴더보다는 짧고 쓰기 가능한 로컬 경로를 권장합니다.
2. `setup.ps1`을 실행합니다. PowerShell 실행이 차단되면 폴더에서 PowerShell을 열고 다음을 실행합니다.

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\setup.ps1
   ```

3. PostgreSQL 서비스를 실행하고 빈 데이터베이스를 하나 만듭니다. 기본 이름은 `dataprep_workbench`입니다. 테이블은 프로그램이 첫 연결 때 자동으로 만듭니다.
4. 자동으로 만들어진 `.env`를 메모장으로 열고 이 PC의 PostgreSQL 값을 입력합니다.

   ```text
   PGHOST=localhost
   PGPORT=5432
   PGDATABASE=dataprep_workbench
   PGUSER=postgres
   PGPASSWORD=각자_PC의_비밀번호
   ```

5. `환경확인.cmd`를 실행합니다. PostgreSQL과 Codex 설치 위치를 확인하고, 현재 Windows 사용자 환경의 ChatGPT 로그인 상태를 알려줍니다.
6. `시작.cmd`를 실행합니다. 브라우저가 열리지 않으면 `http://127.0.0.1:8502`로 접속합니다.
7. 화면 위쪽의 **연결 설정 → ChatGPT로 로그인**을 누르고 본인의 ChatGPT 계정으로 인증합니다.

`환경확인.cmd`에서 PostgreSQL 연결과 Codex 실행 파일을 모두 확인할 수 있습니다. Codex가 이미 로그인되어 있으면 그 계정을 그대로 사용하고, 로그인되어 있지 않으면 웹앱에서 본인 계정으로 로그인합니다.

## 계정과 데이터는 어떻게 분리되나요?

- 프로그램은 API 키를 요구하거나 공유하지 않습니다.
- 로그인할 때 현재 Windows 사용자의 Codex 인증 저장소를 사용합니다. 압축파일에는 다른 사람의 인증 정보가 없습니다.
- 팀원이 자기 PC에서 로그인하면 그 팀원의 ChatGPT 계정과 사용 한도가 적용됩니다.
- `.env`와 PostgreSQL도 각 PC에서 따로 만듭니다. 따라서 프로젝트 목록과 분석 기록은 자동으로 공유되지 않습니다.
- 실제 데이터를 공유해야 한다면 회사의 승인된 저장소를 사용하세요. 이 소스 압축파일에 업무 데이터를 다시 넣지 마세요.

## 매번 실행할 때

1. PostgreSQL이 실행 중인지 확인합니다.
2. `시작.cmd`를 실행합니다.
3. 작업이 끝나면 `종료.cmd`를 실행합니다.

## 코드 수정과 검사

개발 구조와 변경 원칙은 `DEVELOPMENT.md`, 제품 요구사항은 `specs/001-team-prototype/`에 있습니다.

```powershell
.\.venv\Scripts\python.exe -m pytest tests -q
```

테스트용 PostgreSQL까지 포함하려면 별도의 테스트 DB를 준비한 뒤 다음을 실행합니다.

```powershell
$env:STUDIO_TEST_DATABASE='1'
.\.venv\Scripts\python.exe -m pytest tests -q
```

## 자주 생기는 문제

- **PostgreSQL 연결 실패:** `.env`의 호스트·포트·DB 이름·사용자·비밀번호와 PostgreSQL 실행 상태를 확인합니다.
- **Codex 실행 파일을 찾지 못함:** Codex 앱 또는 CLI를 설치합니다. 자동 탐지가 안 되면 `.env`의 `CODEX_EXECUTABLE`에 각자 PC의 `codex.exe` 경로를 적습니다.
- **로그인 실패:** `codex login status`로 현재 사용자 계정의 상태를 확인하고, 웹 화면에서 새 로그인 요청을 시작합니다. 이전 사용자의 `.codex` 폴더나 인증 파일을 복사하지 않습니다.
- **8502 포트 사용 중:** 기존 DataPrep Studio를 `종료.cmd`로 닫은 뒤 다시 실행합니다.
