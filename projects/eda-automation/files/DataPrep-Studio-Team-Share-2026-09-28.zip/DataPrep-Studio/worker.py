"""Run owned job children; cancellation stops only their process trees."""
from __future__ import annotations

import logging
import multiprocessing as mp
import os
import signal
import time

from studio.repository import Conflict, Repository


class _WindowsJob:
    """An owned Windows job; closing its handle also kills its descendants."""
    def __init__(self, pid):
        import ctypes
        from ctypes import wintypes

        class BASIC(ctypes.Structure):
            _fields_ = [("PerProcessUserTimeLimit", ctypes.c_longlong), ("PerJobUserTimeLimit", ctypes.c_longlong),
                        ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                        ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
                        ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD), ("SchedulingClass", wintypes.DWORD)]
        class IO(ctypes.Structure):
            _fields_ = [(name, ctypes.c_ulonglong) for name in (
                "ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
                "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]
        class EXTENDED(ctypes.Structure):
            _fields_ = [("BasicLimitInformation", BASIC), ("IoInfo", IO),
                        ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                        ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]

        self.kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        self.kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        self.kernel.CreateJobObjectW.restype = wintypes.HANDLE
        self.kernel.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        self.kernel.SetInformationJobObject.restype = wintypes.BOOL
        self.kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        self.kernel.AssignProcessToJobObject.restype = wintypes.BOOL
        self.kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.kernel.OpenProcess.restype = wintypes.HANDLE
        self.kernel.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
        self.kernel.TerminateJobObject.restype = wintypes.BOOL
        self.kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel.CloseHandle.restype = wintypes.BOOL
        self.handle = self.kernel.CreateJobObjectW(None, None)
        if not self.handle:
            raise OSError("작업 프로세스 그룹을 만들지 못했습니다.")
        process = None
        try:
            limits = EXTENDED()
            limits.BasicLimitInformation.LimitFlags = 0x00002000  # KILL_ON_JOB_CLOSE
            if not self.kernel.SetInformationJobObject(self.handle, 9, ctypes.byref(limits), ctypes.sizeof(limits)):
                raise OSError("작업 프로세스 종료 규칙을 설정하지 못했습니다.")
            process = self.kernel.OpenProcess(0x0100 | 0x0001 | 0x1000, False, pid)
            if not process or not self.kernel.AssignProcessToJobObject(self.handle, process):
                raise OSError("작업 프로세스의 소유권을 설정하지 못했습니다.")
        except Exception:
            self.close()
            raise
        finally:
            if process:
                self.kernel.CloseHandle(process)

    def terminate(self):
        if self.handle:
            self.kernel.TerminateJobObject(self.handle, 1)

    def close(self):
        if self.handle:
            self.kernel.CloseHandle(self.handle)
            self.handle = None


def _perform_job(job):
    from studio.service import Processor
    Processor(Repository()).run(job)


def _gated_target(gate, target, args, result_pipe):
    if os.name != "nt":
        os.setsid()
    if not gate.wait(30):
        result_pipe.close()
        return
    try:
        target(*args)
        result_pipe.send({"status": "completed"})
    except Conflict:
        result_pipe.send({"status": "superseded"})
    except BaseException as exc:
        # No credentials or user data in supervisor logs.
        result_pipe.send({"status": "error", "error_type": type(exc).__name__})
    finally:
        result_pipe.close()


class OwnedTask:
    def __init__(self, target, args=()):
        context = mp.get_context("spawn")
        self.gate = context.Event()
        self.receiver, sender = context.Pipe(duplex=False)
        self.process = context.Process(target=_gated_target, args=(self.gate, target, args, sender), daemon=False)
        self.group = None
        self.process.start()
        sender.close()
        try:
            if os.name == "nt":
                # Child waits until ownership is assigned, so it cannot spawn
                # an App Server outside our own process group in the meantime.
                self.group = _WindowsJob(self.process.pid)
            self.gate.set()
        except Exception:
            self.process.terminate()
            self.process.join(timeout=5)
            self.receiver.close()
            self.process.close()
            raise

    def alive(self):
        return self.process.is_alive()

    def join(self, seconds):
        self.process.join(timeout=seconds)

    def result(self):
        try:
            if self.receiver.poll():
                return self.receiver.recv()
        except EOFError:
            pass
        return {"status": "error", "error_type": "WorkerChildExited"}

    def close(self):
        if self.group:
            self.group.terminate()
            self.group.close()
            self.group = None
        elif self.process.pid and os.name != "nt":
            try:
                os.killpg(self.process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        if self.process.is_alive():
            self.process.terminate()
        self.process.join(timeout=3)
        if self.process.is_alive():
            self.process.kill()
            self.process.join(timeout=3)
        self.receiver.close()
        self.process.close()


def run_owned_job(repo, job, *, poll_interval=2.0, task_factory=OwnedTask):
    """A lost or unconfirmable lease terminates only this job's process tree."""
    task = task_factory(_perform_job, (job,))
    last_confirmed = time.monotonic()
    try:
        while task.alive():
            try:
                if not repo.heartbeat(job):
                    return {"status": "superseded"}
                last_confirmed = time.monotonic()
            except Exception:
                # Reclaim is 45 seconds; stop before another owner can begin.
                if time.monotonic() - last_confirmed >= 30:
                    return {"status": "lease_unconfirmed"}
                logging.warning("작업 연결 확인 지연")
            task.join(poll_interval)
        return task.result()
    finally:
        task.close()


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    repo = Repository()
    repo.initialize()
    while True:
        try:
            repo.heartbeat()
            job = repo.claim()
            if not job:
                time.sleep(1)
                continue
            result = run_owned_job(repo, job)
            if result["status"] in {"superseded", "lease_unconfirmed"}:
                logging.info("작업 프로세스 정리: %s", job["id"])
            elif result["status"] == "error":
                logging.error("작업 처리 실패: %s", result.get("error_type", "WorkerError"))
        except KeyboardInterrupt:
            break
        except Exception as exc:
            logging.error("작업 처리 실패: %s", type(exc).__name__)
            time.sleep(3)


if __name__ == "__main__":
    mp.freeze_support()
    main()
