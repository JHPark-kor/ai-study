import copy
from unittest.mock import patch

import pandas as pd

from studio.analysis import profile_dataset
from studio.codex_client import CodexError
from studio.service import Processor


def setup_state():
    frame = pd.DataFrame({'c0001': pd.Series(['1','2',None],dtype='string'), 'c0002': pd.Series(['a','a','b'],dtype='string')})
    schema = [dict(id='c0001',name='금액',original_name='금액',role='text',dtype='string',unit='',description=''),
              dict(id='c0002',name='집단',original_name='집단',role='categorical',dtype='string',unit='',description='')]
    context = dict(goal='집단별 현황',definitions={},decisions=[],unresolved=[])
    # Production uploads now enter reasoning with the dataset-specific quality
    # baseline already calculated.
    profile = profile_dataset(frame,schema,context,deep=True)
    state = dict(id='test',goal=context['goal'],version_id='v0',revision=1,stage='basic_review',schema=schema,profile=profile,
                 context=context,analysis={},recipes=[],messages=[],versions=[dict(id='v0',schema=copy.deepcopy(schema))])
    return frame,state


def response(**extra):
    return dict(summary='데이터를 점검했다.',definitions={},findings=[],question=None,recipes=[],investigations=[],decisions=[],unresolved=[],**extra)


class FakeRepo:
    def __init__(self): self.checkpoints=[]
    def publish(self,job,state,**kwargs): self.checkpoints.append(copy.deepcopy(state))


def test_role_change_recalculates_without_an_automatic_second_model_call():
    frame,state = setup_state()
    calls=[]
    original_id=state['profile']['columns'][0]['evidence_id']
    def analyst(context,profile,messages,phase,thread_id):
        calls.append((phase,copy.deepcopy(profile)))
        result=response()
        if len(calls)==1:
            result['definitions']={'c0001':{'role':'numeric','description':'거래 금액'}}
            result['findings']=[{'id':'f1','evidence_ids':[original_id]}]
        return result
    repo=FakeRepo()
    Processor(repo,analyst).reason({},state,frame,'basic')
    assert [phase for phase,_ in calls]==['basic']
    assert state['profile']['columns'][0]['role']=='numeric'
    assert state['profile']['columns'][0]['evidence_id']!=original_id
    assert state['analysis']['findings']==[]
    assert state['analysis']['unresolved'][0]['id']=='definition_reassessment'
    assert state['ai_status']=='completed'
    assert not repo.checkpoints[1]['analysis']


def test_additional_check_failure_is_named_and_does_not_erase_other_results():
    frame,state=setup_state()
    calls=[]
    def analyst(*args,**kwargs):
        calls.append(1)
        result=response()
        if len(calls)==1:
            result['investigations']=[{'kind':'grouped_missing','columns':['c0001'],'params':{'group_by':['c0002']}}]
        return result
    with patch('studio.analysis.investigate',side_effect=ValueError('집단 기준 확인 필요')):
        Processor(FakeRepo(),analyst).reason({},state,frame,'deep')
    assert state['ai_status']=='completed'
    assert state['analysis']['unresolved'][0]['status']=='needs_check'
    assert state['analysis']['unresolved'][0]['reason']=='집단 기준 확인 필요'
    assert state['profile']['overview']['rows']==3
    assert list(state['investigation_cache'].values())[0]['status']=='failed'


def test_repeated_identical_check_runs_only_once():
    frame,state=setup_state()
    def analyst(*args,**kwargs):
        result=response()
        result['investigations']=[{'kind':'grouped_missing','columns':['c0001'],'params':{'group_by':['c0002']}}]
        return result
    evidence={'id':'ev_grouped','kind':'grouped_missing','columns':['c0001'],'summary':'집단 a의 결측값은 0건이다.'}
    with patch('studio.analysis.investigate',return_value=[evidence]) as check:
        Processor(FakeRepo(),analyst).reason({},state,frame,'deep')
    assert check.call_count==1
    assert state['ai_status']=='completed'


def test_additional_check_is_saved_without_an_automatic_second_model_call():
    frame,state=setup_state()
    calls=[]
    def analyst(*args,**kwargs):
        calls.append(1)
        result=response()
        result['investigations']=[{'kind':'grouped_missing','columns':['c0001'],'params':{'group_by':['c0002']}}]
        return result
    evidence={'id':'ev_grouped','kind':'grouped_missing','columns':['c0001'],'summary':'집단별 결측률을 계산했다.'}
    with patch('studio.analysis.investigate',return_value=[evidence]) as check:
        Processor(FakeRepo(),analyst).reason({},state,frame,'deep')
    assert len(calls)==1
    assert check.call_count==1
    assert any(item['id']=='pending_investigations' for item in state['analysis']['unresolved'])
    assert any(item['id']=='ev_grouped' for item in state['profile']['evidence'])


def test_error_code_is_preserved_and_unvalidated_recipes_are_not_actionable():
    frame,state=setup_state()
    state['recipes']=[{'id':'old'}]
    def analyst(*args,**kwargs): raise CodexError('ChatGPT 로그인이 필요합니다.','not_logged_in',False)
    Processor(FakeRepo(),analyst).reason({},state,frame,'basic')
    assert state['ai_status']=='failed'
    assert state['ai_error_code']=='not_logged_in' and state['ai_retryable'] is False
    assert not state['recipes']
    assert state['profile']['overview']['rows']==3


def test_explicit_unit_and_code_removal_updates_dictionary_and_profile():
    frame,state=setup_state()
    state['schema'][0].update(unit='원',code_values={'1':'정상'})
    state['context']['definitions']['c0001']={'unit':'원','code_values':{'1':'정상'}}
    def analyst(*args,**kwargs):
        result=response()
        result['definitions']={'c0001':{'unit':'','code_values':{},'description':'단위 없는 정규화 점수'}}
        return result
    Processor(FakeRepo(),analyst).reason({},state,frame,'followup')
    assert state['schema'][0]['unit']=='' and state['schema'][0]['code_values']=={}
    assert state['context']['definitions']['c0001']['unit']==''
    assert state['profile']['columns'][0]['unit']==''
