"""Service/Processor integration with a test-only repository and model.

These tests exercise real loading, profiling, cleaning, files and exports.
The in-memory fence models the repository contract; it is not evidence of a live
PostgreSQL transaction or an actual Codex response.
"""
import copy
import hashlib
import json
import tempfile
import unittest
import uuid
import zipfile
from pathlib import Path
from unittest.mock import patch

import pandas as pd

from studio.analysis import ALGORITHM_VERSION
from studio.repository import Conflict
from studio.cleaning import hash_frame
from studio.service import Processor, Service, read_frame, current_version


class FakeRepository:
    """Only tests import this class. No production fallback uses in-memory state."""

    def __init__(self):
        self.states, self.jobs, self.requests = {}, {}, {}
        self.events = []
        self.fail_next_version_publish = False

    def create(self, state):
        self.states[state["id"]] = copy.deepcopy(state)

    def load(self, project_id):
        return copy.deepcopy(self.states[project_id])

    def command(self, project_id, expected_revision, kind, payload=None, mutate=None, request_id=None):
        if request_id in self.requests:
            return self.requests[request_id]
        state = self.load(project_id)
        if state["revision"] != expected_revision:
            raise Conflict("stale revision")
        if any(j["project_id"] == project_id and j["status"] in {"queued", "running"} for j in self.jobs.values()):
            raise Conflict("active job")
        if mutate:
            mutate(state)
        state.update(revision=expected_revision + 1, status="queued", error=None)
        jid = str(uuid.uuid4())
        self.jobs[jid] = dict(id=jid, project_id=project_id, kind=kind, payload=copy.deepcopy(payload or {}),
                              revision=state["revision"], version_id=state["version_id"], status="queued", token=None)
        self.states[project_id] = state
        if request_id:
            self.requests[request_id] = jid
        return jid

    def mutate(self, project_id, expected_revision, kind, callback, cancel=False):
        state = self.load(project_id)
        if state["revision"] != expected_revision:
            raise Conflict("stale revision")
        active = [j for j in self.jobs.values() if j["project_id"] == project_id and j["status"] in {"queued", "running"}]
        if active and not cancel:
            raise Conflict("active job")
        if cancel:
            for job in active:
                job.update(status="canceled", token=None)
        callback(state)
        state["revision"] += 1
        self.states[project_id] = copy.deepcopy(state)
        self.events.append((kind, project_id, state["revision"]))
        return state

    def claim(self):
        for job in self.jobs.values():
            if job["status"] == "queued":
                job.update(status="running", token=str(uuid.uuid4()))
                return copy.deepcopy(job)
        return None

    def publish(self, job, state, final=False, version=None):
        state = copy.deepcopy(state)
        stored_job = self.jobs[job["id"]]
        old = self.states[job["project_id"]]
        if stored_job["status"] != "running" or stored_job["token"] != job["token"]:
            raise Conflict("expired attempt")
        if old["revision"] != job["revision"] or old["version_id"] != job["version_id"] or state["revision"] != job["revision"]:
            raise Conflict("stale result")
        if version is not None and self.fail_next_version_publish:
            self.fail_next_version_publish = False
            raise OSError("simulated transaction failure")
        successor = None
        if final:
            next_kind = state.pop("pending_action", None)
            if next_kind and state.get("status") != "failed":
                if next_kind not in {"reason", "deep"}:
                    raise ValueError("unsupported followup")
                state.update(revision=state["revision"] + 1, status="queued", ai_status="pending")
                successor = dict(id=str(uuid.uuid4()), project_id=state["id"], kind=next_kind,
                                 payload={}, revision=state["revision"], version_id=state["version_id"],
                                 status="queued", token=None)
        # Catch accidental non-serializable calculation state before it reaches JSONB.
        json.dumps(state, ensure_ascii=False, allow_nan=False)
        self.states[state["id"]] = copy.deepcopy(state)
        self.events.append((job["kind"], state["id"], state["revision"]))
        if final:
            stored_job.update(status="failed" if state.get("status") == "failed" else "completed", token=None)
            if successor:
                self.jobs[successor["id"]] = successor
                self.requests["after:" + job["id"]] = successor["id"]


class ConversationModel:
    def __init__(self):
        self.calls = []
        self.fail = False
        self.omit_held_on_finish = False
        self.no_questions = False

    def __call__(self, context, profile, messages, phase="basic", thread_id=None):
        self.calls.append(copy.deepcopy(dict(context=context, profile=profile, messages=messages, phase=phase, thread_id=thread_id)))
        if self.fail:
            raise RuntimeError("모의 AI 연결 실패")
        evidence_id = profile["evidence"][0]["id"]
        answered = any(m["role"] == "user" and "천원" in m["content"] for m in messages)
        original = context.get("dataset_version") == "v0"
        unit = "천원" if original else "원"
        definitions = {"c0003": {"description": "취소 거래를 포함한 거래 금액", "role": "numeric", "unit": unit,
                                      "certainty": "confirmed" if answered else "likely", "basis": "user" if answered else "inference"}} if answered else {}
        recipes = []
        if answered and original:
            recipes = [dict(id="unit-won", operation="unit", columns=["c0003"], params={"factor": 1000, "from_unit": "천원", "to_unit": "원"},
                            reason="사용자가 확인한 금액 단위 통일", evidence_ids=[evidence_id], phase="basic")]
        finishing = phase == "synthesis" or context.get("dialogue_stopped")
        question = None if answered else "금액 단위가 천원인지 확인해 주세요."
        issue_id = "amount-unit"
        if not original:
            question, issue_id = "동일 ID가 반복된 행은 같은 거래인지 확인해 주세요.", "duplicate-meaning"
        unresolved = [{"id": issue_id, "title": "거래 정의 확인", "reason": "추가 업무 정보 필요", "status": "open", "columns": ["c0001"]}] if question else []
        if finishing:
            question = None
            unresolved = [] if self.omit_held_on_finish else copy.deepcopy(context.get("unresolved", []))
        if self.no_questions:
            question, unresolved, recipes = None, [], []
        return dict(summary="확인한 금액 단위와 거래 의미를 반영하였다." if answered else "금액의 단위를 확인하면 거래 규모를 해석할 수 있다.",
                    dataset_description="정상·취소 거래의 금액을 기록한 데이터이다.",
                    context_patch={"observation_unit": "거래 한 건"}, definitions=definitions,
                    findings=[dict(id="amount-unit", title="금액 단위", evidence_ids=[evidence_id], fact=profile["evidence"][0]["summary"],
                                   interpretation="취소 거래의 음수는 유지한다.", recommendation="확인한 단위로 통일한다.")],
                    question=question, question_issue_ids=[issue_id] if question else [],
                    recipes=recipes, investigations=[], resolved_issue_ids=["amount-unit"] if answered else [],
                    decisions=[{"id": "unit-confirmed", "summary": "금액은 천원 단위이며 취소 거래에는 음수를 허용한다.", "scope": "dataset"}] if answered else [],
                    unresolved=unresolved, thread_id=thread_id or "mock-thread-1", model="mock")


def describe_fixture(context,profile,ids):
    return dict(dataset_description='거래 유형과 금액을 기록한 데이터로 보인다.',observation_unit='거래 한 건으로 추정된다.',
                analysis_uses=['거래 유형별 금액을 비교한다.'],source='codex',model='mock',
                columns=[dict(column_id=cid,description='거래에 관한 항목으로 추정된다.',certainty='likely') for cid in ids])


class WorkflowTests(unittest.TestCase):
    RAW = b"id,type,amount\n001,normal,10\n002,cancel,-5\n003,normal,\n004,normal,30\n004,normal,30\n"

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.data_patch = patch("studio.service.DATA", Path(self.directory.name))
        self.data_patch.start()
        self.addCleanup(self.data_patch.stop)
        self.repo = FakeRepository()
        self.model = ConversationModel()
        self.service = Service(self.repo)
        self.processor = Processor(self.repo, self.model, describe_fixture)
        self.pid = self.service.create(self.RAW, "transactions.csv", "거래 현황 분석")

    def drain(self):
        for _ in range(12):
            job = self.repo.claim()
            if job is None:
                return
            self.processor.run(job)
        self.fail("작업이 종료되지 않습니다.")

    def state(self):
        return self.repo.load(self.pid)

    def test_new_upload_gets_deep_quality_evidence_before_first_ai_review(self):
        first_job = self.repo.claim()
        self.assertEqual(first_job["kind"], "diagnose")
        self.processor.run(first_job)
        state = self.state()
        self.assertTrue(state["profile"]["deep"]["performed"])
        kinds = {item["kind"] for item in state["profile"]["evidence"]}
        self.assertIn("missing", kinds)
        self.assertIn("key_duplicates", kinds)
        self.assertEqual(state["version_id"], "v0")
        self.assertEqual(state["lineage"], [])

    def test_existing_project_profile_is_upgraded_before_ai_review(self):
        diagnose = self.repo.claim()
        self.processor.run(diagnose)
        stored = self.repo.states[self.pid]
        stored["profile"]["algorithm_version"] = "1.0"
        stored["profile"]["deep"] = {"performed": False, "checks": [], "skipped": []}
        reason = self.repo.claim()
        self.assertEqual(reason["kind"], "reason")
        self.processor.run(reason)
        state = self.state()
        self.assertEqual(state["profile"]["algorithm_version"], ALGORITHM_VERSION)
        self.assertTrue(state["profile"]["deep"]["performed"])
        self.assertTrue(self.model.calls[-1]["profile"]["deep"]["performed"])

    def answer_and_preview(self):
        self.drain()
        self.service.reply(self.state(), "맞아, 천원 단위야. 취소 거래는 음수로 기록해.")
        self.drain()
        state = self.state()
        self.service.preview(state, state["recipes"])
        self.drain()
        return self.state()

    def test_end_to_end_reply_preview_approval_apply_and_exports(self):
        self.drain()
        initial = self.state()
        self.assertEqual(initial["stage"], "basic_review")
        self.assertEqual(initial["ai_status"], "completed")
        self.assertTrue(initial["analysis"]["question"])
        self.assertEqual(initial["profile"]["overview"]["rows"], 5)
        self.service.reply(initial, "맞아, 천원 단위야. 취소 거래는 음수로 기록해.")
        self.drain()
        replied = self.state()
        self.assertEqual(replied["context"]["definitions"]["c0003"]["unit"], "천원")
        self.assertEqual(replied["context"]["observation_unit"], "거래 한 건")
        self.assertIsNone(replied["analysis"]["question"])
        self.assertNotEqual(replied["context"]["decisions"][0]["summary"], replied["messages"][-2]["content"])
        self.assertEqual(self.model.calls[-1]["thread_id"], "mock-thread-1")
        self.assertEqual(self.model.calls[-1]["context"]["goal"], "거래 현황 분석")
        original = read_frame(replied)
        self.service.preview(replied, replied["recipes"])
        self.drain()
        review = self.state()
        self.assertEqual(review["version_id"], "v0")
        pd.testing.assert_frame_equal(read_frame(review), original)
        self.assertEqual(review["preview"]["impact"]["after"]["rows"], 5)
        first_job = self.service.approve(review)
        second_job = self.service.approve(review)
        self.assertEqual(first_job, second_job)
        self.drain()
        cleaned = self.state()
        self.assertEqual(cleaned["version_id"], "v1")
        self.assertEqual(len(cleaned["lineage"]), 1)
        self.assertEqual(cleaned["schema"][2]["unit"], "원")
        self.assertEqual(read_frame(cleaned).iloc[1]["c0003"], -5000)
        self.assertTrue(pd.isna(read_frame(cleaned).iloc[2]["c0003"]))
        self.assertEqual(hashlib.sha256(Path(cleaned["original_path"]).read_bytes()).hexdigest(), hashlib.sha256(self.RAW).hexdigest())
        self.service.export(cleaned, "팀의 거래 데이터 점검")
        self.drain()
        exported = self.state()
        self.assertEqual(exported["stage"], "outputs")
        self.assertEqual({a["version_id"] for a in exported["artifacts"]}, {"v1"})
        report = Path(next(a["path"] for a in exported["artifacts"] if a["kind"] == "report")).read_text(encoding="utf-8")
        self.assertIn("취소 거래", report)
        self.assertIn("단위 변환", report)
        self.assertTrue(all(Path(a["path"]).exists() for a in exported["artifacts"]))
        bundle = Path(next(a["path"] for a in exported["artifacts"] if a["kind"] == "bundle"))
        with zipfile.ZipFile(bundle) as archive:
            self.assertTrue({"report.html", "dictionary.html", "source.csv", "notebook.ipynb", "manifest.json"}.issubset(archive.namelist()))
            manifest = json.loads(archive.read("manifest.json"))
            self.assertEqual(manifest["version_id"], "v1")
            self.assertEqual(manifest["revision"], exported["revision"])

    def test_deep_fill_and_duplicate_rules_require_a_second_approval(self):
        review = self.answer_and_preview()
        self.service.approve(review)
        self.drain()
        state = self.state()
        self.assertEqual(state["stage"], "deep_review")
        rules = [dict(id="fill", operation="fill_missing", columns=["c0003"], params={"method": "median"}, reason="확인한 대치", evidence_ids=[], phase="deep"),
                 dict(id="dedup", operation="deduplicate", columns=[], params={"keep": "first"}, reason="완전 중복 확인", evidence_ids=[], phase="deep")]
        self.service.preview(state, rules)
        self.drain()
        self.assertEqual(self.state()["version_id"], "v1")
        self.assertEqual(len(read_frame(self.state())), 5)
        self.service.approve(self.state())
        self.drain()
        result = self.state()
        self.assertEqual(result["version_id"], "v2")
        self.assertEqual(len(result["lineage"]), 2)
        self.assertEqual(len(read_frame(result)), 4)
        self.assertEqual(read_frame(result).iloc[2]["c0003"], 20000)
        self.assertEqual(read_frame(result).iloc[1]["c0003"], -5000)

    def test_reply_invalidates_preview_and_stale_approval(self):
        review = self.answer_and_preview()
        self.service.reply(review, "단위를 다시 확인할게. 지금은 보류해줘.")
        self.drain()
        self.assertIsNone(self.state()["preview"])
        with self.assertRaises(Conflict):
            self.service.approve(review)
        with self.assertRaises(Conflict):
            self.service.approve(self.state())
        self.assertEqual(self.state()["version_id"], "v0")

    def test_final_transaction_failure_keeps_previous_version(self):
        review = self.answer_and_preview()
        original = read_frame(review)
        self.service.approve(review)
        self.repo.fail_next_version_publish = True
        self.drain()
        state = self.state()
        self.assertEqual(state["status"], "failed")
        self.assertEqual(state["version_id"], "v0")
        self.assertEqual(len(state["versions"]), 1)
        self.assertEqual(state["lineage"], [])
        self.assertFalse(any(job["kind"] == "reason" and job['version_id']=='v1' for job in self.repo.jobs.values()))
        pd.testing.assert_frame_equal(read_frame(state), original)

    def test_apply_commit_publishes_followup_in_same_state_transition(self):
        review = self.answer_and_preview()
        jid = self.service.approve(review)
        job = self.repo.claim()
        self.assertEqual(job["id"], jid)
        self.processor.run(job)
        committed = self.state()
        self.assertEqual(committed["version_id"], "v1")
        self.assertEqual(committed["status"], "queued")
        self.assertEqual(committed["revision"], job["revision"] + 1)
        self.assertNotIn("pending_action", committed)
        successor = self.repo.jobs[self.repo.requests["after:" + jid]]
        self.assertEqual(successor["kind"], "reason")
        self.assertEqual(successor["version_id"], "v1")
        self.assertEqual(successor["revision"], committed["revision"])
        self.assertEqual(self.repo.jobs[jid]["status"], "completed")
        self.assertEqual(len([j for j in self.repo.jobs.values() if j["status"] == "queued"]), 1)

    def test_clear_diagnosis_advances_to_deep_then_outputs_without_clicks(self):
        self.model.no_questions = True
        self.drain()
        state = self.state()
        self.assertEqual(state["stage"], "outputs")
        self.assertEqual(state["version_id"], "v0")
        self.assertEqual(state["lineage"], [])
        self.assertEqual([job["kind"] for job in self.repo.jobs.values()], ["diagnose", "reason", "deep"])
        self.assertIn("deep", [call["phase"] for call in self.model.calls])

    def test_understanding_is_saved_before_cleaning_and_survives_timeout(self):
        self.model.fail=True
        job=self.repo.claim()
        self.processor.run(job)
        state=self.state()
        self.assertEqual(state['understanding']['status'],'completed')
        self.assertTrue(state['context']['analysis_uses'])
        self.assertEqual(state['status'],'queued')
        self.assertEqual(len(self.model.calls),0)
        self.drain()
        state=self.state()
        self.assertEqual(state['ai_status'],'failed')
        self.assertEqual(state['understanding']['status'],'completed')
        self.assertEqual(len(state['context']['definitions']),3)
        self.assertEqual(current_version(state)['frame_hash'],hash_frame(read_frame(state),state['schema']))

    def test_failed_batch_resumes_only_remaining_columns(self):
        calls=[]
        def fail_second(context,profile,ids):
            calls.append(ids)
            if len(calls)==2:raise RuntimeError('timeout')
            return describe_fixture(context,profile,ids)
        self.processor.describer=fail_second
        with patch('studio.understanding.BATCH_SIZE',2):
            self.drain()
            state=self.state()
            self.assertEqual(state['understanding']['status'],'failed')
            self.assertEqual(len(state['understanding']['completed_columns']),2)
            self.assertEqual(len(self.model.calls),0)
            self.service.retry(state)
            self.drain()
        self.assertEqual(calls,[['c0001','c0002'],['c0003'],['c0003']])
        self.assertEqual(self.state()['understanding']['status'],'completed')

    def test_backfill_preserves_question_and_confirmed_meanings(self):
        self.drain()
        state=self.state()
        state['understanding']={}
        state['context']['definitions']['c0001']={'description':'사용자가 확인한 거래 번호','basis':'user','certainty':'confirmed'}
        self.repo.states[self.pid]=state
        question=state['analysis']['question']
        messages=copy.deepcopy(state['messages'])
        self.service.summarize(state)
        self.drain()
        updated=self.state()
        self.assertEqual(updated['analysis']['question'],question)
        self.assertEqual(updated['messages'],messages)
        self.assertEqual(updated['schema'][0]['description'],'사용자가 확인한 거래 번호')
        self.assertEqual(updated['status'],'needs_input')

    def test_user_finish_holds_unanswered_issue_and_synthesizes_before_outputs(self):
        review = self.answer_and_preview()
        self.service.approve(review)
        self.drain()
        reviewing = self.state()
        self.assertEqual(reviewing["stage"], "deep_review")
        self.assertEqual(reviewing["status"], "needs_input")
        jid = self.service.advance(reviewing)
        requested = self.state()
        self.assertEqual(self.repo.jobs[jid]["kind"], "finish")
        self.assertTrue(requested["context"]["dialogue_stopped"])
        self.assertEqual(requested["context"]["unresolved"][0]["status"], "held")
        self.assertEqual(requested["stage"], "deep_review")
        self.drain()
        finished = self.state()
        self.assertEqual(self.model.calls[-1]["phase"], "synthesis")
        self.assertEqual(finished["stage"], "outputs")
        self.assertIsNone(finished["analysis"]["question"])
        self.assertEqual(finished["context"]["unresolved"][0]["status"], "held")
        self.assertEqual(len(finished["lineage"]), 1)

    def test_synthesis_cannot_erase_user_held_issue_by_omitting_it(self):
        review = self.answer_and_preview()
        self.service.approve(review)
        self.drain()
        self.model.omit_held_on_finish = True
        self.service.advance(self.state())
        self.drain()
        held = {item["id"]: item for item in self.state()["context"]["unresolved"]}
        self.assertIn("duplicate-meaning", held)
        self.assertEqual(held["duplicate-meaning"]["status"], "held")

    def test_restore_reloads_values_unit_schema_and_lineage_together(self):
        review = self.answer_and_preview()
        original = read_frame(review)
        self.service.approve(review)
        self.drain()
        self.service.restore(self.state(), "v0")
        restored = self.state()
        self.assertEqual(restored["version_id"], "v0")
        self.assertEqual(restored["schema"][2]["unit"], "천원")
        self.assertEqual(restored["context"]["definitions"]["c0003"]["unit"], "천원")
        self.assertEqual(restored["lineage"], [])
        self.assertEqual(restored["recipes"], [])
        pd.testing.assert_frame_equal(read_frame(restored), original)

    def test_restore_reopens_review_and_archives_issues_from_previous_version(self):
        review = self.answer_and_preview()
        self.service.approve(review)
        self.drain()
        self.service.advance(self.state())
        self.drain()
        closed = self.state()
        self.assertTrue(closed["context"]["dialogue_stopped"])
        self.assertEqual(closed["version_id"], "v1")
        self.repo.states[self.pid]["context"]["held_issue_ids"] = ["duplicate-meaning", "old-column-issue"]
        self.repo.states[self.pid]["context"]["unresolved"].append(
            {"id": "old-column-issue", "title": "과거 파생 컬럼 확인", "columns": ["c0999"], "status": "held"})
        self.repo.states[self.pid]["context"]["decisions"].append(
            {"id": "project-purpose", "scope": "project", "summary": "지역별 거래 현황을 비교한다."})
        previous = self.state()
        self.service.restore(previous, "v0")
        restored = self.state()
        self.assertFalse(restored["context"]["dialogue_stopped"])
        self.assertNotIn("review_closed_at", restored)
        self.assertEqual(restored["context"]["unresolved"], [])
        self.assertEqual(restored["context"]["held_issue_ids"], [])
        history = restored["context"]["review_history"][-1]
        self.assertEqual(history["version_id"], "v1")
        self.assertEqual(history["restored_to"], "v0")
        self.assertEqual(history["unresolved"], previous["context"]["unresolved"])
        self.assertEqual(history["held_issue_ids"], previous["context"]["held_issue_ids"])
        self.assertEqual(restored["context"]["decisions"][0]["id"], "project-purpose")
        self.service.reply(restored, "이 버전의 데이터로 다시 확인해 줘.")
        self.drain()
        self.assertFalse(self.model.calls[-1]["context"]["dialogue_stopped"])
        self.assertEqual(self.model.calls[-1]["context"]["dataset_version"], "v0")
        self.assertEqual(self.model.calls[-1]["phase"], "followup")
        self.assertNotIn("old-column-issue", self.model.calls[-1]["context"]["held_issue_ids"])

    def test_reply_after_finish_reopens_same_phase_and_preserves_valid_holds(self):
        review = self.answer_and_preview()
        self.service.approve(review)
        self.drain()
        self.service.advance(self.state())
        self.drain()
        closed = self.state()
        self.assertEqual(closed["stage"], "outputs")
        self.repo.states[self.pid]["context"]["held_issue_ids"] = ["existing-hold"]
        self.service.reply(self.state(), "추가 정보를 확인했어. 다른 품질 문제도 이어서 검토해 줘.")
        queued = self.state()
        self.assertFalse(queued["context"]["dialogue_stopped"])
        self.assertEqual(queued["stage"], "deep_review")
        self.assertNotIn("review_closed_at", queued)
        self.assertEqual(queued["context"]["held_issue_ids"], ["existing-hold"])
        self.assertEqual(queued["context"]["unresolved"], closed["context"]["unresolved"])
        self.assertIsNone(queued["preview"])
        self.assertEqual(queued["version_id"], "v1")
        self.drain()
        self.assertFalse(self.model.calls[-1]["context"]["dialogue_stopped"])
        self.assertEqual(self.model.calls[-1]["context"]["review_phase"], "deep")
        self.assertEqual(self.model.calls[-1]["phase"], "followup")

    def test_ai_failure_retains_profile_and_user_answer(self):
        self.drain()
        before = copy.deepcopy(self.state()["profile"])
        self.model.fail = True
        self.service.reply(self.state(), "금액 단위는 천원이야")
        self.drain()
        failed = self.state()
        self.assertEqual(failed["ai_status"], "failed")
        self.assertEqual(failed["status"], "partial")
        self.assertEqual(failed["profile"], before)
        self.assertEqual(failed["messages"][-1]["content"], "금액 단위는 천원이야")
        self.model.fail = False
        self.service.retry(failed)
        self.drain()
        self.assertEqual(self.state()["ai_status"], "completed")

    def test_response_provenance_cannot_overwrite_dataset_context(self):
        self.repo.states[self.pid]["source_info"] = {"source": "기능 확인용 합성 데이터", "collection_period": "2026년 8월"}
        explicit_source = None
        def analyst(context, profile, messages, phase="basic", thread_id=None):
            result = self.model(context, profile, messages, phase, thread_id)
            result.update(source="codex", goal="응답 메타정보", collection_period="응답 생성 기간",
                          observation_unit="응답 메타정보의 단위")
            if explicit_source is not None:
                result["context_patch"]["source"] = explicit_source
            return result
        self.processor.analyst = analyst
        self.drain()
        diagnosed = self.state()
        self.assertEqual(diagnosed["analysis"]["source"], "codex")
        self.assertEqual(diagnosed["context"]["source"], "기능 확인용 합성 데이터")
        self.assertEqual(diagnosed["goal"], "거래 현황 분석")
        self.assertEqual(diagnosed["context"]["collection_period"], "2026년 8월")
        self.assertEqual(diagnosed["context"]["observation_unit"], "거래 한 건")
        self.assertEqual(diagnosed["context"]["dataset_description"], diagnosed["analysis"]["dataset_description"])
        explicit_source = "사용자가 확인한 원천 시스템"
        self.service.reply(diagnosed, "출처를 원천 시스템으로 정정해 주세요.")
        self.drain()
        self.assertEqual(self.state()["context"]["source"], explicit_source)
        self.assertEqual(self.state()["analysis"]["source"], "codex")

    def test_canceled_job_cannot_publish_late_result(self):
        job = self.repo.claim()
        snapshot = self.state()
        self.service.cancel(snapshot)
        with self.assertRaises(Conflict):
            self.repo.publish(job, snapshot, final=True)
        with self.assertRaises(Conflict):
            self.processor.run(job)
        self.assertEqual(self.state()["status"], "canceled")
        self.assertEqual(self.state()["version_id"], "v0")

    def test_reclaimed_attempt_rejects_previous_token(self):
        old_job = self.repo.claim()
        old_state = self.state()
        self.repo.jobs[old_job["id"]].update(status="queued", token=None)
        new_job = self.repo.claim()
        self.assertNotEqual(old_job["token"], new_job["token"])
        with self.assertRaises(Conflict):
            self.repo.publish(old_job, old_state, final=True)
        self.processor.run(new_job)
        self.drain()
        self.assertEqual(self.state()["ai_status"], "completed")

    def test_preview_error_does_not_modify_current_frame(self):
        self.drain()
        original = read_frame(self.state())
        invalid = dict(id="bad-log", operation="log", columns=["c0003"], params={"base": 10}, reason="시험", evidence_ids=[], phase="deep")
        self.service.preview(self.state(), [invalid])
        self.drain()
        failed = self.state()
        self.assertEqual(failed["status"], "failed")
        self.assertIsNone(failed["preview"])
        self.assertEqual(failed["version_id"], "v0")
        pd.testing.assert_frame_equal(read_frame(failed), original)

    def test_registered_version_file_tampering_is_detected_before_use(self):
        self.drain()
        state = self.state()
        Path(state["versions"][0]["path"]).write_bytes(b"untrusted bytes")
        with self.assertRaisesRegex(ValueError, "변경"):
            read_frame(state)


if __name__ == "__main__":
    unittest.main()
