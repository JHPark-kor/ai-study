"""User-facing ingest, diagnosis, and evidence contracts (FR-01/02/04/05/06/12)."""
import io
import json
import zipfile
import unittest

import numpy as np
import pandas as pd
from openpyxl import Workbook

from studio.analysis import (investigate, load_dataset, missing_mask, profile_dataset,
                             read_metadata, standalone_loader_source)
from studio.analysis_loader import inspect_archive


class PreservedIngestTests(unittest.TestCase):
    def test_duplicate_headers_id_and_literal_null_tokens_survive(self):
        raw = "고객ID,금액,금액,\n00123,10,NA,\n00124,,null, \n".encode("utf-8-sig")
        frame, schema, ingest = load_dataset(raw, "실험.csv")
        self.assertEqual(frame.columns.tolist(), ["c0001", "c0002", "c0003", "c0004"])
        self.assertEqual(ingest["raw_headers"], ["고객ID", "금액", "금액", ""])
        self.assertEqual(frame.iloc[0, 0], "00123")
        self.assertEqual(frame.iloc[0, 2], "NA")
        self.assertEqual(frame.iloc[1, 2], "null")
        self.assertTrue(schema[1]["duplicate_header"])
        self.assertEqual(schema[0]["role"], "id")
        self.assertEqual(missing_mask(frame["c0004"]).tolist(), [True, False])
        self.assertEqual(ingest["source_sha256"], __import__("hashlib").sha256(raw).hexdigest())

    def test_encoding_separator_and_multiline_quote(self):
        raw = '지역;메모\r\n서울;"둘째 줄\n유지"\r\n부산;정상\r\n'.encode("cp949")
        frame, schema, ingest = load_dataset(raw, "data.csv", {"separator": ";"})
        self.assertEqual(ingest["encoding"], "cp949")
        self.assertEqual(frame.iloc[0, 1], "둘째 줄\n유지")
        self.assertEqual(len(frame), 2)

    def test_extra_fields_are_not_silently_lost(self):
        with self.assertRaises(ValueError):
            load_dataset(b"a,b\n1,2,3\n4,5,6\n", "bad.csv")

    def test_xlsx_displayed_zero_and_formula_are_preserved(self):
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "원본"
        sheet.append(["고객ID", "합계", "code"])
        sheet.append([123, "=1+2", "0007"])
        sheet["A2"].number_format = "00000"
        sheet.append([124, 3, "0008"])
        output = io.BytesIO()
        workbook.save(output)
        frame, schema, ingest = load_dataset(output.getvalue(), "test.xlsx")
        self.assertEqual(frame.iloc[0, 0], "00123")
        self.assertEqual(frame.iloc[0, 1], "=1+2")
        self.assertEqual(ingest["formula_cells"], 1)
        self.assertEqual(ingest["display_zero_preserved"], 1)
        self.assertIn("00000", schema[0]["number_formats"])
        self.assertTrue(any("복원할 수 없습니다" in message for message in ingest["warnings"]))

    def test_notebook_loader_reproduces_source_frame_and_schema(self):
        raw = b"id,value\n001,0.10\n002,\n"
        frame, schema, ingest = load_dataset(raw, "data.csv")
        namespace = {"__name__": "__notebook__"}
        exec(compile(standalone_loader_source(), "loader.py", "exec"), namespace)
        repeated, repeated_schema, repeated_ingest = namespace["load_dataset"](raw, "data.csv", ingest["settings"])
        pd.testing.assert_frame_equal(frame, repeated)
        self.assertEqual(schema, repeated_schema)
        self.assertEqual(ingest, repeated_ingest)

    def test_excel_blank_last_header_does_not_drop_data(self):
        workbook = Workbook()
        sheet = workbook.active
        sheet.append(["ID", None])
        sheet.append(["001", 15])
        output = io.BytesIO()
        workbook.save(output)
        frame, schema, ingest = load_dataset(output.getvalue(), "blank_header.xlsx")
        self.assertEqual(ingest["raw_headers"], ["ID", ""])
        self.assertEqual(frame.iloc[0, 1], 15)
        self.assertEqual(schema[1]["name"], "")

    def test_delimited_text_and_tsv_are_loaded_without_changing_values(self):
        text_frame, _, text_ingest = load_dataset("id|값\n001|NA\n002|\n".encode(), "data.txt")
        tsv_frame, _, _ = load_dataset("id\t값\n001\t10\n".encode(), "data.tsv")
        self.assertEqual(text_ingest["separator"], "|")
        self.assertEqual(text_frame.iloc[0].tolist(), ["001", "NA"])
        self.assertEqual(text_frame.iloc[1, 1], "")
        self.assertEqual(tsv_frame.iloc[0].tolist(), ["001", "10"])

    def test_dense_arff_uses_declared_columns_and_native_missing_marker(self):
        raw = b"@RELATION cards\n@ATTRIBUTE id STRING\n@ATTRIBUTE amount NUMERIC\n@ATTRIBUTE class {ok,bad}\n@DATA\n'001',10,ok\n'002',?,bad\n"
        frame, schema, ingest = load_dataset(raw, "cards.arff")
        self.assertEqual([column["name"] for column in schema], ["id", "amount", "class"])
        self.assertTrue(pd.isna(frame.iloc[1, 1]))
        self.assertEqual(ingest["relation"], "cards")
        self.assertTrue(any("결측 표시" in warning for warning in ingest["warnings"]))

    def test_time_series_ts_is_expanded_reproducibly(self):
        raw = b"@problemName demo\n@timestamps false\n@univariate true\n@classLabel true A B\n@data\n1,2,3:A\n4,5:B\n"
        frame, schema, ingest = load_dataset(raw, "series.ts")
        self.assertEqual([column["name"] for column in schema], ["series_1_t1", "series_1_t2", "series_1_t3", "class"])
        self.assertEqual(frame.iloc[0].tolist(), ["1", "2", "3", "A"])
        self.assertTrue(pd.isna(frame.iloc[1, 2]))
        self.assertEqual(ingest["format"], "time-series-ts")

    def test_zip_lists_supported_members_and_loads_selected_member(self):
        output = io.BytesIO()
        with zipfile.ZipFile(output, "w") as archive:
            archive.writestr("notes/readme.md", "ignore")
            archive.writestr("first.csv", "id,value\n001,10\n")
            archive.writestr("nested/second.tsv", "id\tvalue\n002\t20\n")
        raw = output.getvalue()
        self.assertEqual([item["name"] for item in inspect_archive(raw)], ["first.csv", "nested/second.tsv"])
        frame, _, ingest = load_dataset(raw, "bundle.zip", {"archive_member": "nested/second.tsv"})
        self.assertEqual(frame.iloc[0].tolist(), ["002", "20"])
        self.assertEqual(ingest["archive_member"], "nested/second.tsv")
        self.assertEqual(ingest["source_sha256"], __import__("hashlib").sha256(raw).hexdigest())
        namespace = {"__name__": "__notebook__"}
        exec(compile(standalone_loader_source(), "loader.py", "exec"), namespace)
        repeated, repeated_schema, repeated_ingest = namespace["load_dataset"](raw, "bundle.zip", ingest["settings"])
        pd.testing.assert_frame_equal(frame, repeated)
        self.assertEqual(ingest, repeated_ingest)

    def test_zip_requires_a_choice_when_it_contains_multiple_data_files(self):
        output = io.BytesIO()
        with zipfile.ZipFile(output, "w") as archive:
            archive.writestr("a.csv", "id\n1\n")
            archive.writestr("b.csv", "id\n2\n")
        with self.assertRaisesRegex(ValueError, "선택"):
            load_dataset(output.getvalue(), "bundle.zip")


class ProfileTests(unittest.TestCase):
    def test_real_numbers_match_reference_and_source_is_unchanged(self):
        frame, schema, _ = load_dataset(b"amount,label\n1,A\n2,A\n3,B\n100,B\n,\n", "test.csv")
        before = frame.copy(deep=True)
        profile = profile_dataset(frame, schema)
        numeric = profile["columns"][0]
        values = pd.Series([1., 2., 3., 100.])
        self.assertEqual(numeric["stats"]["mean"], values.mean())
        self.assertEqual(numeric["stats"]["std"], values.std(ddof=1))
        self.assertEqual(numeric["stats"]["iqr_candidates"], 1)
        self.assertEqual(sum(row["count"] for row in numeric["histogram"]), 4)
        self.assertEqual(numeric["chart"]["excluded_missing"], 1)
        self.assertEqual(profile["overview"]["missing_cells"], 2)
        pd.testing.assert_frame_equal(frame, before)
        json.dumps(profile, allow_nan=False)

    def test_all_missing_constant_and_nonfinite_are_explicit(self):
        frame = pd.DataFrame({"c0001": ["", ""], "c0002": ["5", "5"], "c0003": ["inf", "-inf"]})
        schema = [{"id": key, "name": key, "original_name": key, "role": "numeric"} for key in frame]
        profile = profile_dataset(frame, schema)
        first, constant, nonfinite = profile["columns"]
        self.assertIsNone(first["stats"]["mean"])
        self.assertEqual(first["histogram"], [])
        self.assertIsNone(constant["stats"]["skew"])
        self.assertEqual(constant["stats"]["std"], 0)
        self.assertEqual(nonfinite["stats"]["nonfinite"], 2)
        self.assertIsNone(nonfinite["stats"]["mean"])
        json.dumps(profile, allow_nan=False)

    def test_pca_negative_is_a_fact_not_a_range_error(self):
        frame, schema, _ = load_dataset(b"V1,V2\n-2,1\n-1,2\n0,3\n1,4\n2,5\n", "pca.csv")
        profile = profile_dataset(frame, schema, {"definitions": {"c0001": {"description": "PCA 변환값", "allow_negative": True}}})
        negative = next(ev for ev in profile["evidence"] if ev["kind"] == "negative_values")
        self.assertEqual(negative["severity"], "info")
        self.assertTrue(negative["details"]["allow_negative"])
        self.assertFalse(any(ev["kind"] == "rule_check" for ev in profile["evidence"]))

    def test_explicit_date_role_tracks_failed_parsing_separately(self):
        frame, schema, _ = load_dataset("예약일,종료일\n2024-01-01,2024-01-02\n2099/01/01,2099/01/02\n잘못된날짜,2024-01-01\n,\n".encode(), "dates.csv")
        context = {"definitions": {"c0001": {"role": "datetime"}, "c0002": {"role": "datetime"}}}
        profile = profile_dataset(frame, schema, context)
        column = profile["columns"][0]
        self.assertEqual(column["missing"], 1)
        self.assertEqual(column["stats"]["parse_failures"], 1)
        self.assertEqual(column["stats"]["future"], 1)
        self.assertTrue(all(ev["kind"] != "future_error" for ev in profile["evidence"]))
        json.dumps(profile, allow_nan=False)

    def test_roles_can_change_without_changing_the_uploaded_values(self):
        frame, schema, _ = load_dataset(b"Class,amount\n0,10\n1,20\n0,30\n", "test.csv")
        profile = profile_dataset(frame, schema, {"definitions": {"c0001": {"role": "categorical"}}})
        self.assertEqual(profile["columns"][0]["role"], "categorical")
        self.assertIn("frequency", profile["columns"][0])
        self.assertEqual(frame["c0001"].tolist(), ["0", "1", "0"])
        self.assertEqual(schema[0]["role"], "numeric")

    def test_rare_categories_include_value_count_and_both_denominators(self):
        values = ["일반"] * 199 + ["희소"]
        frame = pd.DataFrame({"c0001": values})
        schema = [{"id": "c0001", "name": "등급", "original_name": "등급", "role": "categorical"}]
        column = profile_dataset(frame, schema)["columns"][0]
        self.assertEqual(column["stats"]["rare_categories"], 1)
        self.assertEqual(column["stats"]["rare_rows"], 1)
        self.assertEqual(column["rare_frequency"], [{
            "value": "희소", "value_truncated": False, "count": 1,
            "rate_valid": .005, "rate_all": .005,
        }])

    def test_date_format_confirmation_resolves_ambiguous_interpretation(self):
        frame, schema, _ = load_dataset(b"date\n01/02/2024\n03/04/2024\n", "test.csv")
        preliminary = profile_dataset(frame, schema)
        self.assertEqual(preliminary["columns"][0]["stats"]["ambiguous_dates"], 2)
        confirmed = profile_dataset(frame, schema, {"definitions": {"c0001": {"date_format": "%d/%m/%Y"}}})
        self.assertEqual(confirmed["columns"][0]["stats"]["ambiguous_dates"], 0)
        self.assertTrue(confirmed["columns"][0]["stats"]["start"].startswith("2024-02-01"))

    def test_duplicate_columns_are_candidates_not_deletions(self):
        frame, schema, _ = load_dataset(b"net,gross,other\n1,1,3\n2,2,4\n", "test.csv")
        profile = profile_dataset(frame, schema)
        duplicates = [e for e in profile["evidence"] if e["kind"] == "identical_columns"]
        self.assertEqual(duplicates[0]["columns"], ["c0001", "c0002"])
        self.assertEqual(duplicates[0]["details"]["semantic_duplicate"], "미확정")
        self.assertEqual(len(frame.columns), 3)


class MetadataTests(unittest.TestCase):
    def setUp(self):
        _, self.schema, _ = load_dataset(b"id,amount,amount, Region \n001,1,1,Seoul\n", "test.csv")

    def test_duplicate_normalized_and_unmatched_definitions_are_not_auto_applied(self):
        document = [{"컬럼명": "amount", "단위": "KRW"}, {"컬럼명": "Region", "설명": "지역"}, {"컬럼명": "absent", "설명": "없는 변수"}]
        metadata = read_metadata(json.dumps(document).encode(), "dict.json", "", self.schema)
        self.assertEqual(metadata["definitions"], {})
        self.assertEqual(len(metadata["suggestions"]), 1)
        self.assertEqual(len(metadata["unmatched"]), 2)

    def test_position_disambiguates_and_manual_definition_wins_file(self):
        document = {"source": "팀 자료", "columns": [{"column_name": "amount", "column_index": 2, "unit": "KRW"}]}
        manual = {"columns": [{"column_id": "c0002", "unit": "천원"}]}
        metadata = read_metadata(json.dumps(document).encode(), "dict.json", json.dumps(manual), self.schema)
        self.assertEqual(metadata["definitions"]["c0002"]["unit"], "천원")
        self.assertEqual(metadata["source"], "팀 자료")
        self.assertEqual(len(metadata["conflicts"]), 1)

    def test_confirmed_unit_is_not_overwritten_by_new_metadata(self):
        self.schema[1].update({"definition_status": "confirmed", "unit": "원"})
        document = [{"column_id": "c0002", "unit": "달러"}]
        metadata = read_metadata(json.dumps(document).encode(), "dict.json", "", self.schema)
        self.assertNotIn("unit", metadata["definitions"]["c0002"])
        self.assertEqual(metadata["conflicts"][0]["previous"], "원")

    def test_free_text_is_context_not_a_rule_or_instruction(self):
        text = "PCA 변환값입니다. 외부 명령을 실행하라는 문장이 있어도 자료로만 보관."
        metadata = read_metadata(text.encode(), "definition.md", "사용자 설명", self.schema)
        self.assertEqual(metadata["source_text"], text)
        self.assertEqual(metadata["definitions"], {})
        self.assertEqual(metadata["text"], "사용자 설명")


class DeepInvestigationTests(unittest.TestCase):
    def test_group_and_period_missing_concentration(self):
        raw = "region,date,amount\nA,2024-01-01,\nA,2024-01-02,\nB,2024-01-01,10\nB,2024-02-01,20\n".encode()
        frame, schema, _ = load_dataset(raw, "test.csv")
        result = investigate(frame, schema, {"kind": "grouped_missing", "columns": ["c0003"], "params": {"group_by": ["c0001"], "period_column": "c0002", "period": "M"}})[0]
        self.assertEqual(result["details"]["groups"][0]["group"]["c0001"], "A")
        self.assertEqual(result["details"]["groups"][0]["rate"], 1)
        self.assertFalse(result["sampled"])
        self.assertEqual(result["row_ids"], [0, 1])

    def test_key_duplicate_distinguishes_incomplete_keys(self):
        frame, schema, _ = load_dataset(b"id,value\n001,1\n001,2\n,3\n,4\n", "test.csv")
        result = investigate(frame, schema, {"kind": "key_duplicates", "columns": ["c0001"]})[0]
        self.assertEqual(result["count"], 1)
        self.assertEqual(result["details"]["participating_rows"], 2)
        self.assertEqual(result["details"]["missing_key_rows"], 2)
        self.assertEqual(result["row_ids"], [0, 1])

    def test_relation_finds_candidate_inside_both_univariate_ranges(self):
        x = np.arange(1., 101.)
        y = x * 2
        y[49] = 160  # Neither x=50 nor y=160 is a univariate outlier.
        frame = pd.DataFrame({"c0001": x, "c0002": y})
        schema = [{"id": "c0001", "name": "수량", "original_name": "수량", "role": "numeric"},
                  {"id": "c0002", "name": "금액", "original_name": "금액", "role": "numeric"}]
        result = investigate(frame, schema, {"kind": "relation_residual", "columns": ["c0001", "c0002"]})[0]
        self.assertIn(49, result["row_ids"])
        basic = profile_dataset(frame, schema)
        self.assertEqual(basic["columns"][1]["stats"]["iqr_candidates"], 0)
        self.assertIn("후보", result["details"]["interpretation"])

    def test_date_order_and_explicit_range_have_problem_rows(self):
        frame, schema, _ = load_dataset(b"start,end,value\n2024-02-01,2024-01-01,-2\n2024-01-01,2024-02-01,2\n", "test.csv")
        dates = investigate(frame, schema, {"kind": "date_order", "columns": ["c0001", "c0002"]})[0]
        rule = investigate(frame, schema, {"kind": "rule_check", "columns": ["c0003"], "params": {"min": 0}})[0]
        self.assertEqual(dates["row_ids"], [0])
        self.assertEqual(rule["row_ids"], [0])
        self.assertEqual(dates["count"], 1)

    def test_sample_is_reproducible_and_not_extrapolated(self):
        size = 51_000
        frame = pd.DataFrame({"c0001": ["A", "B"] * (size // 2), "c0002": ["", "1"] * (size // 2)})
        schema = [{"id": cid, "name": cid, "original_name": cid, "role": "categorical"} for cid in frame]
        request = {"kind": "grouped_missing", "columns": ["c0002"], "params": {"group_by": ["c0001"]}}
        first, second = investigate(frame, schema, request)[0], investigate(frame, schema, request)[0]
        self.assertEqual(first["id"], second["id"])
        self.assertTrue(first["sampled"])
        self.assertEqual(first["details"]["examined_rows"], 50_000)
        self.assertEqual(first["total_rows"], size)
        self.assertLess(first["count"], 25_500)

    def test_whitelist_rejects_code_and_unknown_columns(self):
        frame, schema, _ = load_dataset(b"a,b\n1,2\n", "test.csv")
        with self.assertRaises(ValueError):
            investigate(frame, schema, {"kind": "python", "columns": ["c0001"], "code": "raise RuntimeError()"})
        with self.assertRaises(ValueError):
            investigate(frame, schema, {"kind": "rows", "columns": ["missing"]})

    def test_automatic_deep_is_bounded_and_serializable(self):
        data = {"region": ["A", "B"] * 30, "date": ["2024-01-01"] * 60,
                "sensor_id": [str(i // 2) for i in range(60)],
                "amount": ["" if i % 3 == 0 else str(i) for i in range(60)],
                "quantity": [str(i + 1) for i in range(60)]}
        raw = pd.DataFrame(data).to_csv(index=False).encode()
        frame, schema, _ = load_dataset(raw, "test.csv")
        profile = profile_dataset(frame, schema, deep=True)
        self.assertTrue(profile["deep"]["performed"])
        self.assertLessEqual(len(profile["deep"]["checks"]), 20)
        kinds = {item["kind"] for item in profile["deep"]["checks"]}
        self.assertTrue({"grouped_missing", "key_duplicates", "correlation", "time_profile"}.issubset(kinds))
        json.dumps(profile, allow_nan=False)

    def test_quality_baseline_is_derived_from_each_new_dataset(self):
        sales = pd.DataFrame({
            "store": ["A", "A", "B", "B"],
            "sales": ["10", "", "30", ""],
            "visitors": ["2", "", "6", "8"],
        }).to_csv(index=False).encode()
        patients = pd.DataFrame({
            "patient_id": ["P1", "P2", "P3", "P4"],
            "ward": ["I", "I", "O", "O"],
            "temperature": ["36.5", "", "38.1", ""],
            "discharged_at": ["2026-01-01", "", "2026-01-03", ""],
        }).to_csv(index=False).encode()

        first_frame, first_schema, _ = load_dataset(sales, "sales.csv")
        second_frame, second_schema, _ = load_dataset(patients, "patients.csv")
        first = profile_dataset(first_frame, first_schema, deep=True)
        second = profile_dataset(second_frame, second_schema, deep=True)

        self.assertTrue(first["deep"]["performed"] and second["deep"]["performed"])
        first_names = {column["name"] for column in first_schema}
        second_names = {column["name"] for column in second_schema}
        self.assertTrue(first_names.isdisjoint(second_names))
        self.assertEqual({column["name"] for column in second["columns"]}, second_names)
        self.assertTrue(any(item["kind"] == "co_missing" for item in second["evidence"]))
        valid_second_ids = {column["id"] for column in second_schema}
        self.assertTrue(all(set(item["columns"]).issubset(valid_second_ids) for item in second["evidence"]))
        self.assertNotIn("sales", json.dumps(second, ensure_ascii=False))


if __name__ == "__main__":
    unittest.main()
