import json
from unittest.mock import patch

import pytest

from studio.ai import AIValidationError, build_context
from studio.understanding import describe, build_packet


PROFILE={"overview":{"rows":15000,"columns":2},"columns":[
    {"id":"c0001","name":"customer_id","role":"id","examples":["001"],"chart":{"raw":"unused"}},
    {"id":"c0002","name":"churn","role":"categorical","examples":[0,1]}],
    "evidence":[{"id":"ev1","kind":"column_profile","columns":["c0001"],"summary":"15,000건",
                 "details":{"chart":{"raw":"unused"}},"row_ids":list(range(100))}]}


def test_bounded_packet_keeps_whole_dataset_context_and_requested_meanings():
    packet=build_packet({"goal":"이탈 특성 분석","password":"secret"},PROFILE,["c0002"])
    assert len(packet['all_columns'])==2
    assert [c['id'] for c in packet['column_details']]==['c0002']
    assert packet['overview']['rows']==15000
    assert 'password' not in packet['context']
    assert 'unused' not in json.dumps(packet)
    compact=build_context({},PROFILE,[],'basic')
    assert compact['profile']['evidence'][0]['id']=='ev1'
    assert 'unused' not in json.dumps(compact)
    assert compact['profile']['columns'][0]['examples']==['001']


@pytest.mark.parametrize('invalid',['missing','duplicate','foreign','empty'])
def test_incomplete_or_invented_definitions_are_never_published(invalid):
    payload={'dataset_description':'고객별 구독과 이탈 현황으로 보인다.','observation_unit':'고객 한 명으로 추정된다.',
             'analysis_uses':['이탈 여부별 이용 현황을 비교할 수 있다.'],
             'columns':[{'column_id':'c0002','description':'고객의 이탈 여부로 추정된다.','certainty':'likely'}]}
    if invalid=='missing':payload['columns']=[]
    if invalid=='duplicate':payload['columns']*=2
    if invalid=='foreign':payload['columns'][0]['column_id']='c0999'
    if invalid=='empty':payload['columns'][0]['description']=''
    class Client:
        def __enter__(self):return self
        def __exit__(self,*a):pass
        def interpret(self,*a,**kw):return {'text':json.dumps(payload)}
    with patch('studio.understanding.CodexClient',Client),pytest.raises(AIValidationError):
        describe({},PROFILE,['c0002'])
