"""Opt-in real PostgreSQL tests use a disposable, uniquely named schema."""
import copy
import os
import uuid

import psycopg
from psycopg import sql
import pytest

from studio.config import connection_kwargs
from studio.repository import Conflict, Repository


@pytest.fixture
def repo():
    if os.getenv('STUDIO_TEST_DATABASE') != '1':
        pytest.skip('Set STUDIO_TEST_DATABASE=1 to validate real PostgreSQL in an isolated test schema.')
    namespace='studio_test_'+uuid.uuid4().hex
    with psycopg.connect(**connection_kwargs()) as conn:
        conn.execute(sql.SQL('CREATE SCHEMA {}').format(sql.Identifier(namespace)))
    def connect():
        conn=psycopg.connect(**connection_kwargs())
        conn.execute(sql.SQL('SET search_path TO {}').format(sql.Identifier(namespace)))
        return conn
    r=Repository(connect);r.initialize()
    try:yield r
    finally:
        assert namespace.startswith('studio_test_') and len(namespace)==44
        with psycopg.connect(**connection_kwargs()) as conn:
            conn.execute(sql.SQL('DROP SCHEMA {} CASCADE').format(sql.Identifier(namespace)))


def project(repo):
    state=dict(id=str(uuid.uuid4()),name='합성 검증',revision=0,version_id='v0',stage='basic_review',status='ready')
    repo.create(state)
    return state


def test_duplicate_request_and_one_active_project(repo):
    state=project(repo)
    jid=repo.command(state['id'],0,'preview',request_id='same')
    assert repo.command(state['id'],0,'preview',request_id='same')==jid
    with pytest.raises(Conflict):repo.command(state['id'],1,'preview')
    assert repo.load(state['id'])['revision']==1


def test_canceled_attempt_cannot_publish(repo):
    state=project(repo);repo.command(state['id'],0,'reason')
    job=repo.claim();old=repo.load(state['id'])
    repo.mutate(state['id'],1,'cancel',lambda s:s.update(status='canceled'),cancel=True)
    with pytest.raises(Conflict):repo.publish(job,old,final=True)
    assert repo.load(state['id'])['status']=='canceled'


def test_expired_worker_lease_fences_late_result(repo):
    state=project(repo);repo.command(state['id'],0,'reason')
    old=repo.claim()
    with repo.connection() as conn:
        conn.execute("UPDATE dpw2_jobs SET heartbeat=now()-interval '90 seconds' WHERE id=%s",(old['id'],))
    new=repo.claim()
    assert new['id']==old['id'] and new['token']!=old['token']
    current=repo.load(state['id']);current['status']='ready'
    with pytest.raises(Conflict):repo.publish(old,current,final=True)
    repo.publish(new,current,final=True)
    assert repo.load(state['id'])['status']=='ready'


def test_version_commit_and_manifest_are_atomic(repo):
    state=project(repo);repo.command(state['id'],0,'apply')
    job=repo.claim();state=repo.load(state['id']);state.update(version_id='v1',status='ready')
    repo.publish(job,state,final=True,version={'id':'v1','parent_id':'v0','synthetic':True})
    assert repo.load(state['id'])['version_id']=='v1'
    with repo.connection() as conn:
        assert conn.execute('SELECT manifest FROM dpw2_dataset_versions WHERE project_id=%s',(state['id'],)).fetchone()[0]['parent_id']=='v0'
    with pytest.raises(Conflict):repo.publish(job,state,final=True)


def test_revision_conflict_does_not_discard_message(repo):
    state=project(repo)
    repo.command(state['id'],0,'reply',mutate=lambda s:s.update(message='첫 답변'))
    with pytest.raises(Conflict):repo.command(state['id'],0,'reply',mutate=lambda s:s.update(message='늦은 답변'))
    assert repo.load(state['id'])['message']=='첫 답변'


def test_followup_enqueued_with_version_commit(repo):
    state=project(repo);repo.command(state['id'],0,'apply')
    job=repo.claim();state=repo.load(state['id'])
    state.update(version_id='v1',status='ready',pending_action='reason')
    repo.publish(job,state,final=True,version={'id':'v1','parent_id':'v0'})
    saved=repo.load(state['id'])
    assert saved['version_id']=='v1' and saved['revision']==2 and saved['status']=='queued'
    assert 'pending_action' not in saved
    next_job=repo.claim()
    assert next_job['kind']=='reason' and next_job['version_id']=='v1' and next_job['revision']==2


def test_invalid_followup_rolls_back_version_pointer(repo):
    state=project(repo);repo.command(state['id'],0,'apply')
    job=repo.claim();state=repo.load(state['id'])
    state.update(version_id='v1',status='ready',pending_action='invalid')
    with pytest.raises(ValueError):repo.publish(job,state,final=True,version={'id':'v1'})
    assert repo.load(state['id'])['version_id']=='v0'
    with repo.connection() as conn:
        assert conn.execute('SELECT count(*) FROM dpw2_dataset_versions').fetchone()[0]==0


def test_project_rename_archive_and_restore_preserve_state(repo):
    state=project(repo)
    renamed=repo.rename_project(state['id'],0,'합성 검증 이름 변경')
    assert renamed['name']=='합성 검증 이름 변경' and renamed['revision']==1
    listed=repo.list_projects()
    assert listed[0]['name']=='합성 검증 이름 변경' and listed[0]['revision']==1
    repo.archive_project(state['id'],1)
    assert not repo.list_projects()
    archived=repo.list_archived_projects()
    assert archived[0]['id']==state['id'] and archived[0]['archived_at'] is not None
    with pytest.raises(ValueError):repo.load(state['id'])
    repo.restore_project(state['id'])
    restored=repo.load(state['id'])
    assert restored['name']=='합성 검증 이름 변경' and restored['revision']==1
