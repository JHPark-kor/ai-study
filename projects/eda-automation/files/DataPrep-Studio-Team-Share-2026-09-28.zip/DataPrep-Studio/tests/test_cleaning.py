import copy
import unittest

import pandas as pd

from studio.analysis import load_dataset
from studio.cleaning import CleaningError, apply_manifest, hash_frame, preview


def rule(operation, columns, params, rid="r1", phase="deep"):
    return dict(id=rid, operation=operation, columns=columns, params=params,
                reason="시험 데이터에서 확인한 처리", evidence_ids=["e1"], phase=phase)


class CleaningTests(unittest.TestCase):
    def setUp(self):
        self.raw = b"id,group,amount,date\n001,A,10,2025-01-01\n002,A,,2025-01-02\n003,A,30,2025-01-03\n004,B,100,2025-01-04\n004,B,100,2025-01-04\n"
        self.frame, self.schema, self.ingest = load_dataset(self.raw, "input.csv")

    def check_replay(self, rules, context=None):
        original = self.frame.copy(deep=True)
        schema = copy.deepcopy(self.schema)
        result = preview(self.frame, self.schema, rules, context)
        replay, replay_schema = apply_manifest(self.frame, self.schema, result["manifest"])
        pd.testing.assert_frame_equal(result["frame"], replay)
        pd.testing.assert_frame_equal(self.frame, original)
        self.assertEqual(schema, self.schema)
        self.assertEqual(replay_schema, result["schema"])
        return result

    def test_cast_and_unit_replay_preserves_original_ids(self):
        rules = [rule("cast", ["c0003"], {"dtype": "numeric"}, "cast"),
                 rule("unit", ["c0003"], {"factor": 1000, "from_unit": "천원", "to_unit": "원"}, "unit")]
        result = self.check_replay(rules)
        self.assertEqual(result["frame"].iloc[0]["c0003"], 10000)
        self.assertEqual(result["frame"].iloc[0]["c0001"], "001")
        self.assertEqual(result["schema"][2]["unit"], "원")

    def test_statistical_fill_is_frozen(self):
        result = self.check_replay([rule("fill_missing", ["c0003"], {"method": "median"})])
        self.assertEqual(result["frame"].iloc[1]["c0003"], 65.0)
        frozen = result["manifest"]["rules"][0]["_frozen_values"][0]
        self.assertEqual(frozen["value"], 65.0)
        self.assertEqual(result["impact"]["after"]["missing_cells"], 0)

    def test_group_fill_uses_group_only(self):
        result = self.check_replay([rule("fill_missing", ["c0003"], {"method": "group_median", "group_by": ["c0002"], "min_group_size": 2})])
        self.assertEqual(result["frame"].iloc[1]["c0003"], 20.0)

    def test_group_without_reference_is_left_missing_or_rejected(self):
        self.frame.loc[0, "c0003"] = ""
        rules = [rule("fill_missing", ["c0003"], {"method": "group_median", "group_by": ["c0002"], "min_group_size": 2})]
        result = self.check_replay(rules)
        self.assertEqual(result["frame"].iloc[1]["c0003"], "")
        rules[0]["params"]["on_unmatched"] = "error"
        with self.assertRaises(CleaningError):
            preview(self.frame, self.schema, rules)

    def test_prediction_requires_fit_scope_and_excludes_evaluation_values(self):
        rules = [rule("fill_missing", ["c0003"], {"method": "median"})]
        with self.assertRaises(CleaningError):
            preview(self.frame, self.schema, rules, {"goal": "금액 예측"})
        rules[0]["params"]["fit_condition"] = {"column": "c0002", "op": "eq", "value": "A"}
        result = self.check_replay(rules, {"goal": "금액 예측"})
        self.assertEqual(result["frame"].iloc[1]["c0003"], 20)

    def test_all_missing_statistic_is_not_silently_zero(self):
        self.frame["c0003"] = ""
        with self.assertRaises(CleaningError):
            preview(self.frame, self.schema, [rule("fill_missing", ["c0003"], {"method": "median"})])

    def test_mode_tie_uses_first_observation(self):
        self.frame["c0002"] = ["Z", "A", "Z", "A", ""]
        result = self.check_replay([rule("fill_missing", ["c0002"], {"method": "mode"})])
        self.assertEqual(result["frame"].iloc[-1]["c0002"], "Z")

    def test_missing_indicator_and_conditional_null(self):
        result = self.check_replay([
            rule("missing_indicator", ["c0003"], {"new_id": "c0005", "new_name": "금액_결측"}, "flag"),
            rule("set_missing", ["c0003"], {"condition": {"column": "c0003", "op": "gt", "value": 90}}, "null")])
        self.assertEqual(list(result["frame"]["c0005"]), [0, 1, 0, 0, 0])
        self.assertTrue(pd.isna(result["frame"].iloc[3]["c0003"]))

    def test_conditional_replace_and_drop_preserve_row_identity(self):
        result = self.check_replay([
            rule("replace", ["c0003"], {"condition": {"column": "c0002", "op": "eq", "value": "A"}, "value": 5}, "replace"),
            rule("drop_rows", [], {"condition": {"all": [{"column": "c0002", "op": "eq", "value": "B"}, {"column": "c0003", "op": "gt", "value": 90}]}}, "drop")])
        self.assertEqual(list(result["frame"].index), [0, 1, 2])
        self.assertEqual(list(result["frame"]["c0003"]), [5, 5, 5])

    def test_clip_and_log_validate_domain(self):
        result = self.check_replay([rule("clip", ["c0003"], {"upper": 50}, "cap"), rule("log", ["c0003"], {"base": 10, "new_id": "c0005", "new_name": "log_amount"}, "log")])
        self.assertEqual(result["frame"].iloc[0]["c0005"], 1.0)
        self.frame.loc[0, "c0003"] = "-1"
        with self.assertRaises(CleaningError):
            preview(self.frame, self.schema, [rule("log", ["c0003"], {})])

    def test_exact_duplicate_removal_requires_keep_rule(self):
        result = self.check_replay([rule("deduplicate", [], {"keep": "first"})])
        self.assertEqual(list(result["frame"].index), [0, 1, 2, 3])
        with self.assertRaises(CleaningError):
            preview(self.frame, self.schema, [rule("deduplicate", [], {})])

    def test_key_duplicates_sort_selection_then_preserve_order(self):
        self.frame.loc[4, "c0003"] = "200"
        result = self.check_replay([rule("cast", ["c0003"], {"dtype": "numeric"}, "cast"), rule("deduplicate", ["c0001"], {"keep": "last", "sort_by": ["c0003"]}, "dedup")])
        self.assertEqual(list(result["frame"].index), [0, 1, 2, 4])

    def test_missing_keys_remain_unless_explicitly_dropped(self):
        self.frame.loc[[0, 1], "c0001"] = ""
        result = self.check_replay([rule("deduplicate", ["c0001"], {"keep": "first", "key_missing": "keep"})])
        self.assertIn(0, result["frame"].index)
        self.assertIn(1, result["frame"].index)

    def test_rename_does_not_change_fixed_ids(self):
        result = self.check_replay([rule("rename", ["c0003"], {"names": {"c0003": "거래금액"}})])
        self.assertEqual(list(result["frame"].columns), list(self.frame.columns))
        self.assertEqual(result["schema"][2]["original_name"], "amount")
        with self.assertRaises(CleaningError):
            preview(self.frame, self.schema, [rule("rename", ["c0003"], {"names": {"c0003": "id"}})])

    def test_duplicate_column_drop_validates_values_and_confirmation(self):
        self.frame["c0005"] = self.frame["c0003"].copy()
        self.schema.append({**self.schema[2], "id": "c0005", "name": "amount_copy"})
        result = self.check_replay([rule("drop_columns", ["c0005"], {"confirmed": True, "duplicate_of": {"c0005": "c0003"}})])
        self.assertNotIn("c0005", result["frame"])
        with self.assertRaises(CleaningError):
            preview(self.frame, self.schema, [rule("drop_columns", ["c0005"], {"confirmed": True, "duplicate_of": {"c0005": "c0002"}})])

    def test_cast_parse_failure_is_counted_and_requires_explicit_coercion(self):
        self.frame.loc[0, "c0003"] = "unknown"
        with self.assertRaises(CleaningError):
            preview(self.frame, self.schema, [rule("cast", ["c0003"], {"dtype": "numeric"})])
        result = self.check_replay([rule("cast", ["c0003"], {"dtype": "numeric", "errors": "coerce"})])
        self.assertEqual(result["impact"]["steps"][0]["details"]["parse_failures"], 1)

    def test_date_format_is_explicit(self):
        with self.assertRaises(CleaningError):
            preview(self.frame, self.schema, [rule("cast", ["c0004"], {"dtype": "datetime"})])
        result = self.check_replay([rule("cast", ["c0004"], {"dtype": "datetime", "format": "%Y-%m-%d"})])
        self.assertEqual(result["schema"][3]["role"], "datetime")

    def test_category_mapping_is_simultaneous_not_chained(self):
        result = self.check_replay([rule("category_map", ["c0002"], {"mapping": [{"from": "A", "to": "B"}, {"from": "B", "to": "C"}]})])
        self.assertEqual(list(result["frame"]["c0002"]), ["B", "B", "B", "C", "C"])

    def test_unknown_operation_params_and_code_are_rejected(self):
        for candidate in [rule("eval", [], {"code": "1+1"}), rule("clip", ["c0003"], {"upper": 5, "exec": "pass"}), rule("drop_rows", [], {"condition": "amount > 3"})]:
            with self.subTest(candidate=candidate), self.assertRaises(CleaningError):
                preview(self.frame, self.schema, [candidate])

    def test_input_tamper_manifest_tamper_and_environment_change_are_rejected(self):
        result = preview(self.frame, self.schema, [rule("clip", ["c0003"], {"upper": 50})])
        changed = self.frame.copy()
        changed.iloc[0, 2] = "11"
        with self.assertRaises(CleaningError):
            apply_manifest(changed, self.schema, result["manifest"])
        modified = copy.deepcopy(result["manifest"])
        modified["rules"][0]["params"]["upper"] = 500
        with self.assertRaises(CleaningError):
            apply_manifest(self.frame, self.schema, modified)
        self.assertNotEqual(hash_frame(changed, self.schema), hash_frame(self.frame, self.schema))


if __name__ == "__main__":
    unittest.main()
