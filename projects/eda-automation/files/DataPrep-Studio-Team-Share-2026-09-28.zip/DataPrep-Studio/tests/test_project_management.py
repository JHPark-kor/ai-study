from pathlib import Path
import datetime as dt
import html

from streamlit.testing.v1 import AppTest

from studio.service import Service


ROOT = Path(__file__).resolve().parents[1]


def management_helpers():
    source = (ROOT / 'app.py').read_text(encoding='utf-8')
    return source[source.index('def recent_project_status('):source.index('\nwith st.sidebar:', source.index('def recent_project_status('))]


def test_recent_project_status_and_date_are_clear():
    scope = {'dt': dt}
    helper_source = management_helpers()
    exec(helper_source[:helper_source.index('\ndef recent_projects_sidebar(')], scope)
    status = scope['recent_project_status']
    shown_date = scope['recent_project_date']
    assert status({'status': 'running'}) == ('진행 중', 'running')
    assert status({'status': 'partial'}) == ('확인 필요', 'failed')
    assert status({'status': 'ready', 'stage': 'outputs'}) == ('완료', 'completed')
    assert status({'status': 'needs_input', 'stage': 'basic_review'}) == ('검토 중', 'review')
    assert shown_date('2026-09-28T01:02:03+00:00').count('.') == 2


def test_recent_work_sidebar_shows_name_file_date_status_and_archive():
    projects = [{
        'id': 'p1', 'name': '문화누리카드 점검', 'revision': 3,
        'filename': 'culture_card.xlsx', 'created_at': '2026-09-28T01:02:03+00:00',
        'status': 'needs_input', 'stage': 'basic_review', 'ai_status': 'completed',
        'understanding_status': 'completed',
    }]
    archived = [{
        'id': 'p2', 'name': '삭제한 점검', 'revision': 1, 'filename': 'old.csv',
        'created_at': '2026-09-27T01:02:03+00:00', 'archived_at': '2026-09-28T02:03:04+00:00',
        'status': 'ready', 'stage': 'outputs', 'ai_status': 'completed',
        'understanding_status': 'completed',
    }]
    script = '\n'.join([
        'import streamlit as st', 'import datetime as dt', 'import html',
        'class Repo:',
        f'    def list_projects(self): return {projects!r}',
        f'    def list_archived_projects(self): return {archived!r}',
        'class Service:',
        '    def rename_project(self,*args): pass',
        '    def archive_project(self,*args): pass',
        '    def restore_project(self,*args): pass',
        management_helpers(),
        'with st.sidebar: recent_projects_sidebar(Repo(),Service())',
    ])
    app = AppTest.from_string(script).run(timeout=30)
    assert not app.exception
    content = '\n'.join(item.value for item in app.markdown)
    assert '문화누리카드 점검' in content
    assert 'culture_card.xlsx' in content
    assert '검토 중' in content
    assert any(expander.label == '삭제한 작업 1개' for expander in app.expander)
    assert any(button.label == '되돌리기' for button in app.button)


class ProjectRepositoryStub:
    def __init__(self):
        self.calls = []

    def rename_project(self, project_id, revision, name):
        self.calls.append(('rename', project_id, revision, name))
        return {'id': project_id, 'name': name}

    def archive_project(self, project_id, revision):
        self.calls.append(('archive', project_id, revision))
        return {'id': project_id}

    def restore_project(self, project_id):
        self.calls.append(('restore', project_id))
        return {'id': project_id}


def test_service_delegates_project_management_without_touching_analysis():
    repo = ProjectRepositoryStub(); service = Service(repo)
    project = {'id': 'p1', 'revision': 7}
    service.rename_project(project, '새 이름')
    service.archive_project(project)
    service.restore_project(project)
    assert repo.calls == [
        ('rename', 'p1', 7, '새 이름'),
        ('archive', 'p1', 7),
        ('restore', 'p1'),
    ]
