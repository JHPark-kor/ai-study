"""Render only the profile section: no database, account, or network dependency."""
from pathlib import Path
from contextlib import contextmanager
import json
import sys
import unittest

from streamlit.testing.v1 import AppTest


@contextmanager
def preserve_test_entrypoint():
    """AppTest replaces __main__; do not let its temporary app become spawn's entrypoint.

    Streamlit's ScriptRunner installs a fresh __main__ module for each app run
    without restoring the test runner's module. Windows multiprocessing reads
    that module when starting a later worker test. Restore the module identities
    and process arguments after every UI test, including assertion failures.
    """
    missing = object()
    modules = {name: sys.modules.get(name, missing) for name in ('__main__', '__mp_main__')}
    argv, paths = sys.argv[:], sys.path[:]
    try:
        yield
    finally:
        for name, module in modules.items():
            if module is missing:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = module
        sys.argv[:] = argv
        sys.path[:] = paths


def profile_script(raw, definitions=None):
    # Keep this test tied to the real section without executing app startup.
    source = (Path(__file__).resolve().parents[1] / "app.py").read_text(encoding="utf-8")
    section = source[source.index("STAT_NAMES="):source.index("\ndef findings(")]
    return "\n".join([
        "import streamlit as st", "import pandas as pd", "import plotly.express as px",
        "import plotly.graph_objects as go", "from studio.analysis import load_dataset, profile_dataset",
        "def section(number, title): st.subheader(title)", "def readable(value): return str(value)",
        f"test_frame, schema, ingest = load_dataset({raw!r}, 'test.csv')",
        "def read_frame(state): return test_frame",
        f"profile = profile_dataset(test_frame, schema, {{'definitions': {definitions or {}!r}}})",
        "state = {'id': 'test', 'schema': schema, 'profile': profile}",
        section, "profiles(state)",
    ])


class ProfileUITests(unittest.TestCase):
    def setUp(self):
        entrypoint = preserve_test_entrypoint()
        entrypoint.__enter__()
        self.addCleanup(entrypoint.__exit__, None, None, None)

    def test_dataset_meaning_and_uses_remain_visible_after_cleaning_failure(self):
        source=(Path(__file__).resolve().parents[1]/'app.py').read_text(encoding='utf-8')
        section_source=source[source.index('def explanation('):source.index('\nSTAT_NAMES=')]
        state={'ai_status':'failed','analysis':{},'schema':[{'id':'c0001','name':'고객번호','role':'id','description':'고객을 식별하는 번호다.'}],
               'understanding':{'status':'completed'},'context':{'dataset_description':'고객별 구독 현황을 기록한 데이터다.',
               'observation_unit':'고객 한 명','analysis_uses':['구독 유형별 이용 행태를 비교할 수 있다.']}}
        script='\n'.join(['import streamlit as st','import pandas as pd','import html',
            'def section(n,t):st.subheader(t)','def readable(v):return str(v)','def polite_analysis_text(v):return str(v)',section_source,f'explanation({state!r})'])
        app=AppTest.from_string(script).run(timeout=30)
        self.assertEqual(len(app.exception),0)
        content='\n'.join(m.value for m in app.markdown)
        self.assertEqual(app.subheader[0].value,'이 데이터는 무엇인가요?')
        self.assertIn('고객별 구독 현황',content)
        self.assertIn('분석에 활용할 수 있어요',content)
        self.assertIn('구독 유형별',content)
        self.assertEqual(app.dataframe[0].value.iloc[0]['의미'],'고객을 식별하는 번호다.')
        self.assertFalse(any(expander.label=='컬럼 설명을 문장으로 읽기' for expander in app.expander))

    def test_review_index_separates_variable_and_value_counts(self):
        app=AppTest.from_string(profile_script(b"amount,group\n1,A\n2,A\n3,A\n100,B\n,B\n")).run(timeout=30)
        self.assertEqual(len(app.exception),0)
        table=next(item.value for item in app.dataframe if item.value.columns.tolist()==['변수','역할','주요 확인 사항','우선순위'])
        self.assertIn('amount',table['변수'].tolist())
        labels=[button.label for button in app.button]
        self.assertTrue(any('결측값 확인' in label and '1개 변수' in label and '1건' in label for label in labels))
        self.assertTrue(any('극단값 후보' in label and '1개 변수' in label for label in labels))
        self.assertFalse(any('희소 범주 후보' in label for label in labels))
        self.assertTrue(any(toggle.label=='모든 변수 보기' and toggle.value is False for toggle in app.toggle))

    def test_saved_dataset_description_uses_the_same_polite_tone(self):
        source=(Path(__file__).resolve().parents[1]/'app.py').read_text(encoding='utf-8')
        section_source=source[source.index('def polite_analysis_text('):source.index('\ndef friendly_issue_title(')]
        scope={'re':__import__('re')}
        exec(section_source,scope)
        original='지역별 이용 현황을 정리한 데이터로 보인다. 한 행은 자치구 집계로 추정된다. 총계 행이 있다. 지역 구분이다. 수집 기준은 명시되지 않았다. 비교 분석에 활용할 수 있다.'
        converted=scope['polite_analysis_text'](original)
        self.assertEqual(converted,'지역별 이용 현황을 정리한 데이터로 보입니다. 한 행은 자치구 집계로 추정됩니다. 총계 행이 있습니다. 지역 구분입니다. 수집 기준은 명시되지 않았습니다. 비교 분석에 활용할 수 있습니다.')

    def test_app_test_entrypoint_does_not_leak_into_worker_spawning(self):
        before = sys.modules['__main__']
        before_file = getattr(before, '__file__', None)
        before_spec = getattr(before, '__spec__', None)
        before_argv = sys.argv[:]
        with preserve_test_entrypoint():
            app = AppTest.from_string('import streamlit as st\nst.write("entrypoint test")').run(timeout=30)
            self.assertEqual(len(app.exception), 0)
        self.assertIs(sys.modules['__main__'], before)
        self.assertEqual(getattr(sys.modules['__main__'], '__file__', None), before_file)
        self.assertIs(getattr(sys.modules['__main__'], '__spec__', None), before_spec)
        self.assertEqual(sys.argv, before_argv)

    def test_numeric_chart_uses_real_whiskers_and_korean_statistics(self):
        app = AppTest.from_string(profile_script(b"amount,label\n1,A\n2,A\n3,B\n100,B\n,\n")).run(timeout=30)
        self.assertEqual(len(app.exception), 0)
        charts = app.get("plotly_chart")
        self.assertEqual(len(charts), 2)
        box = json.loads(charts[1].proto.spec)["data"][0]
        self.assertEqual(box["upperfence"], [3.0])
        stats = next(table.value for table in app.dataframe if "항목" in table.value.columns)
        self.assertIn("표준편차", stats["항목"].tolist())
        self.assertFalse(any("_" in value for value in stats["항목"]))
        self.assertIn("결측률", [metric.label for metric in app.metric])
        self.assertTrue(any("5행 중 4건" in caption.value for caption in app.caption))

    def test_category_frequency_columns_are_readable_and_show_denominators(self):
        app = AppTest.from_string(profile_script(b"region\nA\nA\nB\n\n", {"c0001": {"role": "categorical"}})).run(timeout=30)
        self.assertEqual(len(app.exception), 0)
        self.assertEqual(len(app.get("plotly_chart")), 1)
        table = next(item.value for item in app.dataframe if item.value.columns.tolist() == ["값", "건수", "비결측값 내 비율", "전체 행 대비 비율"])
        self.assertEqual(table.columns.tolist(), ["값", "건수", "비결측값 내 비율", "전체 행 대비 비율"])
        self.assertEqual(table.iloc[0]["비결측값 내 비율"], "66.7%")

    def test_rare_category_values_counts_and_rates_are_visible(self):
        raw=("region\n"+"일반\n"*199+"희소\n").encode()
        app=AppTest.from_string(profile_script(raw,{"c0001":{"role":"categorical"}})).run(timeout=30)
        self.assertEqual(len(app.exception),0)
        content='\n'.join(item.value for item in app.markdown)+"\n"+'\n'.join(item.value for item in app.caption)
        self.assertIn('희소 범주',content)
        rare_tables=[table.value for table in app.dataframe if table.value.columns.tolist()==['값','건수','비결측값 내 비율','전체 행 대비 비율']]
        self.assertTrue(any((table['값']=='희소').any() and table.loc[table['값']=='희소','건수'].iloc[0]==1 for table in rare_tables))

    def test_quality_pattern_copy_explains_multivariate_values(self):
        source=(Path(__file__).resolve().parents[1]/'app.py').read_text(encoding='utf-8')
        section_source=source[source.index('QUALITY_GROUPS='):source.index('\ndef polite_analysis_text(')]
        scope={'html':__import__('html'),'pd':__import__('pandas'),'st':__import__('streamlit'),'read_frame':lambda state:None,
               'section':lambda number,title:None,'polite_analysis_text':lambda value:str(value)}
        exec(section_source,scope)
        title,body=scope['quality_evidence_copy']({
            'kind':'correlation','columns':['c0001','c0002'],'count':None,
            'details':{'pearson':.81234,'spearman':.75,'complete_pairs':128}
        },{'c0001':'이용자수','c0002':'발급매수'})
        self.assertEqual(title,'이용자수, 발급매수의 관계')
        self.assertIn('비결측 쌍 128건',body)
        self.assertIn('피어슨 0.812',body)
        self.assertIn('인과관계를 뜻하지 않습니다',body)

    def test_quality_pattern_tabs_render_missing_duplicates_and_relationships(self):
        source=(Path(__file__).resolve().parents[1]/'app.py').read_text(encoding='utf-8')
        section_source=source[source.index('QUALITY_GROUPS='):source.index('\ndef polite_analysis_text(')]
        state={
            'schema':[{'id':'c0001','name':'지역'},{'id':'c0002','name':'이용자수'},{'id':'c0003','name':'발급매수'}],
            'profile':{
                'overview':{'duplicate_rows':2},
                'columns':[
                    {'id':'c0001','name':'지역','missing':0,'stats':{'rare_categories':1,'rare_rows':1}},
                    {'id':'c0002','name':'이용자수','missing':4,'stats':{'iqr_candidates':2}},
                    {'id':'c0003','name':'발급매수','missing':4,'stats':{}},
                ],
                'evidence':[
                    {'id':'m1','kind':'co_missing','columns':['c0002','c0003'],'count':1,'details':{'pairs':[{'columns':['c0002','c0003'],'both_missing':4}]}},
                    {'id':'d1','kind':'duplicate_rows','columns':['c0001'],'count':2,'details':{'participants':4}},
                    {'id':'r1','kind':'correlation','columns':['c0002','c0003'],'count':None,'details':{'pearson':.8,'spearman':.7,'complete_pairs':20}},
                ],
                'deep':{'performed':True,'checks':[1,2,3],'sampled':False,'scope':'유형별 제한된 조합'},
            },
        }
        script='\n'.join(['import streamlit as st','import pandas as pd','import html',
            'def section(n,t):st.subheader(t)','def read_frame(state):return pd.DataFrame()',
            'def polite_analysis_text(v):return str(v)',section_source,f'quality_patterns({state!r})'])
        app=AppTest.from_string(script).run(timeout=30)
        self.assertEqual(len(app.exception),0)
        self.assertEqual([tab.label for tab in app.tabs],['결측 패턴','이상치·범위','중복','변수 관계','형식·희소 범주'])
        content='\n'.join(item.value for item in app.markdown)
        self.assertIn('함께 발생한 결측',content)
        self.assertIn('완전히 같은 행',content)
        self.assertIn('피어슨 0.800',content)

    def test_date_chart_and_all_missing_column_render_without_error(self):
        raw = b"date,empty\n2024-01-01,\n2024-01-02,\nnot-a-date,\n"
        definitions = {"c0001": {"role": "datetime"}, "c0002": {"role": "numeric"}}
        app = AppTest.from_string(profile_script(raw, definitions)).run(timeout=30)
        self.assertEqual(len(app.exception), 0)
        self.assertEqual(len(app.get("plotly_chart")), 1)
        app.selectbox[0].select_index(1).run(timeout=30)
        self.assertEqual(len(app.exception), 0)
        self.assertEqual(len(app.get("plotly_chart")), 0)
        self.assertTrue(any("비결측값이 없어" in item.value for item in app.info))

    def test_issue_rows_are_read_only_and_labeled(self):
        app = AppTest.from_string(profile_script(b"amount,code\n1,a\n2,b\n3,c\n100,d\n,e\n")).run(timeout=30)
        self.assertEqual(len(app.exception), 0)
        buttons = [button for button in app.button if button.label == "해당 행 보기"]
        self.assertTrue(buttons)
        buttons[0].click().run(timeout=30)
        self.assertEqual(len(app.exception), 0)
        self.assertTrue(any(table.value.index.name == "원본 데이터 행" for table in app.dataframe))

    def test_issue_copy_is_complete_friendly_and_keeps_raw_evidence_in_details(self):
        source=(Path(__file__).resolve().parents[1]/'app.py').read_text(encoding='utf-8')
        section_source=source[source.index('def polite_analysis_text('):source.index('\ndef findings(')]
        item={
            'title':'금액 컬럼의 숫자 변환 확인',
            'fact':'총 사업예산 (A): numeric 형식으로 해석되지 않는 값 1건. 총 발급매수: numeric 형식으로 해석되지 않는 값 1건. 발급매수 (남): numeric 형식으로 해석되지 않는 값 1건.',
            'interpretation':'공통된 표시 형식 때문일 가능성이 있으나 현재 정보만으로 원인을 확정할 수 없다.',
            'recommendation':'해당 컬럼의 변환을 보류한다. errors=coerce로 결측값을 늘리지 않고, 기존에 해석 가능한 컬럼의 errors=raise 변환안만 유지한다.',
            'priority':'high',
        }
        scope={'html':__import__('html'),'json':json,'re':__import__('re'),'readable':lambda value:str(value)}
        exec(section_source,scope)
        rendered=scope['finding_html'](item)
        self.assertNotIn('…',rendered)
        self.assertNotIn('errors=coerce',rendered)
        self.assertNotIn('errors=raise',rendered)
        self.assertIn('숫자로 읽히지 않는 값이 각각 1건씩 확인됐습니다.',rendered)
        self.assertIn('현재 정보만으로는 확정하기 어렵습니다.',rendered)
        self.assertIn('이렇게 진행해 보세요',rendered)
        self.assertIn('계산 근거 보기',rendered)

    def test_dialogue_panel_shows_answer_reflected_judgment_and_next_question(self):
        source=(Path(__file__).resolve().parents[1]/'app.py').read_text(encoding='utf-8')
        section_source=source[source.index('def dialogue_panel('):source.index('\ndef render_change_preview(')]
        state={'id':'p1','stage':'outputs','analysis':{
            'summary':'의존 위험 수준의 의미를 확인했습니다.','question':'위험 수준의 순서가 공식 기준인가요?',
            'question_context':{'situation':'세 단계 값이 있습니다.','judgment':'순서형 타깃으로 보입니다.','recommendation':'단계 정의를 확인하세요.','decision_impact':'비교 방법이 달라집니다.'},
            'decisions':[{'summary':'의존 위험 수준을 분석 타깃으로 사용합니다.'}]},
            'messages':[{'role':'assistant','content':'라벨 의미를 확인해 주세요.'},{'role':'user','content':'설문 점수로 만든 위험 수준이 맞습니다.'}],
        }
        script='\n'.join(['import streamlit as st','import html','def polite_analysis_text(v):return str(v)',section_source,f'dialogue_panel({state!r},None,False)'])
        app=AppTest.from_string(script).run(timeout=30)
        self.assertEqual(len(app.exception),0)
        content='\n'.join(item.value for item in app.markdown)
        self.assertIn('사용자 답변',content)
        self.assertIn('설문 점수로 만든 위험 수준',content)
        self.assertIn('답변을 반영한 판단',content)
        self.assertIn('분석 타깃으로 사용',content)
        self.assertIn('다음 확인',content)

    def test_change_preview_uses_saved_per_rule_impacts(self):
        source=(Path(__file__).resolve().parents[1]/'app.py').read_text(encoding='utf-8')
        section_source=source[source.index('def render_change_preview('):source.index('\ndef review(')]
        state={'schema':[{'id':'c1','name':'age'}]}
        summary_before={'rows':4,'columns':1,'missing_cells':1,'numeric':{'c1':{'mean':2,'median':2,'min':1,'max':3}}}
        summary_after={'rows':4,'columns':1,'missing_cells':0,'numeric':{'c1':{'mean':2,'median':2,'min':1,'max':3}}}
        step={'operation':'fill_missing','before':summary_before,'after':summary_after,'changed_rows':1,'changed_cells':1,'removed_rows':0,
              'added_columns':[],'removed_columns':[],'definitions_changed':False,'details':{'filled':1,'unfilled':0},
              'examples':[{'row_id':1,'column':'c1','before':None,'after':2}]}
        preview={'schema':state['schema'],'manifest':{'rules':[{'columns':['c1'],'reason':'중앙값으로 대치'}]},
                 'impact':{**step,'steps':[step]}}
        script='\n'.join(['import streamlit as st','import pandas as pd','def readable(v):return "—" if v is None else str(v)',
            'def polite_analysis_text(v):return str(v)',"OPERATIONS={'fill_missing':'결측값 대치'}",section_source,
            f'render_change_preview({state!r},{preview!r})'])
        app=AppTest.from_string(script).run(timeout=30)
        self.assertEqual(len(app.exception),0)
        self.assertTrue(any(expander.label=='1. 결측값 대치 · age' for expander in app.expander))
        self.assertTrue(any(metric.label=='값이 달라진 행' and metric.value=='1' for metric in app.metric))
        example=next(item.value for item in app.dataframe if '원본 데이터 행' in item.value.columns)
        self.assertEqual(example.iloc[0]['원본 데이터 행'],2)


if __name__ == "__main__":
    unittest.main()
