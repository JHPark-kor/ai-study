import copy
import json
import os
import tempfile
import unittest
from pathlib import Path

import pandas as pd

from studio.analysis import load_dataset, profile_dataset
from studio.cleaning import preview
from studio.exports import build_exports


def rule(operation, columns, params, rid):
    return dict(id=rid, operation=operation, columns=columns, params=params,
                reason="확인한 단위와 결측값 처리 기준", evidence_ids=["e1"], phase="deep")


class ExportTests(unittest.TestCase):
    def setUp(self):
        self.raw = b"id,amount\n001,10\n002,\n003,30\n003,30\n"
        frame, schema, ingest = load_dataset(self.raw, "test.csv")
        basic = preview(frame, schema, [rule("cast", ["c0002"], {"dtype": "numeric"}, "cast"), rule("unit", ["c0002"], {"factor": 1000, "from_unit": "천원", "to_unit": "원"}, "unit")])
        deep = preview(basic["frame"], basic["schema"], [rule("fill_missing", ["c0002"], {"method": "median"}, "fill"), rule("deduplicate", [], {"keep": "first"}, "dedup")])
        self.frame = deep["frame"]
        self.state = dict(id="p1", name="거래 데이터", revision=12, version_id="v2", schema=deep["schema"], ingest=ingest,
                          goal="거래 현황 확인", context=dict(dataset_description="거래별 금액과 식별자를 기록한 데이터이다.", observation_unit="거래 한 건", source="팀 제공", collection_period="2025년", definitions={}, decisions=[{"summary": "금액 단위를 원으로 통일하였다."}], unresolved=[{"summary": "취소 거래의 포함 여부는 추가 확인이 필요하다."}]),
                          profile=profile_dataset(deep["frame"], deep["schema"]), analysis={"summary": "금액의 결측값을 확인하고 승인한 기준에 따라 정제하였다.", "findings": [{"title": "금액 결측", "fact": "금액 컬럼에 결측값이 있다.", "interpretation": "대치 후 분포 변화를 함께 확인한다.", "recommendation": "승인한 중앙값 대치", "evidence_ids": ["e1"]}]},
                          lineage=[dict(version_id="v1", parent_version="v0", manifest=basic["manifest"], approved_at="2026-01-01"), dict(version_id="v2", parent_version="v1", manifest=deep["manifest"], approved_at="2026-01-02")], recipes=[rule("drop_rows", [], {"condition": {"column": "c0002", "op": "gt", "value": 20000}}, "not_approved")])

    def test_all_artifacts_share_version_and_escape_untrusted_html(self):
        self.state["analysis"]["findings"][0]["title"] = '<script>alert("x")</script>'
        with tempfile.TemporaryDirectory() as tmp:
            artifacts = build_exports(self.state, self.frame, self.raw, tmp, "내 거래 데이터 점검")
            self.assertEqual({a["version_id"] for a in artifacts}, {"v2"})
            self.assertEqual({a["revision"] for a in artifacts}, {12})
            report = (Path(tmp) / "report.html").read_text(encoding="utf-8")
            self.assertNotIn("<script>", report)
            self.assertIn("&lt;script&gt;", report)
            dictionary = (Path(tmp) / "dictionary.html").read_text(encoding="utf-8")
            self.assertIn("데이터셋 정보", dictionary)
            self.assertIn("팀 제공", dictionary)
            self.assertIn("컬럼 정의", dictionary)
            self.assertIn("취소 거래", report)
            exported = pd.read_csv(Path(tmp) / "data.csv", dtype={"id": str})
            self.assertEqual(exported.iloc[0]["id"], "001")
            self.assertEqual(len(exported), 3)

    def test_standalone_notebook_replays_all_approved_versions(self):
        with tempfile.TemporaryDirectory() as tmp:
            build_exports(self.state, self.frame, self.raw, tmp, "내가 정한 제목")
            notebook = json.loads((Path(tmp) / "notebook.ipynb").read_text(encoding="utf-8"))
            self.assertTrue("".join(notebook["cells"][0]["source"]).startswith("# 내가 정한 제목"))
            code = "\n".join("".join(c["source"]) for c in notebook["cells"] if c["cell_type"] == "code")
            self.assertNotIn("from studio", code)
            self.assertNotIn("not_approved", code)
            old_cwd = os.getcwd()
            namespace = {"__name__": "__main__"}
            try:
                os.chdir(tmp)
                for cell in notebook["cells"]:
                    if cell["cell_type"] == "code":
                        exec(compile("".join(cell["source"]), "<notebook>", "exec"), namespace)
            finally:
                os.chdir(old_cwd)
            pd.testing.assert_frame_equal(namespace["df"], self.frame)
            self.assertEqual(namespace["schema"], self.state["schema"])
            self.assertEqual(len(namespace["RUN"]["manifests"]), 2)
            self.assertTrue((Path(tmp) / "정제_결과.csv").exists())

    def test_unmodified_dataset_notebook_has_no_cleaning_rules(self):
        frame, schema, ingest = load_dataset(self.raw, "test.csv")
        state = {**self.state, "schema": schema, "version_id": "v0", "lineage": [], "ingest": ingest}
        with tempfile.TemporaryDirectory() as tmp:
            build_exports(state, frame, self.raw, tmp, "원본 점검")
            manifest = json.loads((Path(tmp) / "manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["lineage"], [])
            self.assertEqual(manifest["version_id"], "v0")

    def test_wrong_original_bytes_are_rejected(self):
        with tempfile.TemporaryDirectory() as tmp, self.assertRaises(ValueError):
            build_exports(self.state, self.frame, b"another file", tmp, "점검")

    def test_dialogue_definition_changes_between_versions_and_after_cleaning(self):
        frame, schema, ingest = load_dataset(self.raw, "test.csv")
        schema[1]["description"] = "승인 전 확인한 거래 금액"
        schema[1]["unit"] = "천원"
        basic = preview(frame, schema, [rule("unit", ["c0002"], {"factor": 1000, "from_unit": "천원", "to_unit": "원"}, "unit")])
        input_schema = copy.deepcopy(basic["schema"])
        input_schema[1]["description"] = "취소 거래를 포함한 거래 금액"
        deep = preview(basic["frame"], input_schema, [rule("fill_missing", ["c0002"], {"method": "median"}, "fill")])
        state = copy.deepcopy(self.state)
        state["schema"] = copy.deepcopy(deep["schema"])
        state["schema"][1]["description"] = "최종 검토에서 확인한 정의"
        state["lineage"] = [{"version_id": "v1", "parent_version": "v0", "manifest": basic["manifest"]}, {"version_id": "v2", "parent_version": "v1", "manifest": deep["manifest"]}]
        with tempfile.TemporaryDirectory() as tmp:
            build_exports(state, deep["frame"], self.raw, tmp, "정의가 변경된 분석")
            notebook = json.loads((Path(tmp) / "notebook.ipynb").read_text(encoding="utf-8"))
            old_cwd, namespace = os.getcwd(), {"__name__": "__main__"}
            try:
                os.chdir(tmp)
                for cell in notebook["cells"]:
                    if cell["cell_type"] == "code":
                        exec(compile("".join(cell["source"]), "<notebook>", "exec"), namespace)
            finally:
                os.chdir(old_cwd)
            pd.testing.assert_frame_equal(namespace["df"], deep["frame"])
            self.assertEqual(namespace["schema"][1]["description"], "최종 검토에서 확인한 정의")

    def test_unapproved_data_change_blocks_export(self):
        changed = self.frame.copy()
        changed.iloc[0, 1] = 99
        with tempfile.TemporaryDirectory() as tmp, self.assertRaises(ValueError):
            build_exports(self.state, changed, self.raw, tmp, "변조된 결과")


if __name__ == "__main__":
    unittest.main()
