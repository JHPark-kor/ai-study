from collections import deque
import io
import json
import os
import threading
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from studio.codex_client import CodexClient, CodexError, _failure, child_environment, safe_login_url, check_connection


@pytest.mark.parametrize("url", ["http://auth.openai.com/login", "https://openai.com.evil.test/login", "https://user:password@auth.openai.com", "https://chatgpt.com:444/login", "javascript:alert(1)"])
def test_login_urls_cannot_exfiltrate_oauth_or_use_wrong_origin(url):
    with pytest.raises(CodexError): safe_login_url(url)
    assert safe_login_url("https://auth.openai.com/authorize?state=opaque").startswith("https://auth.openai.com/")


def test_environment_drops_database_and_api_credentials_but_keeps_codex_home():
    with patch.dict("os.environ", {"PGPASSWORD": "secret", "DATABASE_URL": "secret", "OPENAI_API_KEY": "secret", "CODEX_ACCESS_TOKEN": "secret", "CODEX_HOME": "config", "HTTPS_PROXY": "proxy"}, clear=True):
        assert child_environment() == {"CODEX_HOME": "config", "HTTPS_PROXY": "proxy"}


def test_environment_defaults_codex_home_to_current_windows_user():
    with patch.dict("os.environ", {"USERPROFILE": r"D:\Profiles\teammate", "HTTPS_PROXY": "proxy"}, clear=True):
        assert child_environment() == {"USERPROFILE": r"D:\Profiles\teammate", "HTTPS_PROXY": "proxy",
                                       "CODEX_HOME": r"D:\Profiles\teammate\.codex"}


def test_auth_state_contains_no_email_and_does_not_claim_inference_success():
    client = CodexClient()
    client.call = lambda *args, **kwargs: {"account": {"type": "chatgpt", "email": "person@example.com", "planType": "plus"}}
    account = client.account()
    assert account["connected"] and account["mode"] == "chatgpt"
    assert len(account["account_fingerprint"]) == 64
    assert "person" not in json.dumps(account)
    assert "inference" not in account


def test_account_failure_is_distinct_from_logged_out():
    class FailingClient:
        def __enter__(self): raise CodexError("네트워크 오류", "network")
        def __exit__(self, *args): pass
    with patch("studio.codex_client.CodexClient", FailingClient):
        result = check_connection()
    assert result["mode"] == "unknown" and result["code"] == "network"


class FakeTransport(CodexClient):
    def __init__(self, current="a"):
        super().__init__()
        self.current = current
        self.calls = []
        self.cwd = "temporary-analysis-directory"
    def account(self, refresh=False):
        return {"connected": True, "mode": "chatgpt", "account_fingerprint": self.current}
    def _tool_config(self): return {}
    def call(self, method, params, timeout=30):
        self.calls.append((method, params))
        if method == "model/list":
            return {"data": [{"id": "test-model", "model": "test-model", "isDefault": True,
                               "supportedReasoningEfforts": [{"reasoningEffort": value} for value in
                                                              ("low", "medium", "high", "xhigh", "ultra")]}]}
        if method.startswith("thread/"):
            return {"thread": {"id": "thread-1"}, "model": "test"}
        if method == "turn/start":
            self.events.extend([
                {"method": "item/completed", "params": {"threadId": "thread-1", "item": {"type": "agentMessage", "text": '{"ok":"yes"}'}}},
                {"method": "turn/completed", "params": {"threadId": "thread-1", "turn": {"id": "turn-1", "status": "completed"}}},
            ])
            return {"turn": {"id": "turn-1"}}
    def send(self, message): pass


def test_matching_account_resumes_but_different_or_unknown_account_starts_new_thread():
    for prior, expected in [("a", "thread/resume"), ("b", "thread/start"), (None, "thread/start")]:
        client = FakeTransport()
        result = client.interpret("canonical context", "analysis only", thread_id="old", account_fingerprint=prior)
        assert next(method for method, _ in client.calls if method.startswith("thread/")) == expected
        assert result["connection_reset"] == (prior != "a")
        thread_params = next(params for method, params in client.calls if method.startswith("thread/"))
        assert thread_params["sandbox"] == "read-only"
        assert thread_params["approvalPolicy"] == "never"
        assert thread_params["model"] == "test-model"


def test_denies_all_server_tool_and_approval_requests():
    client = CodexClient()
    sent = []
    client.send = sent.append
    client.messages.put({"method": "item/commandExecution/requestApproval", "id": 55, "params": {}})
    client.receive(1)
    assert sent[0]["id"] == 55
    assert "error" in sent[0] and "result" not in sent[0]


def test_error_messages_do_not_include_tokens_urls_or_original_sensitive_details():
    err = _failure("token_exchange_failed https://auth.openai.com/oauth?state=private access_token=secret")
    assert err.code == "authentication"
    assert "secret" not in str(err) and "private" not in str(err)
    assert _failure("Rate limit reached").code == "usage_limit"


def test_tool_config_paths_do_not_create_quoted_mcp_entries():
    client=CodexClient()
    client.call=lambda *args,**kwargs:{'config':{'mcp_servers':{'docs-server':{'command':'example','enabled':True}},'apps':{'sample_app':{'enabled':True}}}}
    config=client._tool_config()
    assert config['mcp_servers.docs-server.enabled'] is False
    assert config['apps.sample_app.enabled'] is False
    assert not any('"' in key for key in config)


def test_literal_dotted_mcp_name_preserves_transport_in_nested_config():
    client=CodexClient()
    client.call=lambda *args,**kwargs:{'config':{'mcp_servers':{'docs.local':{'command':'example','args':['--stdio'],'enabled':True}}}}
    config=client._tool_config()
    assert config['mcp_servers']['docs.local']=={'command':'example','args':['--stdio'],'enabled':False}


def test_configuration_failure_includes_safe_stage_and_rpc_code_only():
    client=CodexClient()
    client.send=lambda value:None
    client.messages.put({'id':1,'error':{'code':-32600,'message':'failed to load configuration: invalid transport in secret@example.com'}})
    with pytest.raises(CodexError) as caught:
        client.call('thread/start',{})
    assert caught.value.code=='configuration'
    assert caught.value.rpc_method=='thread/start' and caught.value.rpc_code==-32600
    assert 'thread/start' in str(caught.value) and '-32600' in str(caught.value)
    assert 'secret@example.com' not in str(caught.value)


def test_close_is_bounded_when_a_pipe_reader_waits_for_an_inherited_writer():
    """A process can exit while a descendant still holds its stdout handle."""
    read_fd, write_fd = os.pipe()
    stream = os.fdopen(read_fd, 'r', encoding='utf-8')
    waiting, closed = threading.Event(), threading.Event()

    class WaitingPipe:
        def __iter__(self):
            while True:
                waiting.set()
                line = stream.readline()
                if not line:
                    return
                yield line

        def close(self):
            stream.close()

    client = CodexClient()
    proc = SimpleNamespace(stdin=io.StringIO(), stdout=WaitingPipe(), poll=lambda: 0)
    client.proc = proc
    reader = threading.Thread(target=client._read, args=(proc,), daemon=True)
    closer = threading.Thread(target=lambda: (client.close(), closed.set()), daemon=True)
    reader.start()
    try:
        assert waiting.wait(2)
        closer.start()
        assert closed.wait(1), 'shutdown waited for an open stdout writer'
        assert client.proc is None
    finally:
        os.close(write_fd)
        closer.join(timeout=2)
        reader.join(timeout=2)
        if client.stream_closer:
            client.stream_closer.join(timeout=2)
        stream.close()
    assert not reader.is_alive()
    assert not closer.is_alive()


def test_close_does_not_wait_for_a_pending_rpc_lock():
    client = CodexClient()
    client.proc = SimpleNamespace(stdin=io.StringIO(), stdout=io.StringIO(), poll=lambda: 0)
    closed = threading.Event()
    closer = threading.Thread(target=lambda: (client.close(), closed.set()), daemon=True)
    with client.lock:
        closer.start()
        try:
            assert closed.wait(1), 'shutdown waited for a pending RPC request'
        finally:
            # Context manager releases the lock even if the regression returns.
            pass
    closer.join(timeout=2)
    assert client.messages.get(timeout=1) is None


@pytest.mark.parametrize('configured,expected', [('', 'medium'), ('low', 'low'), ('medium', 'medium'),
                                              ('high', 'high'), ('xhigh', 'xhigh'), ('ultra', 'ultra')])
def test_product_effort_is_explicit_on_new_and_resumed_turns(configured, expected):
    for prior_thread in (None, 'existing-thread'):
        client = FakeTransport()
        with patch.dict('os.environ', {'CODEX_REASONING_EFFORT': configured}):
            client.interpret('canonical context', 'analysis only', thread_id=prior_thread, account_fingerprint='a')
        turn_params = next(params for method, params in client.calls if method == 'turn/start')
        assert turn_params['effort'] == expected
        assert 'model' not in turn_params


def test_invalid_product_effort_fails_before_starting_an_inference():
    client = FakeTransport()
    with patch.dict('os.environ', {'CODEX_REASONING_EFFORT': 'unrecognized-private-value'}):
        with pytest.raises(CodexError) as caught:
            client.interpret('canonical context', 'analysis only')
    assert caught.value.code == 'configuration'
    assert caught.value.retryable is False
    assert 'unrecognized-private-value' not in str(caught.value)
    assert not client.calls


def test_account_default_model_overrides_incompatible_global_codex_model():
    client = FakeTransport()
    with patch.dict('os.environ', {'CODEX_REASONING_EFFORT': 'medium'}, clear=True):
        client.interpret('canonical context', 'analysis only')
    thread_params = next(params for method, params in client.calls if method == 'thread/start')
    assert thread_params['model'] == 'test-model'


def test_explicit_unavailable_product_model_fails_before_thread_start():
    client = FakeTransport()
    with patch.dict('os.environ', {'CODEX_MODEL': 'unavailable-model', 'CODEX_REASONING_EFFORT': 'medium'}, clear=True):
        with pytest.raises(CodexError) as caught:
            client.interpret('canonical context', 'analysis only')
    assert caught.value.code == 'model_access' and caught.value.retryable is False
    assert not any(method.startswith('thread/') for method, _ in client.calls)


def test_project_effort_overrides_environment_without_changing_account_model_selection():
    client = FakeTransport()
    client.requested_effort = 'low'
    with patch.dict('os.environ', {'CODEX_REASONING_EFFORT': 'high'}, clear=True):
        result = client.interpret('canonical context', 'analysis only')
    turn_params = next(params for method, params in client.calls if method == 'turn/start')
    assert turn_params['effort'] == 'low'
    assert result['effort'] == 'low'
    assert next(params for method, params in client.calls if method == 'thread/start')['model'] == 'test-model'
