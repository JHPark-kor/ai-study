"""Owned cancellation tests use synthetic child processes, never Codex."""
import ctypes
import os
from pathlib import Path
import subprocess
import sys
import time

import pytest

from worker import OwnedTask, run_owned_job


def spawn_descendant_and_wait(pid_path):
    child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(120)"],
                             creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
    Path(pid_path).write_text(str(child.pid), encoding='ascii')
    time.sleep(120)


def write_done(path):
    Path(path).write_text('done', encoding='ascii')


def process_alive(pid):
    if os.name == 'nt':
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)]
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x1000,False,pid)
        if not handle: return False
        code = wintypes.DWORD()
        try: return bool(kernel.GetExitCodeProcess(handle,ctypes.byref(code))) and code.value == 259
        finally: kernel.CloseHandle(handle)
    try:
        os.kill(pid,0)
        return True
    except ProcessLookupError:
        return False


def test_normal_completion_is_reported_and_owned_resources_are_closed(tmp_path):
    output=tmp_path/'done.txt'
    task=OwnedTask(write_done,(str(output),))
    try:
        task.join(15)
        assert not task.alive()
        assert task.result()['status']=='completed'
        assert output.read_text()=='done'
    finally:
        task.close()


@pytest.mark.skipif(os.name != 'nt',reason='Windows Job Object descendant cleanup')
def test_cancel_terminates_only_owned_task_and_its_descendant(tmp_path):
    output=tmp_path/'pid.txt'
    unrelated=subprocess.Popen([sys.executable,'-c','import time; time.sleep(120)'],creationflags=subprocess.CREATE_NO_WINDOW)
    task=OwnedTask(spawn_descendant_and_wait,(str(output),))
    child_pid=task.process.pid
    try:
        deadline=time.monotonic()+15
        while not output.exists() and time.monotonic()<deadline:
            time.sleep(.05)
        assert output.exists()
        descendant=int(output.read_text())
        assert process_alive(descendant)
        task.close()
        task=None
        assert not process_alive(child_pid)
        assert not process_alive(descendant)
        assert unrelated.poll() is None
    finally:
        if task: task.close()
        unrelated.terminate()
        unrelated.wait(timeout=5)


def test_lost_lease_closes_owned_task_immediately():
    events=[]
    class FakeTask:
        def __init__(self,*args): events.append('start')
        def alive(self): return True
        def close(self): events.append('close')
        def join(self,seconds): events.append('wait')
    class FakeRepo:
        def heartbeat(self,job): return False
    result=run_owned_job(FakeRepo(),{'id':'synthetic'},task_factory=FakeTask,poll_interval=.01)
    assert result['status']=='superseded'
    assert events==['start','close']
