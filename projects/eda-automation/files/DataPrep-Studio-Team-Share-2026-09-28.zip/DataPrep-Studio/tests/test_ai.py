import copy
import json
from unittest.mock import patch

import pytest

from studio.ai import AIValidationError, OUTPUT_SCHEMA, analyze, build_context, parse_response, validate_response


def empty_response():
    return {
        "summary": "금액의 음수 거래를 확인했다.", "dataset_description": "거래 한 건을 한 행으로 기록한 데이터다.", "analysis_uses": ["거래 유형별 금액을 비교한다."],
        "context_patch": {"goal": None, "observation_unit": None, "source": None, "collection_period": None},
        "definitions": [], "findings": [], "question": None, "question_issue_ids": [],
        "question_context": {"situation": "", "judgment": "", "recommendation": "", "decision_impact": "", "evidence_ids": []},
        "recipes": [], "investigations": [], "decisions": [], "resolved_issue_ids": [], "unresolved": [], "completion_reason": "현재 근거로 작성했다.",
    }


PROFILE = {"columns": [{"id": "c0001", "name": "금액"}, {"id": "c0002", "name": "유형"}],
           "evidence": [{"id": "ev_negative", "columns": ["c0001"], "summary": "금액의 음수는 2건이다.", "count": 2}]}


def finding():
    return {"id": "negative_amount", "title": "금액의 음수 거래", "columns": ["c0001"], "evidence_ids": ["ev_negative"],
            "interpretation": "취소 거래일 가능성이 있다.", "recommendation": "거래 유형을 확인하고 유지 여부를 정한다.",
            "priority": "medium", "status": "open"}


def test_facts_come_from_python_and_inference_is_separate():
    payload = empty_response()
    payload["findings"] = [finding()]
    result = validate_response(payload, {}, PROFILE)
    assert result["findings"][0]["fact"] == "금액의 음수는 2건이다."
    assert result["findings"][0]["interpretation"] == "취소 거래일 가능성이 있다."
    assert "fact" not in payload["findings"][0]


def test_automatic_review_uses_bounded_context_instead_of_accumulated_threads():
    class FakeClient:
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def interpret(self,prompt,instructions,**kwargs):
            assert kwargs['thread_id'] is None
            assert '사용자가 확인한 내용' in prompt
            assert '결측 패턴, 중복, 형식 오류, 이상치 후보' in instructions
            assert '일부러 미루거나 생략하지 않는다' in instructions
            return {'text':json.dumps(empty_response()),'thread_id':'fresh-thread'}
    with patch('studio.ai.CodexClient',FakeClient):
        result=analyze({'decisions':[{'summary':'사용자가 확인한 내용'}]},PROFILE,[],'basic','old-large-thread')
    assert result['thread_id']=='fresh-thread'
    assert result['request_metrics']['input_chars']>0


@pytest.mark.parametrize("change", ["column", "evidence", "operation", "params", "condition"])
def test_unknown_references_and_unapproved_operations_fail_closed(change):
    payload = empty_response()
    payload["recipes"] = [{"id": "r1", "operation": "replace", "columns": ["c0001"],
        "params_json": json.dumps({"condition": {"column": "c0001", "op": "lt", "value": 0}, "value": 0}),
        "reason": "업무 규칙 확인 후 대체 후보", "evidence_ids": ["ev_negative"], "phase": "deep"}]
    r = payload["recipes"][0]
    if change == "column": r["columns"] = ["unknown"]
    if change == "evidence": r["evidence_ids"] = ["invented"]
    if change == "operation": r["operation"] = "execute_python"
    if change == "params": r["params_json"] = '{"python":"delete files"}'
    if change == "condition": r["params_json"] = '{"condition":{"column":"missing","op":"lt","value":0},"value":0}'
    with pytest.raises(AIValidationError):
        validate_response(payload, {}, PROFILE)


def test_confirmed_inference_is_rejected():
    payload = empty_response()
    payload["definitions"] = [{"column_id": "c0001", "description": "원화 금액", "role": "numeric", "unit": "원",
        "code_values_json": "{}", "basis": "inference", "certainty": "confirmed", "evidence_ids": ["ev_negative"]}]
    with pytest.raises(AIValidationError, match="추정"):
        validate_response(payload, {}, PROFILE)


def test_followup_refines_multiple_definitions_and_preserves_latest_context():
    payload = empty_response()
    payload["findings"] = [{**finding(), "status": "resolved", "interpretation": "취소 거래의 음수 금액은 정상 기록이다.", "recommendation": "취소 거래의 음수 금액은 유지한다."}]
    payload["resolved_issue_ids"] = ["negative_amount"]
    payload["decisions"] = [{"id": "d1", "issue_ids": ["negative_amount"], "columns": ["c0001", "c0002"],
        "summary": "취소 거래의 음수 금액을 허용하며, 거래 유형별 기준으로 점검한다.", "basis": "user"}]
    ctx = {"goal": "취소 거래 현황", "revision": 3, "version_id": "v1", "account_fingerprint": "account-a",
           "unresolved": [{"id": "negative_amount", "status": "open"}]}
    history = [{"role": "user", "content": "맞아 취소는 마이너스로 넣어"}]
    class FakeClient:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def interpret(self, prompt, instructions, **kwargs):
            assert '취소 거래 현황' in prompt and '"revision": 3' in prompt
            assert history[0]["content"] in prompt
            assert kwargs["thread_id"] == "thread-existing"
            assert kwargs["account_fingerprint"] == "account-a"
            return {"text": json.dumps(payload, ensure_ascii=False), "thread_id": "thread-existing", "model": "mock", "account_fingerprint": "account-a"}
    with patch("studio.ai.CodexClient", FakeClient):
        result = analyze(ctx, PROFILE, history, "followup", "thread-existing")
    assert result["resolved_issue_ids"] == ["negative_amount"]
    assert history[0]["content"] not in json.dumps(result["decisions"], ensure_ascii=False)
    assert result["context_patch"]["decisions"][0]["columns"] == ["c0001", "c0002"]
    assert result["source"] == "codex"


def test_hold_rejects_repeated_question_and_user_stop_is_authoritative():
    payload = empty_response()
    payload["findings"] = [finding()]
    payload["question"] = "취소 금액인지 확인할 수 있나요?"
    payload["question_issue_ids"] = ["negative_amount"]
    payload["question_context"]["decision_impact"] = "유지 또는 제외 기준이 달라진다."
    with pytest.raises(AIValidationError, match="보류"):
        validate_response(payload, {"held_issue_ids": ["negative_amount"]}, PROFILE)
    result = validate_response(payload, {"dialogue_stopped": True}, PROFILE)
    assert result["question"] is None and not result["question_issue_ids"]


def test_context_bounds_details_but_keeps_all_column_and_evidence_ids():
    profile = {"columns": [{"id": f"c{i:04}", "name": f"변수{i}", "role": "numeric",
                             "stats": {"min": 0, "median": i, "max": i * 2, "iqr_candidates": i % 4},
                             "frequency": list(range(100))} for i in range(300)],
               "evidence": [{"id": f"ev_{i}", "details": list(range(1000))} for i in range(300)]}
    schema = [{"id": f"c{i:04}", "name": f"변수{i}", "description": "중복 전송되면 안 되는 긴 설명" * 20} for i in range(300)]
    packet = build_context({"goal": "점검", "schema": schema, "password": "never send", "account_fingerprint": "private"}, profile, [{"role": "user", "content": str(i)} for i in range(30)], "deep")
    assert len(packet["profile"]["columns"]) == 300
    assert len(packet["profile"]["evidence"]) == 300
    assert packet["history_omitted_count"] == 14
    assert "password" not in packet["canonical_context"]
    assert "account_fingerprint" not in packet["canonical_context"]
    assert "schema" not in packet["canonical_context"]
    assert "frequency" not in packet["profile"]["columns"][0]
    assert len(json.dumps(packet, ensure_ascii=False)) < 120_000


def test_invalid_json_and_missing_fields_are_not_success():
    with pytest.raises(AIValidationError): parse_response("not JSON", {}, PROFILE)
    with pytest.raises(AIValidationError): parse_response('{"summary":"완료"}', {}, PROFILE)
    payload = empty_response()
    payload["unexpected"] = "hello"
    with pytest.raises(AIValidationError): validate_response(payload, {}, PROFILE)


def test_dynamic_investigation_respects_kind_and_condition_column_contract():
    payload = empty_response()
    payload["investigations"] = [{"kind": "grouped_missing", "columns": ["c0001"],
        "params_json": '{"group_by":["c0002"]}', "reason": "유형별 누락 차이를 확인한다."}]
    result = validate_response(payload, {}, PROFILE, "deep")
    assert result["investigations"][0]["params"] == {"group_by": ["c0002"]}
    payload["investigations"][0]["params_json"] = '{"group_by":["unknown"]}'
    with pytest.raises(AIValidationError): validate_response(payload, {}, PROFILE, "deep")


def test_reassess_can_ask_after_additional_evidence_but_synthesis_cannot():
    payload = empty_response()
    payload["findings"] = [finding()]
    payload["question"] = "취소와 정상 거래의 구분이 맞나요?"
    payload["question_issue_ids"] = ["negative_amount"]
    payload["question_context"]["decision_impact"] = "정상 거래의 음수만 추가로 검사한다."
    assert validate_response(payload, {}, PROFILE, "reassess")["question"]
    assert validate_response(payload, {}, PROFILE, "synthesis")["question"] is None
    assert build_context({"review_phase": "deep"}, PROFILE, [], "reassess")["canonical_context"]["review_phase"] == "deep"


def test_confirmed_metadata_cannot_be_rewritten_without_a_new_user_fact():
    payload = empty_response()
    payload["definitions"] = [{"column_id": "c0001", "description": "환불 포함 금액", "role": "numeric", "unit": "원",
        "code_values_json": "{}", "basis": "inference", "certainty": "likely", "evidence_ids": ["ev_negative"]}]
    ctx = {"definitions": {"c0001": {"description": "환불 포함 금액", "role": "numeric", "unit": "천 원", "status": "confirmed"}}}
    with pytest.raises(AIValidationError, match="새 사용자 근거"):
        validate_response(payload, ctx, PROFILE)
    payload["definitions"][0].update(basis="user", certainty="confirmed")
    ctx["_latest_user_text"] = "단위 설명이 잘못됐어. 원 단위야."
    result = validate_response(payload, ctx, PROFILE)
    assert result["definitions"]["c0001"]["unit"] == "원"


def test_stopping_a_held_issue_always_closes_the_question():
    payload = empty_response()
    payload["findings"] = [finding()]
    payload["question"] = "확인 가능한가요?"
    payload["question_issue_ids"] = ["negative_amount"]
    result = validate_response(payload, {"dialogue_stopped": True, "held_issue_ids": ["negative_amount"]}, PROFILE)
    assert result["question"] is None
