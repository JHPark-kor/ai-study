$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$runtime = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $runtime)) {
    throw 'Python environment is missing. Run setup.ps1 first.'
}
& $runtime (Join-Path $PSScriptRoot 'check_environment.py')
$status = $LASTEXITCODE
if ($status -eq 2) {
    Write-Host 'The app can start. Complete ChatGPT sign-in from Connection settings in the web app.'
    exit 0
}
exit $status
