"""Calm, readable product styling for the single-page review workspace."""

CSS = """
<style>
:root {
  --ink:#191f28; --ink-soft:#4e5968; --muted:#8b95a1;
  --line:#e5e8eb; --line-soft:#f2f4f6; --surface:#ffffff;
  --canvas:#f7f8fa; --blue:#3182f6; --blue-dark:#1b64da;
  --blue-soft:#e8f3ff; --yellow:#fdbb20; --red:#f04452;
  font-synthesis:none;
}
html,body,[class*="css"],.stApp,button,input,textarea,select {
  font-family:'Noto Sans KR','Pretendard Variable','Pretendard','NanumBarunGothic','Malgun Gothic',sans-serif!important;
  color:var(--ink);-webkit-font-smoothing:antialiased;
}
.stApp div,.stApp p,.stApp h1,.stApp h2,.stApp h3,.stApp h4,.stApp h5,.stApp h6,
.stApp label,.stApp button,.stApp input,.stApp textarea,.stApp select,.stApp summary,.stApp th,.stApp td,
.step-name,.stage-label,.issue-title,.issue-block,.decision-message {
  font-family:'Noto Sans KR','Pretendard Variable','Pretendard','NanumBarunGothic','Malgun Gothic',sans-serif!important;
}
body {letter-spacing:-.012em;}
.stApp {background:var(--canvas);}
.block-container {max-width:1260px;padding:2rem 2rem 6rem;}
[data-testid="stMainBlockContainer"]>[data-testid="stVerticalBlock"] {gap:1rem;}
header[data-testid="stHeader"] {background:rgba(247,248,250,.92);backdrop-filter:blur(12px);}
#MainMenu,footer,[data-testid="stAppDeployButton"] {display:none!important;}

[data-testid="stSidebar"] {background:#fff;border-right:1px solid var(--line);}
[data-testid="stSidebar"] .block-container {padding:1.5rem 1rem 2rem;}
[data-testid="stSidebar"] [data-testid="stVerticalBlock"] {gap:.55rem;}
[data-testid="stSidebar"] hr {border-color:var(--line-soft);margin:.75rem 0;}
[data-testid="stSidebar"] .stButton>button {
  width:100%;justify-content:flex-start;border:0;background:transparent;color:#333d4b;
  padding:.65rem .75rem;min-height:2.55rem;border-radius:10px;font-weight:550;box-shadow:none;
}
[data-testid="stSidebar"] .stButton>button:hover {background:#f2f4f6;color:var(--ink);}
[data-testid="stSidebar"] .stButton>button[kind="primary"] {justify-content:center;background:var(--blue);color:#fff;font-weight:650;}
[data-testid="stSidebar"] .stButton>button[kind="primary"]:hover {background:var(--blue-dark);}
.brand {display:flex;align-items:center;gap:10px;font-size:1.02rem;font-weight:760;letter-spacing:-.025em;margin:.1rem .45rem .15rem;}
.brand-mark {position:relative;width:23px;height:23px;display:inline-block;background:var(--blue);border-radius:6px;box-shadow:8px 8px 0 -3px #8dbdff;}
.sidebar-sub {color:var(--muted);font-size:.76rem;margin:0 .45rem .75rem;}
.sidebar-label {color:#6b7684;font-size:.75rem;font-weight:650;margin:.75rem .45rem .25rem;}
.recent-project-card {display:block;border-radius:11px;padding:.62rem .68rem;margin:.08rem 0;color:var(--ink);background:#fff;border:1px solid transparent;transition:background .15s,border-color .15s;min-width:0;}
.recent-project-card:hover {background:#f7f8fa;border-color:#eef1f5;color:var(--ink);}
.recent-project-card.active {background:var(--blue-soft);border-color:#d5e9ff;}
.recent-project-title {display:flex;align-items:center;gap:7px;min-width:0;}
.recent-project-title b {font-size:.78rem;font-weight:650;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.recent-status {display:inline-block;width:7px;height:7px;border-radius:50%;flex:0 0 auto;background:#b0b8c1;}
.recent-status.completed {background:var(--blue);}
.recent-status.running,.recent-status.review {background:var(--yellow);}
.recent-status.failed {background:var(--red);}
.recent-project-file {display:block;color:#6b7684;font-size:.67rem;margin:.28rem 0 .18rem 14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.recent-project-meta {display:flex;align-items:center;justify-content:space-between;color:#8b95a1;font-size:.64rem;margin-left:14px;gap:6px;}
.recent-project-meta em {font-style:normal;color:#6b7684;font-weight:600;}
[data-testid="stSidebar"] [data-testid="stPopover"]>button {width:100%;min-height:2.3rem!important;padding:.3rem!important;justify-content:center!important;border:0!important;background:transparent!important;font-size:1.05rem!important;}
.archived-project {padding:.5rem .1rem .15rem;border-top:1px solid var(--line-soft);}
.archived-project:first-of-type {border-top:0;}
.archived-project b {display:block;font-size:.76rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.archived-project span {display:block;color:#8b95a1;font-size:.66rem;margin-top:.15rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.storage-status {display:flex;align-items:center;gap:8px;color:#6b7684;font-size:.76rem;margin:.35rem .45rem;}
.storage-status:before {content:"";width:7px;height:7px;border-radius:50%;background:#35c46a;box-shadow:0 0 0 3px #e8faef;}

h1 {font-size:2rem!important;font-weight:760!important;letter-spacing:-.045em!important;line-height:1.3!important;margin:.15rem 0 .25rem!important;overflow-wrap:anywhere;word-break:keep-all;}
h2 {font-size:1.32rem!important;font-weight:720!important;letter-spacing:-.035em!important;}
h3,h4 {font-weight:680!important;letter-spacing:-.025em!important;}
p,li,label {line-height:1.68;word-break:keep-all;overflow-wrap:anywhere;}
[data-testid="stCaptionContainer"] p {color:var(--muted);font-size:.79rem;line-height:1.55;}
a {color:var(--blue);text-decoration:none;}
.stButton>button,.stDownloadButton>button,.stFormSubmitButton>button {border-radius:10px;min-height:2.75rem;font-weight:620;border-color:#d8dde5;box-shadow:none;}
.stButton>button:hover,.stDownloadButton>button:hover,.stFormSubmitButton>button:hover {border-color:#aeb7c2;color:var(--ink);}
.stButton>button[kind="primary"],.stFormSubmitButton>button[kind="primary"] {background:var(--blue);border-color:var(--blue);color:#fff;}
.stButton>button[kind="primary"]:hover,.stFormSubmitButton>button[kind="primary"]:hover {background:var(--blue-dark);border-color:var(--blue-dark);color:#fff;}
.stTextArea textarea,.stTextInput input,[data-baseweb="select"]>div {font-size:.9rem;border-radius:10px!important;border-color:#d8dde5!important;background:#fff!important;}
.stTextArea textarea:focus,.stTextInput input:focus {border-color:var(--blue)!important;box-shadow:0 0 0 2px var(--blue-soft)!important;}
[data-testid="stExpander"] {border:1px solid var(--line)!important;border-radius:12px!important;background:#fff;box-shadow:none!important;}
[data-testid="stExpander"] summary {font-size:.88rem;font-weight:580;color:#4e5968;}
[data-testid="stDataFrame"] {border:1px solid var(--line);border-radius:10px;overflow:hidden;}
[data-testid="stSegmentedControl"] {background:#f2f4f6;border-radius:10px;padding:3px;}

.page-kicker {font-size:.78rem;color:#6b7684;margin-bottom:.2rem;}
.page-kicker b {color:#333d4b;font-weight:650;}
.workspace-meta {display:flex;align-items:center;flex-wrap:wrap;gap:8px;color:#6b7684;font-size:.8rem;margin-bottom:1.15rem;}
.status-pill,.version-pill {display:inline-flex;align-items:center;border-radius:999px;padding:5px 10px;font-size:.72rem;font-weight:650;}
.status-pill {background:#e8f8ee;color:#1b8b4b;}
.status-pill.pending {background:#fff6dc;color:#a56600;}
.status-pill.failed {background:#fff0f1;color:#c83240;}
.version-pill {background:var(--blue-soft);color:#246ec8;}
.eyebrow {color:#6b7684;font-size:.74rem;font-weight:650;margin-bottom:.35rem;}
.empty-intro {font-size:1rem;color:#4e5968;margin-bottom:1.5rem;max-width:720px;line-height:1.75;}

.stage-nav {display:flex;align-items:flex-start;margin:1.1rem 0 1.35rem;padding:0 4px;min-width:0;}
.stage-item {position:relative;display:flex;flex:1;align-items:center;gap:8px;color:#8b95a1;font-size:.76rem;font-weight:540;white-space:nowrap;}
.stage-item:not(:last-child):after {content:"";position:absolute;height:1px;background:#d8dde5;left:27px;right:8px;top:12px;z-index:0;}
.stage-index {z-index:1;display:inline-flex;align-items:center;justify-content:center;width:25px;height:25px;border-radius:50%;background:#eef1f5;color:#6b7684;border:1px solid #d8dde5;font-size:.72rem;font-weight:700;}
.stage-label {z-index:1;background:var(--canvas);padding-right:8px;}
.stage-item.done .stage-index,.stage-item.active .stage-index {background:var(--blue);border-color:var(--blue);color:#fff;}
.stage-item.done:not(:last-child):after {background:var(--blue);}
.stage-item.active {color:var(--blue);font-weight:700;}

[data-testid="stLayoutWrapper"]>[data-testid="stVerticalBlock"] {border-color:var(--line)!important;border-radius:16px!important;background:var(--surface);box-shadow:none!important;padding:1.45rem!important;gap:.85rem!important;}
.step-title {display:flex;align-items:center;gap:10px;margin:0 0 .9rem;}
.step-no {display:none;}
.step-name {font-size:1.22rem;font-weight:720;letter-spacing:-.035em;color:var(--ink);}
.section-subtitle {font-size:.82rem;color:var(--muted);margin:-.6rem 0 1rem;}
.overview-grid {display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:0;margin:-.15rem 0 .25rem;}
.overview-metric {padding:.65rem 1.1rem .75rem;border-right:1px solid var(--line);min-width:0;}
.overview-metric:first-child {padding-left:.15rem;}
.overview-metric:last-child {border-right:0;}
.overview-metric span {display:block;color:#6b7684;font-size:.78rem;margin-bottom:.3rem;}
.overview-metric strong {display:block;font-size:1.72rem;font-weight:730;letter-spacing:-.035em;color:var(--ink);line-height:1.25;}
[data-testid="stMetric"] {padding:.35rem .6rem;min-width:0;}
[data-testid="stMetricLabel"] {color:#6b7684;font-size:.78rem;}
[data-testid="stMetricValue"] {font-size:1.68rem;font-weight:730;letter-spacing:-.035em;color:var(--ink);}
.summary-lead {font-size:.94rem;color:#333d4b;line-height:1.78;margin:0 0 .75rem;max-width:980px;}
.observation-unit {display:inline-flex;background:#f2f4f6;color:#4e5968;border-radius:8px;padding:7px 10px;font-size:.78rem;margin-bottom:.85rem;}
.use-row {display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:.8rem 0 .25rem;}
.use-label {color:#6b7684;font-size:.76rem;margin-right:2px;}
.use-chip {display:inline-flex;background:var(--blue-soft);color:#356fae;border-radius:12px;padding:7px 11px;font-size:.75rem;font-weight:550;line-height:1.55;max-width:100%;white-space:normal;}
.review-heading,.change-heading {display:flex;align-items:baseline;gap:12px;margin:.35rem 0 .1rem;}
.review-heading strong,.change-heading strong {font-size:1rem;font-weight:700;color:var(--ink);}
.review-heading span,.change-heading span {font-size:.76rem;color:var(--muted);}
[data-testid="stDataFrame"] * {font-family:'Noto Sans KR','Pretendard Variable','Pretendard','NanumBarunGothic','Malgun Gothic',sans-serif!important;}

.pattern-row {border-bottom:1px solid var(--line-soft);padding:.9rem .15rem .85rem;min-width:0;}
.pattern-row:last-child {border-bottom:0;}
.pattern-row strong {display:block;font-size:.88rem;font-weight:680;color:var(--ink);margin-bottom:.28rem;word-break:keep-all;overflow-wrap:anywhere;}
.pattern-row p {margin:0;color:#4e5968;font-size:.8rem;line-height:1.68;word-break:keep-all;overflow-wrap:anywhere;}
.pattern-row span {display:block;color:var(--muted);font-size:.7rem;margin-top:.28rem;}
[data-testid="stTabs"] [data-baseweb="tab-list"] {gap:1rem;border-bottom:1px solid var(--line);overflow-x:auto;}
[data-testid="stTabs"] [data-baseweb="tab"] {white-space:nowrap;font-size:.8rem;padding-left:.1rem;padding-right:.1rem;}
[data-testid="stTabs"] [data-baseweb="tab-panel"] {padding-top:.55rem;}

.quality-head {display:flex;align-items:baseline;gap:14px;margin-bottom:.25rem;}
.quality-head strong {font-size:1.22rem;letter-spacing:-.035em;}
.quality-head span {font-size:.8rem;color:var(--muted);}
.issue-row {border-top:1px solid var(--line-soft);padding:1rem .15rem .95rem;}
.issue-row:first-child {border-top:0;padding-top:.25rem;}
.issue-title {display:flex;align-items:center;gap:9px;margin-bottom:.65rem;min-width:0;}
.issue-title strong {font-size:.92rem;font-weight:680;min-width:0;word-break:keep-all;overflow-wrap:anywhere;}
.issue-dot {width:8px;height:8px;border-radius:50%;background:var(--yellow);flex:0 0 auto;}
.issue-dot.high {background:var(--red);}
.issue-dot.low {background:#8b95a1;}
.issue-tag {margin-left:auto;background:#f2f4f6;color:#6b7684;border-radius:999px;padding:4px 8px;font-size:.68rem;font-weight:600;flex:0 0 auto;}
.issue-block {margin:.5rem 0 0 17px;min-width:0;}
.issue-block>b {display:block;color:#6b7684;font-size:.72rem;font-weight:650;margin-bottom:.18rem;}
.issue-block p {color:#4e5968;font-size:.81rem;line-height:1.68;margin:0;word-break:keep-all;overflow-wrap:anywhere;}
.issue-rec {background:#f7f9fc;border-radius:10px;padding:.7rem .8rem;margin-top:.65rem;}
.issue-rec>b {color:#246ec8;}
.issue-rec p {color:#333d4b;}
.issue-row details {margin:.5rem 0 0 17px;color:#8b95a1;font-size:.72rem;}
.issue-row details p {font-size:.74rem;line-height:1.62;color:#6b7684;word-break:keep-all;overflow-wrap:anywhere;}
.issue-row summary {cursor:pointer;}
.decision-panel {background:#fbfcfe;border:1px solid var(--line);border-radius:14px;padding:1rem 1rem .85rem;margin-bottom:.5rem;}
.decision-title {display:flex;align-items:center;gap:9px;font-size:.94rem;font-weight:700;margin-bottom:.75rem;}
.decision-dot {width:9px;height:9px;border-radius:50%;background:var(--yellow);box-shadow:0 0 0 4px #fff5d6;}
.decision-message {background:var(--blue-soft);border-radius:12px;padding:.9rem;color:#333d4b;font-size:.82rem;line-height:1.7;margin-bottom:.75rem;word-break:keep-all;overflow-wrap:anywhere;}
.dialogue-section {padding:.15rem .1rem .7rem;}
.dialogue-section>b,.dialogue-answer>b {display:block;color:#6b7684;font-size:.72rem;font-weight:650;margin-bottom:.22rem;}
.dialogue-section p,.dialogue-answer p {margin:0;color:#333d4b;font-size:.83rem;line-height:1.68;word-break:keep-all;overflow-wrap:anywhere;}
.dialogue-answer {background:#f7f8fa;border-radius:12px;padding:.8rem .9rem;margin:.15rem 0 .75rem;}
.dialogue-section.reflected {border-left:3px solid #8dbdff;padding:.15rem 0 .7rem .8rem;}
[data-testid="stChatMessage"] {border:0;border-radius:12px;background:#f7f8fa;padding:.85rem;}
[data-testid="stChatMessage"] p {font-size:.82rem;line-height:1.62;}
.rules-title {font-size:1.05rem;font-weight:700;margin:1.1rem 0 .35rem;}
.safe-note {display:flex;align-items:center;gap:8px;color:#6b7684;font-size:.76rem;margin-top:.5rem;}
.safe-note:before {content:"i";display:inline-flex;align-items:center;justify-content:center;width:17px;height:17px;border:1px solid #8b95a1;border-radius:50%;font-size:.66rem;font-weight:700;}
.finding {border:0;padding:0;margin:0;}

.js-plotly-plot .plotly .modebar {opacity:.45;}
@media (max-width:900px) {
  .block-container {padding:1.5rem 1rem 4rem;}
  [data-testid="stLayoutWrapper"]>[data-testid="stVerticalBlock"] {padding:1.15rem!important;}
  .stage-nav {display:grid;grid-template-columns:repeat(5,minmax(0,1fr));align-items:start;}
  .stage-item {flex-direction:column;gap:5px;text-align:center;white-space:normal;font-size:.67rem;line-height:1.3;min-width:0;}
  .stage-item:not(:last-child):after {left:calc(50% + 13px);right:calc(-50% + 13px);top:12px;}
  .stage-label {display:block;background:transparent;padding:0 2px;word-break:keep-all;}
  h1 {font-size:1.62rem!important;letter-spacing:-.025em!important;padding-left:.1rem;}
}
@media (max-width:700px) {
  .block-container {padding:1.25rem .8rem 3rem;}
  [data-testid="stLayoutWrapper"]>[data-testid="stVerticalBlock"] {padding:1rem!important;gap:.75rem!important;border-radius:14px!important;}
  .overview-grid {grid-template-columns:repeat(2,minmax(0,1fr));}
  .overview-metric {padding:.7rem .75rem;border-bottom:1px solid var(--line);}
  .overview-metric:nth-child(2) {border-right:0;}
  .overview-metric:nth-child(n+3) {border-bottom:0;}
  .overview-metric:nth-child(odd) {padding-left:.15rem;}
  .overview-metric strong {font-size:1.45rem;}
  [data-testid="stMetricValue"] {font-size:1.4rem;}
  .quality-head {display:block;}
  .quality-head span {display:block;margin-top:.25rem;}
  .review-heading,.change-heading {display:block;}
  .review-heading span,.change-heading span {display:block;margin-top:.2rem;}
  .issue-row {padding:.9rem 0;}
  .issue-title {align-items:flex-start;flex-wrap:wrap;}
  .issue-tag {margin-left:17px;}
  .issue-block,.issue-row details {margin-left:17px;}
}
</style>
"""
