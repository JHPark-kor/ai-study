"""Durable project state and a fenced, single-project PostgreSQL job queue."""
from __future__ import annotations

import copy
import datetime as dt
import uuid
from contextlib import contextmanager

import psycopg
from psycopg.types.json import Jsonb

from studio.config import connection_kwargs


class Conflict(RuntimeError):
    pass


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


SCHEMA = """
CREATE TABLE IF NOT EXISTS dpw2_projects (
 id text PRIMARY KEY, name text NOT NULL, revision bigint NOT NULL DEFAULT 0,
 state jsonb NOT NULL, updated_at timestamptz NOT NULL DEFAULT now(),
 archived_at timestamptz
);
ALTER TABLE dpw2_projects ADD COLUMN IF NOT EXISTS archived_at timestamptz;
CREATE INDEX IF NOT EXISTS dpw2_projects_recent ON dpw2_projects(archived_at,updated_at DESC);
CREATE TABLE IF NOT EXISTS dpw2_jobs (
 id text PRIMARY KEY, project_id text NOT NULL REFERENCES dpw2_projects(id),
 kind text NOT NULL, request_id text UNIQUE NOT NULL, payload jsonb NOT NULL,
 expected_revision bigint NOT NULL, input_version text NOT NULL,
 status text NOT NULL DEFAULT 'queued', token text, heartbeat timestamptz,
 attempts integer NOT NULL DEFAULT 0, error text,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS dpw2_one_active_job
 ON dpw2_jobs(project_id) WHERE status IN ('queued','running');
CREATE TABLE IF NOT EXISTS dpw2_events (
 id bigserial PRIMARY KEY, project_id text NOT NULL REFERENCES dpw2_projects(id),
 kind text NOT NULL, revision bigint NOT NULL, payload jsonb NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS dpw2_dataset_versions (
 id text NOT NULL, project_id text NOT NULL REFERENCES dpw2_projects(id),
 manifest jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(project_id,id)
);
CREATE TABLE IF NOT EXISTS dpw2_worker_status (
 id text PRIMARY KEY, heartbeat timestamptz NOT NULL DEFAULT now()
);
"""


class Repository:
    def __init__(self, connector=None):
        self.connector = connector or (lambda: psycopg.connect(**connection_kwargs()))

    @contextmanager
    def connection(self):
        with self.connector() as conn:
            yield conn

    def initialize(self):
        with self.connection() as conn:
            conn.execute(SCHEMA)

    def check(self):
        with self.connection() as conn:
            conn.execute('SELECT 1')
            return bool(conn.execute("SELECT to_regclass('dpw2_projects') IS NOT NULL").fetchone()[0])

    def create(self, state):
        with self.connection() as conn:
            conn.execute('INSERT INTO dpw2_projects(id,name,revision,state) VALUES(%s,%s,%s,%s)',
                         (state['id'], state['name'], state['revision'], Jsonb(state)))
            self._event(conn, state, 'created', {})

    def list_projects(self):
        with self.connection() as conn:
            columns=('id','name','revision','updated_at','stage','filename','status','ai_status','created_at','understanding_status','archived_at')
            return [dict(zip(columns,r)) for r in conn.execute(
                """SELECT id,name,revision,updated_at,state->>'stage',state->>'filename',state->>'status',
                          state->>'ai_status',state->>'created_at',state->'understanding'->>'status',archived_at
                   FROM dpw2_projects WHERE archived_at IS NULL ORDER BY updated_at DESC LIMIT 50""")]

    def list_archived_projects(self):
        with self.connection() as conn:
            columns=('id','name','revision','updated_at','stage','filename','status','ai_status','created_at','understanding_status','archived_at')
            return [dict(zip(columns,r)) for r in conn.execute(
                """SELECT id,name,revision,updated_at,state->>'stage',state->>'filename',state->>'status',
                          state->>'ai_status',state->>'created_at',state->'understanding'->>'status',archived_at
                   FROM dpw2_projects WHERE archived_at IS NOT NULL ORDER BY archived_at DESC LIMIT 20""")]

    def load(self, project_id):
        with self.connection() as conn:
            row = conn.execute('SELECT state FROM dpw2_projects WHERE id=%s AND archived_at IS NULL', (project_id,)).fetchone()
        if not row:
            raise ValueError('작업을 찾을 수 없습니다.')
        return row[0]

    def rename_project(self, project_id, expected_revision, name):
        name=' '.join(str(name or '').split())
        if not name:
            raise ValueError('작업 이름을 입력해 주세요.')
        if len(name)>160:
            raise ValueError('작업 이름은 160자 이내로 입력해 주세요.')
        with self.connection() as conn:
            row=conn.execute('SELECT state,revision,archived_at FROM dpw2_projects WHERE id=%s FOR UPDATE',(project_id,)).fetchone()
            if not row or row[2] is not None:
                raise ValueError('작업을 찾을 수 없습니다.')
            if row[1]!=expected_revision:
                raise Conflict('다른 변경 사항이 반영되었습니다. 화면을 갱신해 주세요.')
            if conn.execute("SELECT 1 FROM dpw2_jobs WHERE project_id=%s AND status IN ('queued','running')",(project_id,)).fetchone():
                raise Conflict('진행 중인 분석이 끝나면 이름을 변경할 수 있습니다.')
            state=copy.deepcopy(row[0]);old_name=state.get('name','')
            state.update(name=name,revision=expected_revision+1,updated_at=now())
            conn.execute('UPDATE dpw2_projects SET name=%s,state=%s,revision=%s,updated_at=now() WHERE id=%s',
                         (name,Jsonb(state),state['revision'],project_id))
            self._event(conn,state,'project_renamed',{'old_name':old_name,'new_name':name})
            return state

    def archive_project(self, project_id, expected_revision):
        with self.connection() as conn:
            row=conn.execute('SELECT state,revision,archived_at FROM dpw2_projects WHERE id=%s FOR UPDATE',(project_id,)).fetchone()
            if not row or row[2] is not None:
                raise ValueError('작업을 찾을 수 없습니다.')
            if row[1]!=expected_revision:
                raise Conflict('다른 변경 사항이 반영되었습니다. 화면을 갱신해 주세요.')
            if conn.execute("SELECT 1 FROM dpw2_jobs WHERE project_id=%s AND status IN ('queued','running')",(project_id,)).fetchone():
                raise Conflict('진행 중인 분석이 끝나면 삭제할 수 있습니다.')
            state=copy.deepcopy(row[0])
            conn.execute('UPDATE dpw2_projects SET archived_at=now(),updated_at=now() WHERE id=%s',(project_id,))
            self._event(conn,state,'project_archived',{'name':state.get('name','')})
            return state

    def restore_project(self, project_id):
        with self.connection() as conn:
            row=conn.execute('SELECT state FROM dpw2_projects WHERE id=%s AND archived_at IS NOT NULL FOR UPDATE',(project_id,)).fetchone()
            if not row:
                raise ValueError('복원할 작업을 찾을 수 없습니다.')
            state=copy.deepcopy(row[0])
            conn.execute('UPDATE dpw2_projects SET archived_at=NULL,updated_at=now() WHERE id=%s',(project_id,))
            self._event(conn,state,'project_restored',{'name':state.get('name','')})
            return state

    def _event(self, conn, state, kind, payload):
        conn.execute('INSERT INTO dpw2_events(project_id,kind,revision,payload) VALUES(%s,%s,%s,%s)',
                     (state['id'], kind, state['revision'], Jsonb(payload)))

    def command(self, project_id, expected_revision, kind, payload=None, mutate=None, request_id=None):
        """Commit user intent and enqueue atomically; double submits return the original job."""
        request_id = request_id or str(uuid.uuid4())
        payload = payload or {}
        with self.connection() as conn:
            row = conn.execute('SELECT state,revision FROM dpw2_projects WHERE id=%s FOR UPDATE', (project_id,)).fetchone()
            existing = conn.execute('SELECT id FROM dpw2_jobs WHERE request_id=%s', (request_id,)).fetchone()
            if existing:
                return existing[0]
            if not row or row[1] != expected_revision:
                raise Conflict('화면의 내용이 변경되었습니다. 최신 결과를 확인한 뒤 다시 시도해 주세요.')
            if conn.execute("SELECT 1 FROM dpw2_jobs WHERE project_id=%s AND status IN ('queued','running')", (project_id,)).fetchone():
                raise Conflict('진행 중인 작업이 있습니다. 완료하거나 취소한 뒤 다시 시도해 주세요.')
            state = copy.deepcopy(row[0])
            if mutate:
                mutate(state)
            state.update(revision=expected_revision + 1, status='queued', error=None, updated_at=now())
            job_id = str(uuid.uuid4())
            conn.execute('INSERT INTO dpw2_jobs(id,project_id,kind,request_id,payload,expected_revision,input_version) VALUES(%s,%s,%s,%s,%s,%s,%s)',
                         (job_id, project_id, kind, request_id, Jsonb(payload), state['revision'], state['version_id']))
            conn.execute('UPDATE dpw2_projects SET state=%s,revision=%s,updated_at=now() WHERE id=%s',
                         (Jsonb(state), state['revision'], project_id))
            self._event(conn, state, kind + '_requested', {'job_id': job_id})
            return job_id

    def mutate(self, project_id, expected_revision, kind, callback, cancel=False):
        with self.connection() as conn:
            row = conn.execute('SELECT state,revision FROM dpw2_projects WHERE id=%s FOR UPDATE', (project_id,)).fetchone()
            if not row or row[1] != expected_revision:
                raise Conflict('다른 변경 사항이 반영되었습니다. 화면을 갱신해 주세요.')
            if cancel:
                conn.execute("UPDATE dpw2_jobs SET status='canceled',token=NULL,updated_at=now() WHERE project_id=%s AND status IN ('queued','running')", (project_id,))
            elif conn.execute("SELECT 1 FROM dpw2_jobs WHERE project_id=%s AND status IN ('queued','running')", (project_id,)).fetchone():
                raise Conflict('진행 중인 작업이 끝나면 변경할 수 있습니다.')
            state = copy.deepcopy(row[0])
            callback(state)
            state.update(revision=expected_revision + 1, updated_at=now())
            conn.execute('UPDATE dpw2_projects SET state=%s,revision=%s,updated_at=now() WHERE id=%s', (Jsonb(state), state['revision'], project_id))
            self._event(conn, state, kind, {})
            return state

    def claim(self):
        with self.connection() as conn:
            # A dead attempt is recoverable. Publication still requires the new token.
            conn.execute("UPDATE dpw2_jobs SET status='queued',token=NULL WHERE status='running' AND heartbeat < now()-interval '45 seconds' AND attempts < 3")
            stale = conn.execute("UPDATE dpw2_jobs SET status='failed',token=NULL,error='작업 프로세스가 반복해서 중단되었습니다.' WHERE status='running' AND heartbeat < now()-interval '45 seconds' AND attempts >= 3 RETURNING project_id,expected_revision").fetchall()
            for pid, revision in stale:
                conn.execute("UPDATE dpw2_projects SET state=jsonb_set(jsonb_set(state,'{status}','\"failed\"'),'{error}','\"작업이 중단되었습니다. 다시 시도해 주세요.\"') WHERE id=%s AND revision=%s", (pid, revision))
            row = conn.execute("SELECT id,project_id,kind,payload,expected_revision,input_version FROM dpw2_jobs WHERE status='queued' ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT 1").fetchone()
            if not row:
                return None
            token = str(uuid.uuid4())
            conn.execute("UPDATE dpw2_jobs SET status='running',token=%s,attempts=attempts+1,heartbeat=now(),updated_at=now() WHERE id=%s", (token, row[0]))
            return dict(zip(('id','project_id','kind','payload','revision','version_id'), row), token=token)

    def heartbeat(self, job=None):
        with self.connection() as conn:
            conn.execute("SET LOCAL statement_timeout = '5s'")
            conn.execute("SET LOCAL lock_timeout = '3s'")
            conn.execute("INSERT INTO dpw2_worker_status(id) VALUES('local') ON CONFLICT(id) DO UPDATE SET heartbeat=now()")
            if job:
                row = conn.execute("UPDATE dpw2_jobs SET heartbeat=now() WHERE id=%s AND token=%s AND status='running' RETURNING id", (job['id'], job['token'])).fetchone()
                return bool(row)
        return True

    def worker_alive(self):
        with self.connection() as conn:
            return bool(conn.execute("SELECT 1 FROM dpw2_worker_status WHERE id='local' AND heartbeat>now()-interval '20 seconds'").fetchone())

    def publish(self, job, state, final=False, version=None):
        state=copy.deepcopy(state)
        with self.connection() as conn:
            # Lock project first, same order as user commands, to avoid cancel deadlocks.
            row = conn.execute('SELECT revision,state FROM dpw2_projects WHERE id=%s FOR UPDATE', (job['project_id'],)).fetchone()
            active = conn.execute("SELECT 1 FROM dpw2_jobs WHERE id=%s AND token=%s AND status='running' FOR UPDATE", (job['id'], job['token'])).fetchone()
            if not active or not row or row[0] != job['revision'] or row[1]['version_id'] != job['version_id']:
                raise Conflict('이전 작업의 결과를 취소했습니다. 최신 판단을 유지합니다.')
            if state['revision'] != job['revision']:
                raise Conflict('작업 버전이 변경되었습니다.')
            if version:
                conn.execute('INSERT INTO dpw2_dataset_versions(id,project_id,manifest) VALUES(%s,%s,%s) ON CONFLICT DO NOTHING', (version['id'], state['id'], Jsonb(version)))
            if final:
                conn.execute("UPDATE dpw2_jobs SET status=%s,token=NULL,error=%s,updated_at=now() WHERE id=%s", ('failed' if state.get('status')=='failed' else 'completed', state.get('error'), job['id']))
                next_kind=state.pop('pending_action',None)
                if next_kind and state.get('status')!='failed':
                    if next_kind not in {'reason','deep'}:raise ValueError('허용되지 않은 후속 작업입니다.')
                    state.update(revision=state['revision']+1,status='queued',ai_status='pending')
                    conn.execute('INSERT INTO dpw2_jobs(id,project_id,kind,request_id,payload,expected_revision,input_version) VALUES(%s,%s,%s,%s,%s,%s,%s)',
                                 (str(uuid.uuid4()),state['id'],next_kind,'after:'+job['id'],Jsonb({}),state['revision'],state['version_id']))
            conn.execute('UPDATE dpw2_projects SET state=%s,revision=%s,updated_at=now() WHERE id=%s', (Jsonb(state),state['revision'],state['id']))
            self._event(conn, state, job['kind'] + ('_completed' if final else '_progress'), {'job_id': job['id'], 'stage':state['stage']})
