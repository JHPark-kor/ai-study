"""Project commands and worker operations. UI never executes a data transformation."""
from __future__ import annotations

import copy
import hashlib
import json
import os
import uuid
import zipfile
from pathlib import Path

import pandas as pd

from studio.config import DATA, MAX_BYTES
from studio.repository import Conflict, Repository, now


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False).encode()).hexdigest()


def project_dir(project_id):
    uuid.UUID(project_id)
    path = DATA / project_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def registered_path(state, value):
    path = Path(value).resolve()
    if not path.is_relative_to(project_dir(state['id']).resolve()):
        raise ValueError('이 작업에 등록되지 않은 파일입니다.')
    return path


def save_frame(frame, path):
    path = Path(path)
    temporary = path.with_suffix('.writing')
    frame.to_pickle(temporary)
    os.replace(temporary, path)


def current_version(state):
    return next(v for v in state['versions'] if v['id'] == state['version_id'])


def read_frame(state):
    # Only our own registered version files are deserialized; uploads are parsed
    # by the bounded text/spreadsheet/archive loaders before this pickle exists.
    version = current_version(state)
    path = registered_path(state, version['path'])
    raw_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    if raw_hash != version['file_hash']:
        raise ValueError('저장된 데이터 파일이 변경되었습니다. 원본과 저장 이력을 확인해 주세요.')
    return pd.read_pickle(path)


def message(role, content, issue_ids=None):
    return dict(id=str(uuid.uuid4()), role=role, content=content, issue_ids=issue_ids or [], created_at=now())


class Service:
    def __init__(self, repository=None):
        self.repo = repository or Repository()

    def create(self, raw, filename, goal='', metadata_raw=None, metadata_name=None, metadata_text='', source_info=None, settings=None):
        if not raw or len(raw) > MAX_BYTES:
            raise ValueError('150MB 이하의 데이터 파일을 선택해 주세요.')
        suffix = Path(filename).suffix.lower()
        if suffix not in {'.csv', '.xlsx', '.txt', '.tsv', '.arff', '.ts', '.zip'}:
            raise ValueError('CSV, XLSX, TXT, TSV, ARFF, TS 또는 ZIP 파일을 지원합니다.')
        settings = copy.deepcopy(settings or {})
        effort = str(settings.get('reasoning_effort') or 'medium').lower()
        if effort not in {'low', 'medium', 'high'}:
            raise ValueError('AI 분석 강도는 빠르게, 균형 있게, 꼼꼼하게 중에서 선택해 주세요.')
        settings['reasoning_effort'] = effort
        if suffix == '.zip':
            from studio.analysis_loader import inspect_archive
            members = inspect_archive(raw)
            if settings.get('archive_member') not in {item['name'] for item in members}:
                raise ValueError('ZIP 안에서 분석할 데이터 파일을 선택해 주세요.')
        if metadata_raw and len(metadata_raw) > 20 * 1024 * 1024:
            raise ValueError('메타데이터 파일은 20MB 이하로 등록해 주세요.')
        pid = str(uuid.uuid4())
        directory = project_dir(pid)
        original = directory / ('original' + suffix)
        original.write_bytes(raw)
        metadata_path = None
        if metadata_raw:
            metadata_path = directory / ('metadata' + Path(metadata_name or 'data.txt').suffix.lower())
            metadata_path.write_bytes(metadata_raw)
        state = dict(id=pid, name=Path(filename).stem[:160], filename=Path(filename).name,
                     original_path=str(original), original_hash=hashlib.sha256(raw).hexdigest(),
                     settings=settings, metadata_path=str(metadata_path) if metadata_path else None,
                     metadata_name=metadata_name, metadata_text=metadata_text[:40000], source_info=source_info or {},
                     goal=goal, context=dict(goal=goal, definitions={}, decisions=[], unresolved=[]),
                     revision=0, version_id='v0', stage='input', status='ready', schema=[], ingest={},
                     profile={}, analysis={}, messages=[], recipes=[], preview=None, lineage=[], versions=[],
                     artifacts=[], ai_status='not_called', error=None, created_at=now(), updated_at=now())
        self.repo.create(state)
        self.repo.command(pid, 0, 'diagnose')
        return pid

    def reply(self, state, text):
        text = text.strip()
        if not text:
            raise ValueError('답변을 입력해 주세요.')
        if len(text) > 12000:
            raise ValueError('한 번에 12,000자 이내로 입력해 주세요.')
        def mutate(s):
            s['messages'].append(message('user', text, s.get('analysis', {}).get('question_issue_ids')))
            s['preview'] = None
            s['artifacts'] = []
            s['ai_status'] = 'pending'
            # A new message resumes review, but does not revoke valid held issues
            # for this same dataset or approve any transformation.
            s['context']['dialogue_stopped'] = False
            s.pop('review_closed_at', None)
            if s['stage'] == 'outputs':
                s['stage'] = 'deep_review' if s.get('profile', {}).get('deep', {}).get('performed') else 'basic_review'
        return self.repo.command(state['id'], state['revision'], 'reply', mutate=mutate)

    def retry(self, state):
        kind = 'diagnose' if not state.get('profile') else ('understand' if state.get('understanding',{}).get('status')=='failed' else 'reason')
        return self.repo.command(state['id'], state['revision'], kind)

    def summarize(self, state):
        # Backfill an existing project without replacing its live question,
        # approvals or dialogue. Only derived downloads are invalidated.
        return self.repo.command(state['id'], state['revision'], 'understand',
                                 {'summary_only': bool(state.get('analysis')), 'resume_status': state['status']},
                                 mutate=lambda s:s.update(artifacts=[],preview=None))

    def preview(self, state, rules):
        if not rules:
            raise ValueError('미리볼 처리 규칙을 선택해 주세요.')
        return self.repo.command(state['id'], state['revision'], 'preview', {'rules': copy.deepcopy(rules)}, mutate=lambda s:s.update(preview=None, artifacts=[]))

    def approve(self, state):
        preview = state.get('preview')
        if not preview or preview['revision'] != state['revision'] or preview['input_version'] != state['version_id']:
            raise Conflict('정의 또는 데이터가 바뀌었습니다. 변경 미리보기를 다시 생성해 주세요.')
        approval = dict(preview_id=preview['id'], manifest_hash=preview['manifest_hash'], input_version=state['version_id'],
                        approved_revision=state['revision'], approved_at=now(), actor='local_user')
        # Idempotency is tied to the exact preview, never to whichever rules are currently selected in the UI.
        return self.repo.command(state['id'], state['revision'], 'apply', approval, request_id='apply:' + preview['id'])

    def advance(self, state):
        if state['stage'] in {'basic_review','profiling'}:
            def continue_deep(s):
                s.update(preview=None,recipes=[],artifacts=[])
                held=s['context'].setdefault('held_issue_ids',[])
                for issue_id in s.get('analysis',{}).get('question_issue_ids',[]):
                    if issue_id not in held:held.append(issue_id)
                s['context']['dialogue_stopped']=False
            return self.repo.command(state['id'], state['revision'], 'deep', mutate=continue_deep)
        def finish(s):
            s.update(review_closed_at=now(),preview=None)
            s['context']['dialogue_stopped']=True
            for issue in s['context'].get('unresolved',[]):
                if isinstance(issue,dict) and issue.get('status')=='open':issue['status']='held'
        return self.repo.command(state['id'],state['revision'],'finish',mutate=finish)

    def export(self, state, title):
        return self.repo.command(state['id'], state['revision'], 'export', {'title':title.strip() or state['name']})

    def cancel(self, state):
        return self.repo.mutate(state['id'], state['revision'], 'canceled', lambda s:s.update(status='canceled', error=None, preview=None), cancel=True)

    def rename_project(self, project, name):
        return self.repo.rename_project(project['id'],project['revision'],name)

    def archive_project(self, project):
        return self.repo.archive_project(project['id'],project['revision'])

    def restore_project(self, project):
        return self.repo.restore_project(project['id'])

    def restore(self, state, target_id):
        def restore(s):
            version = next((v for v in s['versions'] if v['id']==target_id), None)
            if not version:
                raise ValueError('선택한 버전을 찾지 못했습니다.')
            context = s['context']
            if context.get('unresolved') or context.get('held_issue_ids') or context.get('dialogue_stopped'):
                # Preserve the previous review as history, not as live issues
                # that could suppress questions on a different dataset version.
                context.setdefault('review_history', []).append(dict(
                    version_id=s['version_id'], restored_to=target_id, archived_at=now(),
                    review_closed_at=s.get('review_closed_at'),
                    unresolved=copy.deepcopy(context.get('unresolved', [])),
                    held_issue_ids=copy.deepcopy(context.get('held_issue_ids', []))))
            s.update(version_id=target_id, schema=copy.deepcopy(version['schema']), lineage=copy.deepcopy(version['lineage']),
                     profile=copy.deepcopy(version.get('profile',{})), recipes=[], preview=None, artifacts=[],
                     stage='basic_review', status='ready', ai_status='not_called', analysis={},investigation_cache={})
            # Restore version-dependent meanings; retain project goal and conversation as historical evidence.
            s['context']['definitions'] = copy.deepcopy(version.get('definitions', {}))
            s['context']['decisions'] = [d for d in s['context'].get('decisions',[]) if d.get('scope')=='project']
            s['context'].update(dialogue_stopped=False, unresolved=[], held_issue_ids=[])
            s['understanding']=copy.deepcopy(version.get('understanding',{}))
            for key in ('dataset_description','analysis_uses','observation_unit'):
                s['context'].pop(key,None)
                if key in version.get('understanding_context',{}):
                    s['context'][key]=copy.deepcopy(version['understanding_context'][key])
            s.pop('review_closed_at', None)
            s['messages'].append(message('assistant', f"{version['label']}으로 복원했습니다. 해당 버전의 단위와 컬럼 정의를 함께 불러왔습니다."))
        return self.repo.mutate(state['id'], state['revision'], 'restored', restore, cancel=True)


class Processor:
    def __init__(self, repository=None, analyst=None, describer=None):
        self.repo = repository or Repository()
        self.analyst = analyst
        self.describer = describer

    def checkpoint(self, job, state):
        state['status'] = 'running'
        self.repo.publish(job, state)

    def run(self, job):
        state = self.repo.load(job['project_id'])
        if state['revision'] != job['revision']:
            raise Conflict('작업이 이미 변경되었습니다.')
        try:
            kind = job['kind']
            version = None
            if kind == 'diagnose':
                self.diagnose(job, state)
                version = current_version(state)
            elif kind == 'understand':
                self.understand(job,state)
                if state.get('understanding',{}).get('status')=='completed':
                    if job.get('payload',{}).get('summary_only'):
                        state['status']='needs_input' if state.get('analysis',{}).get('question') else 'ready'
                    else:
                        state.update(stage='basic_review',pending_action='reason')
            elif kind in {'reply','reason'}:
                self.reason(job, state, read_frame(state), 'followup' if kind=='reply' else ('deep' if state['stage']=='deep_review' else 'basic'))
            elif kind == 'deep':
                from studio.analysis import profile_dataset
                state.update(stage='deep_review', profile=profile_dataset(read_frame(state), state['schema'], state['context'], deep=True))
                state['investigation_cache']={}
                self.checkpoint(job,state)
                self.reason(job,state,read_frame(state),'deep')
            elif kind == 'preview':
                self.make_preview(job,state)
            elif kind == 'apply':
                version = self.apply(job,state)
            elif kind == 'export':
                self.export(job,state)
            elif kind == 'finish':
                held=copy.deepcopy(state['context'].get('unresolved',[]))
                self.reason(job,state,read_frame(state),'synthesis')
                state.update(stage='outputs',review_closed_at=now())
                state['analysis']['question']=None
                unresolved={i['id']:i for i in state['context'].get('unresolved',[]) if isinstance(i,dict)}
                for issue in held:
                    if isinstance(issue,dict):unresolved[issue['id']]=issue
                state['context']['unresolved']=list(unresolved.values())
                state['analysis']['unresolved']=copy.deepcopy(state['context']['unresolved'])
            else:
                raise ValueError('지원하지 않는 작업입니다.')
            if state.get('status') == 'running' or state.get('status') == 'queued':
                state['status'] = 'ready'
            state['error'] = None
            if kind=='apply':state['pending_action']='reason'
            elif kind in {'reason','reply','deep'} and state.get('ai_status')=='completed' and state['status']=='ready' and not state.get('recipes'):
                if state['stage']=='basic_review':state['pending_action']='deep'
                elif state['stage']=='deep_review':state['stage']='outputs'
            self.repo.publish(job,state,final=True,version=version)
        except Conflict as exc:
            failed=self.repo.load(job['project_id'])
            if failed['revision']==job['revision'] and failed['version_id']==job['version_id']:
                failed.update(status='failed',error=str(exc))
                try:self.repo.publish(job,failed,final=True)
                except Conflict:pass  # Canceled or replaced lease cannot publish even a failure.
            raise
        except Exception as exc:
            # Recover the most recent checkpoint rather than losing completed profiling after an AI failure.
            current = self.repo.load(job['project_id'])
            if current['revision'] != job['revision']:
                raise Conflict('작업이 취소되거나 변경되었습니다.') from exc
            current.update(status='failed', error=f'{type(exc).__name__}: {str(exc)[:700]}')
            self.repo.publish(job,current,final=True)

    def diagnose(self, job, state):
        from studio.analysis import load_dataset, profile_dataset, read_metadata
        from studio.cleaning import hash_frame
        raw = registered_path(state,state['original_path']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != state['original_hash']:
            raise ValueError('원본 파일의 해시가 일치하지 않습니다.')
        frame,schema,ingest = load_dataset(raw,state['filename'],state['settings'])
        metadata_raw = registered_path(state,state['metadata_path']).read_bytes() if state.get('metadata_path') else None
        meta = read_metadata(metadata_raw,state.get('metadata_name'),state.get('metadata_text',''),schema)
        context = state['context']
        context.update({k:v for k,v in state['source_info'].items() if v})
        context.update({k:v for k,v in meta.items() if k not in {'definitions','warnings','unmatched'} and v})
        context['definitions'] = meta.get('definitions',{})
        context['metadata_text'] = '\n\n'.join(str(value) for value in [meta.get('text',''),meta.get('source_text',''),state.get('metadata_text','')] if value)[:40000]
        context['ingest'] = ingest
        for column in schema:
            definition = context['definitions'].get(column['id'],{})
            for key in ('description','unit','role','code_values'):
                if key in definition and definition[key] is not None:
                    column[key]=definition[key]
        state.update(schema=schema,ingest=ingest,metadata_warnings=meta.get('warnings',[]),metadata_unmatched=meta.get('unmatched',[]),stage='profiling')
        # Every uploaded file gets its own bounded quality baseline immediately.
        # This includes missingness patterns and relationship checks selected
        # from the current schema; it does not modify the data.
        state['profile']=profile_dataset(frame,schema,context,deep=True)
        path=project_dir(state['id'])/('v0-'+job['token'][:12]+'.pkl')
        save_frame(frame,path)
        version=dict(id='v0',label='원본',path=str(path),schema=copy.deepcopy(schema),file_hash=hashlib.sha256(path.read_bytes()).hexdigest(),
                     frame_hash=hash_frame(frame,schema),parent_id=None,lineage=[],profile=copy.deepcopy(state['profile']),definitions=copy.deepcopy(context['definitions']))
        state['versions']=[version]
        self.checkpoint(job,state)
        state['stage']='basic_review'
        self.understand(job,state)
        if state.get('understanding',{}).get('status')=='completed':
            state['pending_action']='reason'

    def understand(self,job,state):
        from studio.understanding import describe, BATCH_SIZE
        describer=self.describer or describe
        frame=read_frame(state)
        saved=state.setdefault('understanding',{})
        if saved.get('version_id')!=state['version_id']:
            saved.clear()
        saved.update(version_id=state['version_id'],status='pending',error=None)
        completed=set(saved.get('completed_columns',[]))
        remaining=[c['id'] for c in state['schema'] if c['id'] not in completed]
        self.checkpoint(job,state)
        try:
            for start in range(0,len(remaining),BATCH_SIZE):
                ids=remaining[start:start+BATCH_SIZE]
                call_context=copy.deepcopy(state['context'])
                call_context['_ai_settings']=copy.deepcopy(state.get('settings',{}))
                result=describer(call_context,state['profile'],ids)
                if not completed:
                    state['context'].update(dataset_description=result['dataset_description'],analysis_uses=result['analysis_uses'])
                    if not state['context'].get('observation_unit'):
                        state['context']['observation_unit']=result['observation_unit']
                definitions=state['context'].setdefault('definitions',{})
                for item in result['columns']:
                    cid=item['column_id']
                    # Existing user/metadata/validated review definitions win.
                    if not definitions.get(cid,{}).get('description'):
                        definitions.setdefault(cid,{}).update(description=item['description'],basis='inference',certainty=item['certainty'])
                    column=next(c for c in state['schema'] if c['id']==cid)
                    column['description']=definitions[cid]['description']
                    for pc in state['profile'].get('columns',[]):
                        if pc['id']==cid:pc['description']=column['description']
                completed.update(ids)
                request_metrics=saved.get('request_metrics')
                if not isinstance(request_metrics,list):
                    request_metrics=[]
                    saved['request_metrics']=request_metrics
                if result.get('request_metrics'):
                    request_metrics.append(copy.deepcopy(result['request_metrics']))
                saved.update(completed_columns=sorted(completed),model=result.get('model'),source=result.get('source'),updated_at=now())
                self.save_understanding(state,frame)
                self.checkpoint(job,state)
            saved.update(status='completed',completed_at=now())
            state['status']='ready'
            self.save_understanding(state,frame)
        except Conflict:
            raise
        except Exception as exc:
            saved.update(status='failed',error=str(exc)[:700],error_code=getattr(exc,'code','analysis'))
            state['status']='partial'
            self.save_understanding(state,frame)

    @staticmethod
    def save_understanding(state,frame):
        from studio.cleaning import hash_frame
        version=current_version(state)
        version.update(schema=copy.deepcopy(state['schema']),profile=copy.deepcopy(state['profile']),
                       definitions=copy.deepcopy(state['context']['definitions']),
                       understanding=copy.deepcopy(state.get('understanding',{})),
                       understanding_context={k:copy.deepcopy(state['context'][k]) for k in ('dataset_description','analysis_uses','observation_unit') if k in state['context']})
        version['frame_hash']=hash_frame(frame,state['schema'])

    def reason(self,job,state,frame,phase):
        from studio.analysis import ALGORITHM_VERSION, investigate, profile_dataset
        from studio.ai import analyze, AIValidationError
        from studio.cleaning import hash_frame
        analyst=self.analyst or analyze
        state.update(ai_status='pending', ai_error=None, ai_error_code=None)
        self.checkpoint(job,state)
        # Projects created by an earlier app version may only contain the
        # univariate profile. Upgrade them before the next AI review so the
        # current dataset receives the same missingness and cleaning baseline
        # without asking the user to upload it again.
        if (state.get('profile',{}).get('algorithm_version') != ALGORITHM_VERSION
                or not state.get('profile',{}).get('deep',{}).get('performed')):
            state['profile']=profile_dataset(frame,state['schema'],state['context'],deep=True)
            state['investigation_cache']={}
            self.checkpoint(job,state)
        previous_result=state.get('analysis',{})
        review_phase='deep' if state['stage']=='deep_review' else 'basic'
        # One user action makes one model generation request. Deterministic
        # follow-up checks are still saved, but their interpretation continues
        # on the next user-triggered turn instead of an automatic model loop.
        max_rounds=1
        cache=state.setdefault('investigation_cache',{})
        failures=[]

        def pending_issue(identifier,title,reason,columns=None):
            return dict(id=identifier,title=title,reason=reason,status='needs_check',columns=columns or [])

        try:
            for iteration in range(max_rounds):
                context=copy.deepcopy(state['context'])
                context.update(goal=state['goal'], dataset_version=state['version_id'], context_revision=state['revision'],
                               version_id=state['version_id'],revision=state['revision'],schema=state['schema'],
                               review_phase=review_phase, latest_analysis=previous_result,
                               investigation_history=list(cache.values()),
                               _ai_settings=copy.deepcopy(state.get('settings',{})))
                result=analyst(context,state['profile'],state['messages'],phase=phase,thread_id=state.get('thread_id'))
                state['thread_id']=result.get('thread_id')
                if result.get('account_fingerprint'):
                    state['context']['account_fingerprint']=result['account_fingerprint']
                if 'analysis_uses' in result:
                    state['context']['analysis_uses']=result['analysis_uses']
                patch=result.get('context_patch') or {}
                for key in ('goal','observation_unit','source','collection_period','dataset_description'):
                    # Response metadata (notably source='codex') describes the
                    # producer of this response, not the dataset's provenance.
                    value=patch.get(key)
                    if key=='dataset_description' and value is None:
                        value=result.get('dataset_description')
                    if value:
                        state['context'][key]=value
                        if key=='goal': state['goal']=value
                old_roles={c['id']:c['role'] for c in state['schema']}
                definitions=result.get('definitions') or patch.get('definitions') or {}
                valid_ids={c['id'] for c in state['schema']}
                for cid,definition in definitions.items():
                    if cid not in valid_ids: continue
                    state['context']['definitions'].setdefault(cid,{}).update(definition)
                    column=next(c for c in state['schema'] if c['id']==cid)
                    for key in ('description','unit','role','code_values'):
                        if key in definition and definition[key] is not None: column[key]=definition[key]
                for decision in result.get('decisions') or []:
                    decisions=state['context']['decisions']
                    existing=next((i for i,d in enumerate(decisions) if d.get('id') and d.get('id')==decision.get('id')),None)
                    if existing is not None: decisions[existing]=decision
                    elif decision not in decisions: decisions.append(decision)
                state['context']['unresolved']=result.get('unresolved',[])
                # Labels/units are semantic updates; synchronize presentation without recalculating values.
                for profile_column in state['profile'].get('columns',[]):
                    definition=next((c for c in state['schema'] if c['id']==profile_column['id']),None)
                    if definition:
                        for key in ('name','unit','description'):
                            if key in definition:profile_column[key]=definition[key]
                        if profile_column.get('chart') is not None:profile_column['chart']['unit']=definition.get('unit','')
                previous_result=result
                if any(c['role'] != old_roles[c['id']] for c in state['schema']):
                    # A changed role can alter the applicable missingness,
                    # key, time, or relationship checks. Rebuild the same full
                    # baseline instead of falling back to a basic-only profile.
                    state['profile']=profile_dataset(frame,state['schema'],state['context'],deep=True)
                    # Old findings and recipes reference the previous profile.
                    # Keep the accepted meanings, but never publish stale facts.
                    state.update(analysis={},recipes=[])
                    cache.clear()
                    self.checkpoint(job,state)
                    if iteration==max_rounds-1:
                        result['findings']=[]
                        result['recipes']=[]
                        result['investigations']=[]
                        failures.append(pending_issue(
                            'definition_reassessment','최신 진단 해석 대기',
                            '컬럼 역할을 반영해 프로파일을 다시 계산했습니다. 다음 요청에서 최신 결과를 해석합니다.'))
                        state['analysis']=result
                        state['recipes']=[]
                        break
                    phase='reassess'
                    continue
                current_evidence={e['id'] for e in state['profile'].get('evidence',[])}
                for item in result.get('findings',[])+result.get('recipes',[]):
                    if any(eid not in current_evidence for eid in item.get('evidence_ids',[])):
                        raise AIValidationError('현재 데이터 진단과 일치하지 않는 근거가 포함되었습니다.')
                state['analysis']=result
                state['recipes']=result.get('recipes',[])
                requests=result.get('investigations') or []
                if not requests:
                    break
                new_evidence=False
                for request in requests[:8]:
                    signature=digest(dict(version=state['version_id'],schema=state['schema'],
                                          kind=request.get('kind'),columns=request.get('columns'),params=request.get('params',{})))
                    if signature in cache:
                        continue
                    try:
                        evidence=investigate(frame,state['schema'],request,state['context'])
                        by_id={e['id']:e for e in state['profile'].get('evidence',[])}
                        before=set(by_id)
                        by_id.update({e['id']:e for e in evidence})
                        state['profile']['evidence']=list(by_id.values())
                        cache[signature]=dict(kind=request.get('kind'),columns=request.get('columns'),params=request.get('params',{}),
                                              evidence_ids=[e['id'] for e in evidence],status='completed')
                        new_evidence |= set(by_id)!=before
                    except (ValueError,TypeError,KeyError) as exc:
                        # A malformed optional check must not erase all valid
                        # measurements or turn into a successful check.
                        issue=pending_issue('check_'+signature[:12],'추가 검사 확인 필요',str(exc)[:250],request.get('columns',[]))
                        failures.append(issue)
                        cache[signature]=dict(kind=request.get('kind'),columns=request.get('columns'),params=request.get('params',{}),
                                              evidence_ids=[],status='failed',reason=issue['reason'])
                if len(requests)>8:
                    failures.append(pending_issue('remaining_investigations','추가 검사 대기','한 번에 실행할 검사 수를 넘었습니다. 나머지 검사는 다음 대화에서 이어갈 수 있습니다.'))
                if iteration==max_rounds-1:
                    if new_evidence:
                        failures.append(pending_issue(
                            'pending_investigations','추가 검사 해석 대기',
                            '요청된 추가 검사를 계산했습니다. 다음 요청에서 결과를 해석합니다.'))
                    break
                if not new_evidence and not failures:
                    # The model repeated only already computed checks. It can
                    # use their saved evidence in this result without rerunning.
                    break
                phase='reassess'
                self.checkpoint(job,state)
            if failures:
                unresolved={item['id']:item for item in result.get('unresolved',[]) if isinstance(item,dict)}
                unresolved.update({item['id']:item for item in failures})
                result['unresolved']=list(unresolved.values())
                state['context']['unresolved']=copy.deepcopy(result['unresolved'])
                result['completion_reason']='실행된 검사 결과를 정리했습니다. 수행하지 못한 추가 검사는 미확정 사항에 남겼습니다.'
            state.update(ai_status='completed',ai_model=result.get('model'),ai_completed_at=now(),status='needs_input' if result.get('question') else 'ready')
            parts=[result.get('summary',''),result.get('question','')]
            content='\n\n'.join(str(x).strip() for x in parts if x)
            if content:
                state['messages'].append(message('assistant',content,result.get('question_issue_ids')))
            v=current_version(state)
            v.update(schema=copy.deepcopy(state['schema']),definitions=copy.deepcopy(state['context']['definitions']),
                     profile=copy.deepcopy(state['profile']),frame_hash=hash_frame(frame,state['schema']))
            self.save_understanding(state,frame)
        except Conflict:
            raise
        except Exception as exc:
            state.update(ai_status='failed',ai_error=str(exc)[:700],ai_error_code=getattr(exc,'code','analysis'),
                         ai_retryable=getattr(exc,'retryable',True),status='partial',recipes=[])
            # Preserve the user's raw answer and completed statistics for a targeted retry.
            state.setdefault('analysis',{})['question']=None

    def make_preview(self,job,state):
        from studio.cleaning import preview
        frame=read_frame(state)
        output=preview(frame,state['schema'],job['payload']['rules'],state['context'])
        preview_id=str(uuid.uuid4())
        path=project_dir(state['id'])/(preview_id+'.pkl')
        save_frame(output['frame'],path)
        state['preview']=dict(id=preview_id,revision=state['revision'],input_version=state['version_id'],
                              manifest=output['manifest'],manifest_hash=digest(output['manifest']),impact=output['impact'],
                              frame_hash=output['frame_hash'],schema=output['schema'],path=str(path),created_at=now())
        state['status']='needs_approval'

    def apply(self,job,state):
        from studio.cleaning import apply_manifest, hash_frame
        from studio.analysis import profile_dataset
        approval=job['payload']; p=state.get('preview')
        if not p or p['id']!=approval['preview_id'] or p['manifest_hash']!=approval['manifest_hash'] or digest(p['manifest'])!=p['manifest_hash']:
            raise Conflict('승인한 미리보기와 처리 규칙이 일치하지 않습니다.')
        if p['revision']!=approval['approved_revision'] or state['revision']!=approval['approved_revision']+1 or p['input_version']!=state['version_id']:
            raise Conflict('승인 이후 데이터나 정의가 변경되었습니다.')
        frame,schema=apply_manifest(read_frame(state),state['schema'],p['manifest'])
        if hash_frame(frame,schema)!=p['frame_hash']:
            raise ValueError('실행 결과가 승인한 미리보기와 일치하지 않습니다. 이전 버전을 유지합니다.')
        version_id='v'+str(max(int(v['id'][1:]) for v in state['versions'])+1)
        path=project_dir(state['id'])/(version_id+'-'+job['token'][:8]+'.pkl')
        save_frame(frame,path)
        entry=dict(version_id=version_id,parent_version=state['version_id'],input_schema=copy.deepcopy(state['schema']),
                   manifest=p['manifest'],impact=p['impact'],approval=approval,approved_at=approval['approved_at'])
        lineage=state['lineage']+[entry]
        definitions=copy.deepcopy(state['context']['definitions'])
        for col in schema:
            definitions.setdefault(col['id'],{}).update({k:col.get(k) for k in ('role','unit','description') if col.get(k) is not None})
        definitions={k:v for k,v in definitions.items() if k in {c['id'] for c in schema}}
        state['context']['definitions']=definitions
        profile=profile_dataset(frame,schema,state['context'],deep=True)
        version=dict(id=version_id,label=f'정제 {version_id[1:]}',parent_id=state['version_id'],path=str(path),
                     file_hash=hashlib.sha256(path.read_bytes()).hexdigest(),frame_hash=hash_frame(frame,schema),schema=copy.deepcopy(schema),
                     definitions=definitions,lineage=lineage,profile=profile)
        state.setdefault('review_history',[]).append(dict(version_id=state['version_id'],analysis=copy.deepcopy(state['analysis'])))
        state.update(version_id=version_id,schema=schema,profile=profile,lineage=lineage,preview=None,recipes=[],artifacts=[],analysis={},stage='deep_review',status='ready',ai_status='not_called')
        state['versions'].append(version)
        state['messages'].append(message('assistant',f'승인한 규칙을 {version_id}에 적용하고 다시 점검했습니다. 원본은 그대로 보관했습니다.'))
        return version

    def export(self,job,state):
        from studio.exports import build_exports
        out=project_dir(state['id'])/('exports-'+str(state['revision'])+'-'+job['token'][:12])
        out.mkdir(exist_ok=True)
        raw=registered_path(state,state['original_path']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=state['original_hash']:
            raise ValueError('원본 파일이 변경되어 산출물 생성을 중단했습니다.')
        state['artifacts']=build_exports(state,read_frame(state),raw,out,job['payload']['title'])
        bundle=out/'dataprep-results.zip'
        with zipfile.ZipFile(bundle,'w',compression=zipfile.ZIP_DEFLATED) as archive:
            for artifact in state['artifacts']:
                item=registered_path(state,artifact['path'])
                archive.write(item,item.name)
        state['artifacts'].insert(0,dict(kind='bundle',label='전체 결과 받기 · ZIP',path=str(bundle),mime='application/zip',
                                       version_id=state['version_id'],revision=state['revision'],sha256=hashlib.sha256(bundle.read_bytes()).hexdigest()))
        state.update(stage='outputs',status='ready')
