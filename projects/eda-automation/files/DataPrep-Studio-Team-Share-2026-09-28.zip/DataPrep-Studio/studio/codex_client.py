"""ChatGPT managed authentication and analysis-only Codex App Server transport.

One client owns one process and one serial request stream. Credentials remain in
Codex's credential store; this module never reads or copies credential files.
"""
from __future__ import annotations

import atexit
from collections import deque
import hashlib
import json
import os
from pathlib import Path
import queue
import re
import shutil
import subprocess
import threading
import time
from urllib.parse import urlparse

from studio.config import RUNTIME, ROOT


class CodexError(RuntimeError):
    def __init__(self, message, code="connection", retryable=True):
        super().__init__(message)
        self.code = code
        self.retryable = retryable


def _failure(detail):
    """Classify server errors without exposing OAuth state or credentials."""
    text = str(detail).lower()
    if "invalid transport" in text or "failed to load configuration" in text or "invalid config" in text:
        return CodexError("Codex 분석 세션의 연결 설정 형식이 올바르지 않습니다. 앱의 연결 설정을 확인해 주세요.", "configuration", False)
    if any(word in text for word in ("rate limit", "usage limit", "quota", "credits", "limit reached")):
        return CodexError("Codex 사용 한도에 도달했습니다. 한도 초기화 후 다시 실행해 주세요.", "usage_limit", False)
    if any(word in text for word in ("unauthorized", "token_exchange", "authentication", "401", "not authenticated")):
        return CodexError("Codex 인증을 완료하지 못했습니다. ChatGPT 로그인 상태와 네트워크를 확인해 주세요.", "authentication", False)
    if any(word in text for word in ("not found", "no rollout", "unknown thread")):
        return CodexError("이전 Codex 대화를 찾지 못했습니다.", "thread_missing")
    if any(word in text for word in ("timeout", "timed out", "deadline")):
        return CodexError("Codex 응답 시간이 초과되었습니다. 계산 결과는 보존되며 다시 요청할 수 있습니다.", "timeout")
    if any(word in text for word in ("error sending", "network", "connection", "dns", "tls", "certificate")):
        return CodexError("Codex 서버에 연결하지 못했습니다. 인터넷 연결과 프록시 설정을 확인해 주세요.", "network")
    if any(word in text for word in ("invalid schema", "output schema", "invalid params", "unsupported", "unknown variant")):
        return CodexError("설치된 Codex가 분석 요청 형식을 처리하지 못했습니다. Codex를 업데이트한 뒤 다시 실행해 주세요.", "protocol", False)
    return CodexError("Codex가 분석을 완료하지 못했습니다. 다시 실행해도 계속되면 연결 상태를 확인해 주세요.", "inference")


def executable():
    explicit = os.getenv("CODEX_EXECUTABLE", "").strip()
    if explicit:
        if Path(explicit).is_file() and (os.name != "nt" or Path(explicit).suffix.lower() == ".exe"):
            return explicit
        raise CodexError("CODEX_EXECUTABLE에 올바른 Codex 실행 파일 경로를 설정해 주세요.", "executable", False)
    candidates = []
    local = os.getenv("LOCALAPPDATA")
    if local:
        root = Path(local) / "OpenAI" / "Codex" / "bin"
        candidates = [root / "codex.exe", *root.glob("*/codex.exe")]
    candidates = [p for p in candidates if p.is_file()]
    if candidates:
        return str(max(candidates, key=lambda p: p.stat().st_mtime_ns))
    found = shutil.which("codex.exe" if os.name == "nt" else "codex")
    if found:
        return found
    npm = Path(os.getenv("APPDATA", "")) / "npm/node_modules/@openai/codex"
    candidates = list(npm.glob("**/bin/codex.exe"))
    if candidates:
        return str(max(candidates, key=lambda p: p.stat().st_mtime_ns))
    raise CodexError("Codex 실행 파일을 찾지 못했습니다. Codex를 설치하거나 실행 파일 경로를 설정해 주세요.", "executable", False)


def child_environment():
    env = dict(os.environ)
    for key in list(env):
        if key.upper().startswith("PG") or "API_KEY" in key.upper() or key.upper() in {"DATABASE_URL", "CODEX_ACCESS_TOKEN"}:
            env.pop(key, None)
    # Bundled Codex builds can resolve a different credential location when
    # launched outside the desktop process. Pin the conventional per-user
    # directory unless the current user explicitly configured another one.
    # This selects the local Windows user's login without copying credentials.
    if not env.get("CODEX_HOME"):
        user_home = env.get("USERPROFILE") or str(Path.home())
        env["CODEX_HOME"] = str(Path(user_home) / ".codex")
    return env


def safe_login_url(value):
    if not isinstance(value, str):
        raise CodexError("로그인 주소를 받지 못했습니다.", "login_url", False)
    try:
        parsed = urlparse(value.strip())
        host = (parsed.hostname or "").lower().rstrip(".")
        allowed = host in {"openai.com", "chatgpt.com"} or host.endswith((".openai.com", ".chatgpt.com"))
        if parsed.scheme != "https" or not allowed or parsed.username or parsed.password or parsed.port not in (None, 443):
            raise ValueError()
    except ValueError:
        raise CodexError("Codex 로그인 주소를 확인하지 못했습니다.", "login_url", False) from None
    return value.strip()


def reasoning_effort(requested=None):
    """Product-level setting; do not inherit development-session effort."""
    effort = str(requested or "").strip().lower()
    if not effort:
        effort = os.getenv("CODEX_REASONING_EFFORT", "").strip().lower() or "medium"
    if effort not in {"low", "medium", "high", "xhigh", "ultra"}:
        raise CodexError("CODEX_REASONING_EFFORT는 low, medium, high, xhigh, ultra 중 하나로 설정해 주세요.",
                         "configuration", False)
    return effort


class CodexClient:
    def __init__(self, effort=None, model=None):
        self.requested_effort = effort
        self.requested_model = model
        self.messages = queue.Queue()
        self.events = deque()
        self.sequence = 0
        self.lock = threading.RLock()
        self.close_lock = threading.Lock()
        self.proc = None
        self.reader = None
        self.stream_closer = None

    def __enter__(self):
        self.cwd = RUNTIME.resolve()
        if self.cwd == ROOT.parent.resolve() or ROOT.parent.resolve() in self.cwd.parents:
            raise CodexError("분석 실행 폴더는 프로젝트 소스 밖의 임시 폴더로 설정해 주세요.", "runtime_path", False)
        self.cwd.mkdir(parents=True, exist_ok=True)
        overrides = {
            "forced_login_method": "chatgpt", "web_search": "disabled",
            "features.shell_tool": False, "features.unified_exec": False,
            "features.apps": False, "features.multi_agent": False,
            "features.hooks": False, "features.memories": False,
            "features.skill_mcp_dependency_install": False,
            "apps._default.enabled": False,
            "sandbox_mode": "read-only", "approval_policy": "never",
        }
        args = [executable()]
        for key, value in overrides.items():
            args.extend(["-c", f"{key}={json.dumps(value)}"])
        args.extend(["app-server", "--listen", "stdio://"])
        try:
            self.proc = subprocess.Popen(args, cwd=self.cwd, env=child_environment(),
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                text=True, encoding="utf-8", bufsize=1,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            self.reader = threading.Thread(target=self._read, args=(self.proc,), daemon=True)
            self.reader.start()
            self.call("initialize", {"clientInfo": {"name": "dataprep_studio", "version": "0.1.0"}})
            self.send({"method": "initialized", "params": {}})
        except OSError:
            self.close()
            raise CodexError("Codex 프로세스를 시작하지 못했습니다. 실행 파일 경로와 접근 권한을 확인해 주세요.", "executable", False) from None
        except Exception:
            self.close()
            raise
        return self

    def _read(self, proc):
        try:
            # Keep the owned process locally: close() clears self.proc while
            # this reader may still be waiting for EOF from an inherited pipe.
            for line in proc.stdout:
                try:
                    msg = json.loads(line)
                    if isinstance(msg, dict):
                        self.messages.put(msg)
                except (ValueError, TypeError):
                    continue
        except (OSError, ValueError):
            pass
        finally:
            self.messages.put(None)

    def send(self, message):
        try:
            self.proc.stdin.write(json.dumps(message, ensure_ascii=False, allow_nan=False) + "\n")
            self.proc.stdin.flush()
        except (OSError, ValueError, AttributeError):
            raise CodexError("Codex 연결이 종료되었습니다. 다시 연결해 주세요.", "connection_closed") from None

    def receive(self, timeout):
        try:
            msg = self.messages.get(timeout=max(0.01, timeout))
        except queue.Empty:
            raise _failure("timeout") from None
        if msg is None:
            raise CodexError("Codex App Server가 종료되었습니다. 실행 환경을 확인해 주세요.", "connection_closed")
        if "method" in msg and "id" in msg:
            self.send({"id": msg["id"], "error": {"code": -32601,
                "message": "This analysis client denies all tools, approvals, and external actions."}})
        return msg

    def call(self, method, params, timeout=30):
        with self.lock:
            self.sequence += 1
            request_id = self.sequence
            self.send({"id": request_id, "method": method, "params": params})
            deadline = time.monotonic() + timeout
            while True:
                msg = self.receive(deadline - time.monotonic())
                if msg.get("id") == request_id and "method" not in msg:
                    if "error" in msg:
                        server_error = msg["error"] or {}
                        error = _failure(server_error.get("message", "protocol error"))
                        rpc_code = server_error.get("code")
                        if error.code == "inference" and rpc_code in {-32600, -32601, -32602}:
                            error = CodexError("Codex가 요청 형식을 처리하지 못했습니다. 앱과 Codex의 연결 설정을 확인해 주세요.", "protocol", False)
                        error.rpc_method = method
                        error.rpc_code = rpc_code if isinstance(rpc_code, int) else None
                        # Method names and numeric protocol codes are generated
                        # by this client/server, not account or request content.
                        error.args = (str(error) + f" (단계: {method}, 코드: {error.rpc_code})",)
                        raise error
                    return msg.get("result", {})
                self.events.append(msg)
                if time.monotonic() >= deadline:
                    raise _failure("timeout")

    def account(self, refresh=False):
        result = self.call("account/read", {"refreshToken": bool(refresh)})
        account = result.get("account") or {}
        identity = [account.get(k) for k in ("id", "accountId", "chatgptAccountId", "workspaceId", "email")]
        identity = [str(v).strip().lower() for v in identity if v]
        fingerprint = hashlib.sha256("|".join(identity).encode()).hexdigest() if identity else None
        mode = account.get("type", "not_logged_in")
        return {"mode": mode, "plan": account.get("planType"), "account_fingerprint": fingerprint,
                "connected": mode == "chatgpt"}

    def _tool_config(self):
        # Read only the shape of configured integrations. Never return or log
        # their values. Disable inherited MCP servers/apps in this thread only.
        effective = self.call("config/read", {"includeLayers": False}).get("config", {})
        result = {"web_search": "disabled", "features.shell_tool": False,
                  "features.unified_exec": False, "features.apps": False,
                  "features.multi_agent": False, "features.hooks": False,
                  "apps._default.enabled": False}
        for key in ("mcp_servers", "apps"):
            entries = effective.get(key) or {}
            if any(not re.fullmatch(r"[A-Za-z0-9_-]+", name) for name in entries):
                # Literal dotted names cannot use the dotted-path form. Send a
                # complete nested table so transport settings remain intact.
                result[key] = {name: {**value, "enabled": False} for name, value in entries.items() if isinstance(value, dict)}
                continue
            for name in entries:
                if isinstance(name, str) and name != "_default":
                    # App Server config keys are dotted paths, not TOML source.
                    # JSON quotes become literal name characters and create an
                    # incomplete MCP entry ("invalid transport" at thread/start).
                    result[f"{key}.{name}.enabled"] = False
        return result

    def _account_model(self, effort):
        """Choose a model exposed to the currently authenticated ChatGPT account."""
        configured = str(self.requested_model or "").strip() or os.getenv("CODEX_MODEL", "").strip()
        try:
            result = self.call("model/list", {})
        except CodexError as exc:
            # Older App Server builds may not expose model/list. Preserve an
            # explicit product setting, but never guess a model name.
            if configured:
                return configured
            if getattr(exc, "rpc_code", None) == -32601:
                return None
            raise
        models = [entry for entry in result.get("data", []) if isinstance(entry, dict) and not entry.get("hidden")]

        def model_id(entry):
            return str(entry.get("model") or entry.get("id") or "").strip()

        def supports(entry):
            supported = entry.get("supportedReasoningEfforts") or []
            values = {item.get("reasoningEffort") for item in supported if isinstance(item, dict)}
            return not values or effort in values

        if configured:
            selected = next((entry for entry in models if model_id(entry) == configured), None)
            if not selected or not supports(selected):
                raise CodexError("설정한 Codex 모델 또는 추론 강도를 현재 ChatGPT 계정에서 사용할 수 없습니다. 연결 설정을 확인해 주세요.",
                                 "model_access", False)
            return configured
        selected = next((entry for entry in models if entry.get("isDefault") and supports(entry)), None)
        selected = selected or next((entry for entry in models if supports(entry)), None)
        if not selected or not model_id(selected):
            raise CodexError("현재 ChatGPT 계정에서 사용할 수 있는 Codex 모델을 확인하지 못했습니다.", "model_access", False)
        return model_id(selected)

    def interpret(self, prompt, instructions, output_schema=None, thread_id=None, account_fingerprint=None):
        effort = reasoning_effort(self.requested_effort)
        with self.lock:
            account = self.account()
            if not account["connected"]:
                raise CodexError("ChatGPT 로그인이 필요합니다. 연결 설정에서 로그인한 뒤 다시 실행해 주세요.", "not_logged_in", False)
            # Unknown identity also starts a fresh conversation: never resume a
            # different account's history just because a thread ID was retained.
            reset = bool(thread_id and (not account_fingerprint or account_fingerprint != account["account_fingerprint"]))
            resume_id = None if reset else thread_id
            params = {"cwd": str(self.cwd), "approvalPolicy": "never", "sandbox": "read-only",
                      "developerInstructions": instructions, "config": self._tool_config()}
            model = self._account_model(effort)
            if model:
                params["model"] = model
            try:
                result = self.call("thread/resume", {**params, "threadId": resume_id}) if resume_id else self.call("thread/start", params)
            except CodexError as exc:
                if not resume_id or exc.code != "thread_missing":
                    raise
                reset = True
                result = self.call("thread/start", params)
            tid = result["thread"]["id"]
            # Fail before inference if repository instructions leaked into the
            # product session despite its isolated cwd.
            for source in result.get("instructionSources", []):
                if isinstance(source, str) and str(ROOT.parent).lower() in source.lower():
                    raise CodexError("분석 세션에 개발 지침이 포함되어 실행을 중단했습니다. 실행 폴더 설정을 확인해 주세요.", "instruction_scope", False)
            self.events.clear()
            # Local App Server TurnStartParams.effort overrides this turn and
            # later turns. Set it on every request, including resumed/repair
            # turns; the user's global Codex configuration remains unchanged.
            turn_params = {"threadId": tid, "input": [{"type": "text", "text": prompt}], "effort": effort}
            if output_schema:
                turn_params["outputSchema"] = output_schema
            turn = self.call("turn/start", turn_params)
            turn_id = (turn.get("turn") or {}).get("id")
            timeout = max(15, min(600, int(os.getenv("CODEX_TIMEOUT_SECONDS", "180"))))
            deadline = time.monotonic() + timeout
            chunks, complete, warnings = [], [], []
            try:
                while time.monotonic() < deadline:
                    msg = self.events.popleft() if self.events else self.receive(deadline - time.monotonic())
                    method, p = msg.get("method"), msg.get("params", {})
                    if p.get("threadId") not in (None, tid) or p.get("turnId") not in (None, turn_id):
                        continue
                    if method == "item/agentMessage/delta":
                        chunks.append(p.get("delta", ""))
                    elif method == "item/completed" and p.get("item", {}).get("type") == "agentMessage":
                        complete.append(p["item"].get("text", ""))
                    elif method == "item/started" and p.get("item", {}).get("type") in {"commandExecution", "fileChange", "mcpToolCall", "dynamicToolCall", "webSearch"}:
                        raise CodexError("분석 범위를 벗어난 도구 요청을 차단했습니다. 데이터는 변경하지 않았습니다.", "tool_denied", False)
                    elif method == "error":
                        warnings.append((p.get("error") or {}).get("message", "inference"))
                    elif method == "turn/completed":
                        completed = p.get("turn", {})
                        if completed.get("status") != "completed":
                            raise _failure((completed.get("error") or {}).get("message", " ".join(warnings)))
                        content = "\n".join(complete) or "".join(chunks)
                        if not content.strip():
                            raise CodexError("Codex가 분석 내용을 반환하지 않았습니다. 다시 실행해 주세요.", "empty_response")
                        return {"text": content, "thread_id": tid, "model": result.get("model", model or "Codex default"),
                                "effort": effort,
                                "account_fingerprint": account["account_fingerprint"], "connection_reset": reset}
                raise _failure("timeout")
            except Exception:
                if turn_id:
                    try:
                        self.call("turn/interrupt", {"threadId": tid, "turnId": turn_id}, timeout=3)
                    except Exception:
                        pass
                raise
            finally:
                try:
                    self.sequence += 1
                    self.send({"id": self.sequence, "method": "thread/unsubscribe", "params": {"threadId": tid}})
                except CodexError:
                    pass

    def start_login(self):
        result = self.call("account/login/start", {"type": "chatgpt", "useHostedLoginSuccessPage": True, "appBrand": "chatgpt"})
        login_id = result.get("loginId")
        if result.get("type") != "chatgpt" or not isinstance(login_id, str) or not 1 <= len(login_id) <= 512:
            raise CodexError("Codex 로그인 요청을 시작하지 못했습니다.", "login_start")
        return {"login_id": login_id, "auth_url": safe_login_url(result.get("authUrl")), "status": "pending"}

    def close(self):
        # Do not wait for the RPC lock: a concurrent request can be blocked on
        # incoming data. Terminating our process makes that request fail closed.
        with self.close_lock:
            proc = self.proc
            self.proc = None
        if proc is None:
            return
        try:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=3)
        except (OSError, subprocess.TimeoutExpired):
            # The worker's process job owns any remaining descendants. Cleanup
            # must not replace an analysis result/error with a shutdown error.
            pass
        finally:
            self.messages.put(None)

        def close_streams():
            # TextIOWrapper.close() takes the reader's lock. If a descendant
            # inherited stdout, readline() can hold it after App Server exits.
            # A daemon owns that wait so account checks and job completion stay
            # bounded. No unrelated process is searched for or terminated.
            for stream in (proc.stdin, proc.stdout):
                if stream:
                    try:
                        stream.close()
                    except (OSError, ValueError):
                        pass

        self.stream_closer = threading.Thread(target=close_streams, daemon=True)
        self.stream_closer.start()
        self.stream_closer.join(timeout=0.25)

    def __exit__(self, *args):
        self.close()


def check_connection(refresh=False):
    try:
        with CodexClient() as client:
            return client.account(refresh)
    except CodexError as exc:
        return {"mode": "unknown", "plan": None, "connected": False,
                "account_fingerprint": None, "error": str(exc), "code": exc.code, "retryable": exc.retryable}


_login_lock = threading.RLock()
_logins = {}


def _watch_login(login_id, client):
    deadline = time.monotonic() + 600
    try:
        while time.monotonic() < deadline:
            with _login_lock:
                record = _logins.get(login_id)
                if not record or record["status"] != "pending":
                    return
            try:
                msg = client.events.popleft() if client.events else client.receive(min(1, deadline - time.monotonic()))
            except CodexError as exc:
                if exc.code == "timeout":
                    continue
                raise
            p = msg.get("params", {})
            if msg.get("method") == "account/login/completed" and p.get("loginId") == login_id:
                if not p.get("success"):
                    raise _failure(p.get("error", "authentication"))
                connection = client.account()
                if not connection["connected"]:
                    raise CodexError("로그인 완료 후 계정 상태를 확인하지 못했습니다.", "authentication")
                with _login_lock:
                    _logins[login_id].update(status="completed", connection=connection)
                return
        with _login_lock:
            _logins[login_id].update(status="expired", error="로그인 대기 시간이 지났습니다. 다시 시작해 주세요.")
    except CodexError as exc:
        with _login_lock:
            if _logins.get(login_id, {}).get("status") == "pending":
                _logins[login_id].update(status="failed", error=str(exc), code=exc.code)
    finally:
        client.close()


def start_login():
    with _login_lock:
        if any(value["status"] == "pending" for value in _logins.values()):
            raise CodexError("진행 중인 로그인 창에서 먼저 로그인을 완료해 주세요.", "login_pending", False)
        client = CodexClient().__enter__()
        try:
            result = client.start_login()
        except Exception:
            client.close()
            raise
        _logins[result["login_id"]] = {"status": "pending", "client": client}
        threading.Thread(target=_watch_login, args=(result["login_id"], client), daemon=True).start()
        return result


def login_status(login_id):
    with _login_lock:
        record = _logins.get(login_id)
        if not record:
            return {"status": "expired", "error": "이 로그인 요청이 종료되었습니다. 연결 상태를 확인하거나 다시 로그인해 주세요."}
        return {k: v for k, v in record.items() if k != "client"}


def cancel_login(login_id):
    with _login_lock:
        record = _logins.get(login_id)
        if record and record["status"] == "pending":
            # Watcher owns reads. A notification-style request avoids competing
            # consumers and process close removes only this login listener.
            client = record["client"]
            record["status"] = "cancelled"
            try:
                client.send({"id": 900001, "method": "account/login/cancel", "params": {"loginId": login_id}})
            except CodexError:
                pass
        return {"status": record["status"] if record else "expired"}


@atexit.register
def _close_logins():
    for record in list(_logins.values()):
        if record.get("status") == "pending":
            record["status"] = "cancelled"
            record["client"].close()
