"""동일한 데이터 버전에서 보고서·사전·단일 노트북을 만든다."""
from __future__ import annotations

import ast
import copy
import csv
import hashlib
import html
import inspect
import io
import json
from pathlib import Path

import pandas as pd

from . import cleaning

OPERATION_NAMES = {"rename": "컬럼명 변경", "drop_columns": "컬럼 삭제", "cast": "자료형 변환",
                   "unit": "단위 변환", "category_map": "범주 표기 통일", "fill_missing": "결측값 대치",
                   "missing_indicator": "결측 표시 변수", "clip": "값 범위 제한", "log": "로그 변환",
                   "set_missing": "조건부 결측 처리", "replace": "조건부 값 변경", "drop_rows": "조건부 행 제외",
                   "deduplicate": "중복 행 제거"}
CHECK_NAMES = {"overview": "전체 개요", "missing": "결측값", "duplicate_rows": "중복 행",
               "duplicate_columns": "중복 컬럼", "header": "컬럼명", "outlier_candidate": "극단값 후보",
               "negative_values": "음수", "parse_failure": "자료형 해석", "grouped_missing": "집단별 결측",
               "co_missing": "동시 결측", "key_duplicates": "키 중복", "date_order": "날짜 순서",
               "correlation": "변수 간 상관", "relation_residual": "변수 관계", "time_profile": "기간별 분포",
               "rule_check": "업무 규칙", "category_variants": "표기 차이", "rows": "해당 행"}


def _text(value):
    if value is None or value == "":
        return "미확인"
    if isinstance(value, dict):
        return "; ".join(f"{k}: {_text(v)}" for k, v in value.items())
    if isinstance(value, (list, tuple)):
        return "; ".join(_text(v) for v in value) or "없음"
    return str(value)


def _escape(value):
    return html.escape(_text(value), quote=True)


def _table(headers, rows):
    head = "".join(f"<th>{_escape(v)}</th>" for v in headers)
    body = "".join("<tr>" + "".join(f"<td>{_escape(v)}</td>" for v in row) + "</tr>" for row in rows)
    return f'<div class="table-wrap"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>' if rows else "<p class='muted'>기록된 항목이 없습니다.</p>"


def _document(title, subtitle, body):
    return f"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_escape(title)}</title><style>
*{{box-sizing:border-box}}body{{margin:0;background:#f4f6f8;color:#202b39;font-family:'Malgun Gothic','Apple SD Gothic Neo',sans-serif;font-size:15px;line-height:1.75}}
main{{max-width:1080px;margin:40px auto;background:white;padding:52px 60px;border:1px solid #e4e8ed;border-radius:12px}}
h1{{font-size:28px;line-height:1.35;letter-spacing:-.7px;margin:0 0 10px}}h2{{font-size:19px;margin:36px 0 14px;padding-bottom:9px;border-bottom:1px solid #e4e8ed}}
h3{{font-size:16px;margin:22px 0 7px}}p{{margin:8px 0}}.muted{{color:#687586;font-size:13px}}.lead{{font-size:16px;margin:22px 0;white-space:pre-line}}
.table-wrap{{overflow:auto}}table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{padding:11px 12px;text-align:left;vertical-align:top;border-bottom:1px solid #e7ebef;white-space:pre-wrap;overflow-wrap:anywhere}}th{{background:#f3f6fa;color:#48586a;font-weight:600}}
.finding{{padding:16px 0;border-bottom:1px solid #edf0f4}}.finding h3{{margin:0 0 6px}}.label{{color:#516175;font-size:13px}}.footer{{margin-top:38px;border-top:1px solid #e4e8ed;padding-top:15px;color:#687586;font-size:12px}}
@media(max-width:720px){{main{{padding:24px 20px;margin:0;border:0;border-radius:0}}h1{{font-size:24px}}}}@media print{{body{{background:white}}main{{margin:0;border:0;padding:15px;max-width:none}}h2,h3{{break-after:avoid}}tr,.finding{{break-inside:avoid}}}}
</style></head><body><main><h1>{_escape(title)}</h1><p class="muted">{_escape(subtitle)}</p>{body}</main></body></html>"""


def _version_label(state):
    return f"데이터 {state.get('version_id', 'v0')} · 검토 이력 {state.get('revision', 0)}"


def _dataset_rows(state, frame):
    context = state.get("context", {})
    source = state.get("source_info", {})
    if not isinstance(source, dict):
        source = {"source": source}
    return [
        ["데이터", state.get("name", "데이터")],
        ["파일", state.get("ingest", {}).get("filename", source.get("filename"))],
        ["분석 목적", context.get("goal") or state.get("goal") or "탐색 및 품질 점검"],
        ["관측 단위", context.get("observation_unit")],
        ["출처", context.get("source") or source.get("source")],
        ["수집 기간", context.get("collection_period")],
        ["데이터 크기", f"{len(frame):,}행 · {len(frame.columns):,}개 컬럼"],
    ]


def _decision_text(item):
    if isinstance(item, str):
        return item
    if not isinstance(item, dict):
        return _text(item)
    if item.get("title"):
        return item["title"] + (" — " + item["reason"] if item.get("reason") else "")
    return item.get("summary") or item.get("decision") or item.get("description") or item.get("rationale") or item.get("text") or _text(item)


def _report(state, frame):
    context, analysis = state.get("context", {}), state.get("analysis", {}) or {}
    summary = analysis.get("summary") or context.get("dataset_description") or "등록된 데이터의 구조와 품질을 점검하였다. 아래 수치는 현재 데이터 버전을 기준으로 산출하였다."
    body = f'<p class="lead">{_escape(summary)}</p><h2>1. 점검 대상</h2>' + _table(["항목", "내용"], _dataset_rows(state, frame))
    if context.get('dataset_description'):
        body += '<h3>데이터 설명</h3><p>'+_escape(context['dataset_description'])+'</p>'
    if context.get('analysis_uses'):
        body += '<h3>분석 활용 제안</h3><ul>'+''.join('<li>'+_escape(v)+'</li>' for v in context['analysis_uses'])+'</ul>'
    body += "<h2>2. 주요 점검 결과</h2>"
    findings = analysis.get("findings", [])
    if findings:
        for finding in findings:
            if not isinstance(finding, dict):
                body += f'<p>{_escape(finding)}</p>'
                continue
            title = finding.get("title") or finding.get("issue") or "점검 결과"
            fact = finding.get("fact") or finding.get("observation") or finding.get("summary") or finding.get("description")
            interpretation = finding.get("interpretation") or finding.get("assessment")
            recommendation = finding.get("recommendation") or finding.get("action")
            body += f'<div class="finding"><h3>{_escape(title)}</h3>'
            if fact:
                body += f"<p>{_escape(fact)}</p>"
            if interpretation:
                body += f'<p><span class="label">판단 · </span>{_escape(interpretation)}</p>'
            if recommendation:
                body += f'<p><span class="label">권장 조치 · </span>{_escape(recommendation)}</p>'
            if finding.get("evidence_ids"):
                body += f'<p class="muted">근거: {_escape(finding["evidence_ids"])}</p>'
            body += "</div>"
    else:
        evidence = state.get("profile", {}).get("evidence", [])
        body += _table(["점검 항목", "결과", "근거"], [[CHECK_NAMES.get(e.get("kind"), "데이터 점검"), e.get("summary"), e.get("id")] for e in evidence])
        body += '<p class="muted">해석 결과가 없는 항목은 계산 결과만 수록하였다.</p>'
    column_profiles = state.get("profile", {}).get("columns", [])
    if column_profiles:
        body += "<h3>변수별 점검 요약</h3>"
        body += _table(["변수", "관측값", "결측값", "고유값", "중앙값", "극단값 후보"],
                       [[c.get("name"), c.get("valid"), c.get("missing"), c.get("unique"),
                         c.get("stats", {}).get("median", "—"), c.get("stats", {}).get("iqr_candidates", "—")]
                        for c in column_profiles])
        body += '<p class="muted">극단값 후보는 IQR 기준으로 집계하였다. 후보에 포함되었다는 이유만으로 오류나 제외 대상으로 확정하지 않는다.</p>'
    body += "<h2>3. 검토한 내용과 결정</h2>"
    decisions = context.get("decisions", [])
    body += _table(["결정", "근거·적용 범위"], [[_decision_text(d), d.get("reason") or d.get("evidence_ids") or d.get("columns") or "—"] if isinstance(d, dict) else [d, "—"] for d in decisions])
    body += "<h2>4. 적용한 정제와 검증</h2>"
    lineage = state.get("lineage", [])
    if not lineage:
        body += "<p>승인하여 적용한 정제는 없다. 원본 데이터의 진단 결과를 제공한다.</p>"
    for step in lineage:
        manifest = step["manifest"]
        impact = manifest.get("impact", step.get("impact", {}))
        before, after = impact.get("before", {}), impact.get("after", {})
        body += f"<h3>{_escape(step.get('parent_version', '이전 버전'))} → {_escape(step.get('version_id', '새 버전'))}</h3>"
        body += _table(["규칙", "대상", "처리 이유"], [[OPERATION_NAMES.get(r["operation"], r["operation"]), [s.get("name", s["id"]) for s in manifest["source_schema"] if s["id"] in r["columns"]] or "전체 행", r.get("reason")] for r in manifest["rules"]])
        body += _table(["검증 항목", "변경 전", "변경 후"], [["행 수", before.get("rows"), after.get("rows")], ["컬럼 수", before.get("columns"), after.get("columns")], ["결측값 수", before.get("missing_cells"), after.get("missing_cells")]])
        body += f'<p>제외 {impact.get("removed_rows", 0):,}행, 기존 컬럼에서 값 변경 {impact.get("changed_cells", 0):,}개. 적용 결과는 승인한 전수 미리보기와 같은 데이터 해시로 검증하였다.</p>'
        distributions = []
        for col, stats in before.get("numeric", {}).items():
            target = after.get("numeric", {}).get(col)
            if target:
                name = next((s["name"] for s in manifest["source_schema"] if s["id"] == col), col)
                distributions.append([name, stats.get("median"), target.get("median"), stats.get("max"), target.get("max")])
        if distributions:
            body += _table(["수치형 변수", "중앙값·전", "중앙값·후", "최댓값·전", "최댓값·후"], distributions)
        body += '<p class="muted">결측값 감소나 행 수 감소만으로 품질 향상을 판단하지 않는다. 분석 목적과 분포 변화에 대한 검토가 필요하다.</p>'
    body += "<h2>5. 보류 사항과 다음 점검</h2>"
    unresolved = context.get("unresolved", []) or analysis.get("unresolved", [])
    body += _table(["확인할 내용"], [[_decision_text(v)] for v in unresolved]) if unresolved else "<p>현재 검토 이력에 별도로 보류한 항목은 없다. 이 결과는 수행한 검사 범위에 대한 기록이다.</p>"
    body += '<h2>부록. 재현 정보</h2>'
    body += _table(["항목", "내용"], [["데이터 버전", state.get("version_id")], ["검토 이력", state.get("revision")], ["원본 SHA-256", state.get("ingest", {}).get("source_sha256")], ["현재 데이터 해시", cleaning.hash_frame(frame, state["schema"])], ["정제 엔진", cleaning.ENGINE_VERSION]])
    body += '<p class="footer">처리 순서와 고정된 파라미터는 함께 제공한 처리 명세와 노트북에서 확인할 수 있다. 실제 적용하지 않은 추천은 정제 결과에 포함하지 않았다.</p>'
    return _document("데이터 진단·정제 보고서", f"{state.get('name', '데이터')} · {_version_label(state)}", body)


def _dictionary_rows(state):
    rows = []
    definitions = state.get("context", {}).get("definitions", {})
    role_names = {"numeric": "수치형", "categorical": "범주형", "datetime": "날짜·시간", "text": "텍스트", "id": "ID"}
    for item in state["schema"]:
        definition = {**item, **definitions.get(item["id"], {})}
        # 적용된 자료형·단위는 실제 현재 버전의 정의를 기준으로 한다.
        certainty = definition.get("certainty") or definition.get("definition_status") or definition.get("status")
        status = {"confirmed": "확인됨", "likely": "추정", "unknown": "미확인", "inferred": "추정"}.get(certainty, certainty or "미확인")
        rows.append([item["name"], definition.get("description"), role_names.get(definition.get("role"), definition.get("role")), item.get("dtype"), item.get("unit") or definition.get("unit"), definition.get("code_values"), status])
    return rows


def _dictionary(state, frame):
    context = state.get("context", {})
    description = context.get("dataset_description") or state.get("analysis", {}).get("dataset_description") or "데이터셋 설명이 아직 확인되지 않았다."
    body = f'<p class="lead">{_escape(description)}</p><h2>데이터셋 정보</h2>' + _table(["항목", "내용"], _dataset_rows(state, frame))
    body += "<h2>컬럼 정의</h2>" + _table(["컬럼", "설명", "역할", "자료형", "단위", "코드값", "정의 상태"], _dictionary_rows(state))
    if context.get('analysis_uses'):
        body += '<h2>분석 활용 제안</h2><ul>'+''.join('<li>'+_escape(v)+'</li>' for v in context['analysis_uses'])+'</ul>'
    renamed = [[s["original_name"], s["name"]] for s in state["schema"] if s.get("original_name") and s["original_name"] != s["name"]]
    if renamed:
        body += "<h2>컬럼명 변경</h2>" + _table(["원래 이름", "현재 이름"], renamed)
    body += '<p class="footer">출처와 수집 기간은 제공된 정보만 기록하였다. 업로드 시각은 수집 시각으로 사용하지 않았다.</p>'
    return _document("데이터 사전", f"{state.get('name', '데이터')} · {_version_label(state)}", body)


def _markdown_cell(text):
    return {"cell_type": "markdown", "metadata": {}, "source": text.splitlines(keepends=True)}


def _code_cell(text, collapsed=False):
    return {"cell_type": "code", "metadata": {"jupyter": {"source_hidden": True}} if collapsed else {}, "execution_count": None, "outputs": [], "source": text.splitlines(keepends=True)}


def _notebook(state, source_name, original_bytes, title):
    from . import analysis

    loader_source = analysis.standalone_loader_source()
    analysis_source = inspect.getsource(analysis)
    # 읽기 함수는 앞 셀에 있으므로 패키지 상대 import만 제외한다.
    lines = analysis_source.splitlines(keepends=True)
    relative_imports = [node for node in ast.walk(ast.parse(analysis_source)) if isinstance(node, ast.ImportFrom) and node.level]
    for node in sorted(relative_imports, key=lambda node: node.lineno, reverse=True):
        del lines[node.lineno - 1:node.end_lineno]
    analysis_source = "".join(lines)
    engine_source = inspect.getsource(cleaning)
    manifests = [step["manifest"] for step in state.get("lineage", [])]
    # 사용자 확인으로 바뀐 설명·단위 등은 버전별 source_schema로 복원한다.
    # 이후 실제 값과 자료형의 해시는 apply_manifest가 검사한다.
    payload = {
        "source_sha256": hashlib.sha256(original_bytes).hexdigest(),
        "filename": state.get("ingest", {}).get("filename", source_name),
        "settings": state.get("ingest", {}).get("settings", {}),
        "manifests": manifests,
        "final_schema": state["schema"],
        "version_id": state.get("version_id"),
        "revision": state.get("revision"),
        "final_frame_hash": state["export_frame_hash"],
        "context": {k: state.get("context", {}).get(k) for k in ("goal", "dataset_description", "observation_unit", "source", "collection_period")},
        "decisions": state.get("context", {}).get("decisions", []),
        "unresolved": state.get("context", {}).get("unresolved", []),
    }
    payload_text = json.dumps(cleaning._jsonable(payload), ensure_ascii=False, indent=2, allow_nan=False)
    cells = [
        _markdown_cell(f"# {title}\n\n{_version_label(state)}\n\n원본을 읽고, 승인하여 적용한 정제만 같은 순서로 재현한다. 검토 중이거나 보류한 추천은 실행하지 않는다.\n\n노트북과 `{source_name}`을 같은 폴더에 놓는다. 다른 경로를 쓸 때에는 아래 `SOURCE_PATH`만 수정한다."),
        _markdown_cell("## 1. 실행 환경\n\npandas, numpy, openpyxl이 필요하다. 승인한 미리보기와 다른 라이브러리 버전에서는 재현 검증을 중단한다. 패키지는 이 노트북에서 자동 설치하지 않는다.\n\n" + " · ".join(f"{k} {v}" for k, v in cleaning.environment().items())),
        _code_cell("from pathlib import Path\nimport hashlib\nimport json\nimport pandas as pd\nimport numpy as np\n\n" + f"SOURCE_PATH = Path({source_name!r})\nOUTPUT_PATH = Path('정제_결과.csv')\n"),
        _markdown_cell("## 2. 원본 읽기\n\n업로드 때 사용한 인코딩·시트·헤더 조건을 그대로 사용한다. 아래 읽기 함수는 앱에서 사용한 코드와 같다. 컬럼은 고정 ID로 추적하고 표시 이름은 별도로 관리한다."),
        _code_cell(loader_source, collapsed=True),
        _code_cell("# 업로드 시 확인한 원본 해시와 승인된 전체 처리 이력\n" + "RUN = json.loads(" + repr(payload_text) + ")\n\nraw = SOURCE_PATH.read_bytes()\nassert hashlib.sha256(raw).hexdigest() == RUN['source_sha256'], '원본 파일이 다릅니다.'\ndf, schema, ingest = load_dataset(raw, RUN['filename'], RUN['settings'])\noriginal_rows = len(df)\ndf.head()\n"),
        _markdown_cell("## 3. 데이터 개요\n\n원본의 행·열과 결측값을 확인한다. 빈 문자열은 업로드 진단과 동일하게 결측값으로 집계한다."),
        _code_cell(analysis_source, collapsed=True),
        _code_cell("# 앱과 같은 함수로 수치·범주·날짜 프로파일과 자동 심층 검사를 계산한다.\nif RUN['manifests']:\n    schema = RUN['manifests'][0]['source_schema']\ninitial_profile = profile_dataset(df, schema, RUN['context'], deep=True)\nprint(initial_profile['overview'])\npd.DataFrame([{k: c.get(k) for k in ('name', 'role', 'valid', 'missing', 'unique')} for c in initial_profile['columns']])\n"),
        _markdown_cell("## 4. 검토한 결정\n\n대화 원문 대신 정리된 결정과 보류 사항을 기록한다. 아래 기록은 실행 규칙과 구분된다."),
        _code_cell("for decision in RUN['decisions']:\n    print(decision)\nprint('보류 사항:', RUN['unresolved'])\n"),
        _markdown_cell("## 5. 승인한 정제 적용\n\n앱과 같은 허용 연산을 사용한다. 대치값·경계값은 미리보기 때 고정한 값을 사용하며 다시 추정하지 않는다. 각 단계는 입력과 결과 해시를 검사한다."),
        _code_cell(engine_source, collapsed=True),
        _code_cell("# 원본부터 현재 버전까지 누적된 모든 규칙을 순서대로 적용한다.\nfor step, manifest in enumerate(RUN['manifests'], start=1):\n    schema = copy.deepcopy(manifest['source_schema'])\n    df, schema = apply_manifest(df, schema, manifest)\n    print(f'{step}단계 완료: {len(df):,}행 · {len(df.columns):,}개 컬럼')\n\n# 정제 이후 확인한 설명과 정의도 현재 데이터 사전과 맞춘다.\nschema = RUN['final_schema']\n"),
        _markdown_cell("## 6. 결과 확인 및 내보내기\n\n내부 ID를 현재 컬럼명으로 바꾸어 CSV로 저장한다. 원본 파일은 수정하지 않는다."),
        _code_cell("assert [c['id'] for c in schema] == list(df.columns)\nassert hash_frame(df, schema) == RUN['final_frame_hash'], '앱에서 내보낸 버전과 결과가 다릅니다.'\nfinal_profile = profile_dataset(df, schema, RUN['context'], deep=True)\nprint(f'원본 {original_rows:,}행 → 결과 {len(df):,}행')\nprint(final_profile['overview'])\nresult = df.rename(columns={c['id']: c['name'] for c in schema})\nresult.to_csv(OUTPUT_PATH, index=False, encoding='utf-8-sig')\nresult.head()\n"),
    ]
    return {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}, "language_info": {"name": "python", "version": cleaning.environment()["python"]}, "dataprep": {"version_id": state.get("version_id"), "revision": state.get("revision"), "engine_version": cleaning.ENGINE_VERSION}}, "nbformat": 4, "nbformat_minor": 5}


def build_exports(state, frame, original_bytes, output_dir, title):
    """호출부가 확정한 같은 버전의 state와 frame만 받아 산출물을 기록한다."""
    state = copy.deepcopy(state)
    cleaning._check_frame(frame, state["schema"])
    if state.get("lineage"):
        last = state["lineage"][-1]["manifest"]
        if cleaning.hash_frame(frame, last["output_schema"]) != last["output_hash"]:
            raise cleaning.CleaningError("현재 데이터가 마지막 승인 결과와 다릅니다. 데이터 버전을 확인해 주세요.")
    state["export_frame_hash"] = cleaning.hash_frame(frame, state["schema"])
    target = Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)
    actual_source_hash = hashlib.sha256(original_bytes).hexdigest()
    expected_source_hash = state.get("ingest", {}).get("source_sha256")
    if expected_source_hash and expected_source_hash != actual_source_hash:
        raise cleaning.CleaningError("원본 파일의 해시가 프로젝트 기록과 다릅니다.")
    artifacts = []

    def write(kind, label, filename, content, mime):
        path = target / filename
        if isinstance(content, bytes):
            path.write_bytes(content)
        else:
            path.write_text(content, encoding="utf-8")
        artifacts.append({"kind": kind, "label": label, "path": str(path.resolve()), "mime": mime, "version_id": state.get("version_id"), "revision": state.get("revision"), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})

    write("report", "진단·정제 보고서", "report.html", _report(state, frame), "text/html")
    write("dictionary", "데이터 사전", "dictionary.html", _dictionary(state, frame), "text/html")
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["컬럼", "설명", "역할", "자료형", "단위", "코드값", "정의 상태"])
    writer.writerows([[_text(v) for v in row] for row in _dictionary_rows(state)])
    write("dictionary_csv", "데이터 사전 표", "dictionary.csv", buffer.getvalue().encode("utf-8-sig"), "text/csv")
    result_csv = frame.rename(columns={s["id"]: s["name"] for s in state["schema"]}).to_csv(index=False).encode("utf-8-sig")
    write("data", "현재 데이터", "data.csv", result_csv, "text/csv")
    original_filename = state.get("ingest", {}).get("filename", "data.csv")
    suffix = ".xlsx" if str(original_filename).lower().endswith(".xlsx") else ".csv"
    source_name = "source" + suffix
    write("source", "노트북 재현용 원본", source_name, original_bytes, "application/octet-stream")
    notebook = _notebook(state, source_name, original_bytes, title.strip() or "데이터 진단과 정제")
    write("notebook", "분석·정제 노트북", "notebook.ipynb", json.dumps(notebook, ensure_ascii=False, indent=2), "application/x-ipynb+json")
    manifest = {"project_id": state.get("id"), "version_id": state.get("version_id"), "revision": state.get("revision"), "source_sha256": actual_source_hash, "current_frame_hash": cleaning.hash_frame(frame, state["schema"]), "schema": state["schema"], "lineage": state.get("lineage", []), "environment": cleaning.environment(), "artifacts": [{k: v for k, v in a.items() if k != "path"} for a in artifacts]}
    write("manifest", "처리 명세", "manifest.json", json.dumps(cleaning._jsonable(manifest), ensure_ascii=False, indent=2, allow_nan=False), "application/json")
    return artifacts
