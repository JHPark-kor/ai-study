"""Local configuration. Credentials stay in the local environment."""
import os
import tempfile
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / '.env', override=False)
DATA = ROOT / 'data'
RUNTIME = Path(os.getenv('STUDIO_RUNTIME', str(Path(tempfile.gettempdir()) / 'dataprep-studio-runtime')))
MAX_BYTES = 150 * 1024 * 1024
PORT = int(os.getenv('STUDIO_PORT', '8502'))


def connection_kwargs():
    return dict(host=os.getenv('PGHOST', 'localhost'), port=int(os.getenv('PGPORT', '5432')),
                dbname=os.getenv('PGDATABASE', 'dataprep_workbench'), user=os.getenv('PGUSER', 'postgres'),
                password=os.getenv('PGPASSWORD', ''), connect_timeout=3)
