"""승인 전 미리보기와 승인된 명세의 재실행에 사용하는 정제 연산.

이 모듈은 승인을 대신하지 않는다. 서비스가 승인한 manifest만 apply_manifest에
전달하며, 입력·규칙·실행 환경·결과가 미리보기와 같은지 여기서 다시 검증한다.
노트북에서도 같은 코드를 실행할 수 있도록 앱과 DB에 의존하지 않는다.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import platform
from datetime import datetime, timezone

import numpy as np
import pandas as pd

ENGINE_VERSION = "1.0.0"
SUPPORTED_OPERATIONS = {
    "rename": {"names"},
    "drop_columns": {"confirmed", "duplicate_of"},
    "cast": {"dtype", "errors", "format", "timezone", "decimal", "thousands"},
    "unit": {"factor", "offset", "from_unit", "to_unit"},
    "category_map": {"mapping", "strip", "case"},
    "fill_missing": {"method", "value", "group_by", "min_group_size", "on_unmatched", "fit_condition"},
    "missing_indicator": {"new_id", "new_name"},
    "clip": {"lower", "upper"},
    "log": {"offset", "base", "new_id", "new_name"},
    "set_missing": {"condition"},
    "replace": {"condition", "value"},
    "drop_rows": {"condition"},
    "deduplicate": {"keep", "sort_by", "ascending", "key_missing"},
}


class CleaningError(ValueError):
    """미확정 규칙이나 미리보기와 다른 실행은 결과를 확정하지 않는다."""


def _jsonable(value):
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if value is None or value is pd.NA or value is pd.NaT:
        return None
    if isinstance(value, (pd.Timestamp, datetime)):
        return value.isoformat()
    if isinstance(value, np.generic):
        return _jsonable(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _canonical(value):
    return json.dumps(_jsonable(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _digest(value):
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def environment():
    return {"python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__}


def _check_frame(frame, schema):
    ids = [c["id"] for c in schema]
    if ids != list(frame.columns) or len(ids) != len(set(ids)):
        raise CleaningError("데이터와 컬럼 정의의 순서 또는 ID가 일치하지 않습니다.")
    if not frame.index.is_unique:
        raise CleaningError("원본 행 ID가 중복되어 있습니다.")


def hash_frame(frame, schema):
    """바이트 파일 해시와 별도로 값·행 순서·자료형·컬럼 정의를 고정한다."""
    _check_frame(frame, schema)
    digest = hashlib.sha256()
    digest.update(_canonical(schema).encode("utf-8"))
    digest.update(_canonical([str(t) for t in frame.dtypes]).encode("utf-8"))
    digest.update(pd.util.hash_pandas_object(frame, index=True, categorize=False).values.tobytes())
    return digest.hexdigest()


def missing_mask(series):
    return series.isna() | series.astype("string").eq("").fillna(False)


def _number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise CleaningError(f"{label}에는 유한한 숫자를 지정해 주세요.")
    return value


def _scalar(value):
    if value is not None and not isinstance(value, (str, int, float, bool)):
        raise CleaningError("대치값은 문자열·숫자·불리언 또는 결측값이어야 합니다.")
    if isinstance(value, float) and not math.isfinite(value):
        raise CleaningError("무한대와 NaN은 규칙의 상수로 사용할 수 없습니다.")
    return value


def _numeric(series):
    try:
        result = pd.to_numeric(series.mask(missing_mask(series)), errors="raise")
    except (ValueError, TypeError) as exc:
        raise CleaningError("수치로 해석할 수 없는 값이 있습니다. 자료형 변환 규칙을 먼저 확인해 주세요.") from exc
    if np.isinf(result.astype(float)).any():
        raise CleaningError("무한대가 포함된 컬럼은 먼저 해당 값의 처리 기준을 정해 주세요.")
    return result


def _condition(frame, condition, depth=0):
    """허용된 비교만 수행한다. 문자열 수식이나 Python 코드는 실행하지 않는다."""
    if not isinstance(condition, dict) or depth > 6:
        raise CleaningError("조건 형식이 올바르지 않거나 너무 복잡합니다.")
    for joint in ("all", "any"):
        if joint in condition:
            parts = condition[joint]
            if set(condition) != {joint} or not isinstance(parts, list) or not 1 <= len(parts) <= 20:
                raise CleaningError("조건 묶음에는 1~20개의 비교를 지정해 주세요.")
            masks = [_condition(frame, p, depth + 1) for p in parts]
            result = masks[0]
            for mask in masks[1:]:
                result = result & mask if joint == "all" else result | mask
            return result
    if set(condition) - {"column", "op", "value"}:
        raise CleaningError("지원하지 않는 조건 항목입니다.")
    col, op, value = condition.get("column"), condition.get("op"), condition.get("value")
    if col not in frame:
        raise CleaningError("조건의 컬럼을 찾을 수 없습니다.")
    source = frame[col]
    if op == "is_null":
        return missing_mask(source)
    if op == "not_null":
        return ~missing_mask(source)
    if "value" not in condition:
        raise CleaningError("비교할 값을 지정해 주세요.")
    if op in {"in", "not_in"}:
        if not isinstance(value, list) or len(value) > 1000:
            raise CleaningError("비교 목록에는 최대 1,000개 값을 지정할 수 있습니다.")
        for item in value:
            _scalar(item)
        mask = source.isin(value)
        return (mask if op == "in" else ~mask) & ~missing_mask(source)
    _scalar(value)
    if op in {"lt", "le", "gt", "ge"}:
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            source = _numeric(source)
        elif pd.api.types.is_datetime64_any_dtype(source.dtype):
            value = pd.Timestamp(value)
        else:
            raise CleaningError("크기 비교에는 수치 또는 변환된 날짜 컬럼을 사용해 주세요.")
    funcs = {"eq": "eq", "ne": "ne", "lt": "lt", "le": "le", "gt": "gt", "ge": "ge"}
    if op not in funcs:
        raise CleaningError("지원하지 않는 비교 연산입니다.")
    try:
        return getattr(source, funcs[op])(value).fillna(False) & ~missing_mask(source)
    except (ValueError, TypeError) as exc:
        raise CleaningError("컬럼과 비교값의 자료형이 맞지 않습니다.") from exc


def _validate_rule(rule, frame, schema):
    if not isinstance(rule, dict) or set(rule) - {"id", "operation", "columns", "params", "reason", "evidence_ids", "phase"}:
        raise CleaningError("처리 규칙 형식이 올바르지 않습니다.")
    if not isinstance(rule.get("id"), str) or not rule["id"]:
        raise CleaningError("규칙 ID가 필요합니다.")
    op, cols, params = rule.get("operation"), rule.get("columns"), rule.get("params", {})
    if op not in SUPPORTED_OPERATIONS:
        raise CleaningError(f"지원하지 않는 정제 연산입니다: {op}")
    if not isinstance(cols, list) or len(cols) != len(set(cols)) or any(c not in frame for c in cols):
        raise CleaningError("처리 대상 컬럼 ID를 확인해 주세요.")
    if not isinstance(params, dict) or set(params) - SUPPORTED_OPERATIONS[op]:
        raise CleaningError(f"{op} 규칙에 지원하지 않는 설정이 있습니다.")
    if op not in {"rename", "drop_columns", "deduplicate", "drop_rows"} and len(cols) != 1:
        raise CleaningError("이 규칙은 한 컬럼씩 지정해 주세요.")
    if op in {"rename", "drop_columns"} and not cols:
        raise CleaningError("처리 대상 컬럼을 지정해 주세요.")
    if rule.get("phase", "basic") not in {"basic", "deep"}:
        raise CleaningError("처리 단계가 올바르지 않습니다.")
    return op, cols, params


def _freeze_rule(rule, frame, schema, context):
    op, cols, params = _validate_rule(rule, frame, schema)
    frozen = copy.deepcopy(rule)
    frozen.setdefault("params", {})
    if op != "fill_missing":
        return frozen
    method = params.get("method")
    if method not in {"constant", "median", "mode", "group_median", "group_mode"}:
        raise CleaningError("결측값 처리 방법을 확인해 주세요.")
    if method == "constant":
        if "value" not in params or params["value"] is None:
            raise CleaningError("결측값에 넣을 값을 지정해 주세요.")
        _scalar(params["value"])
        return frozen
    fit = params.get("fit_condition") or context.get("training_condition")
    prediction = context.get("task_type") in {"prediction", "predictive", "forecast"} or "예측" in str(context.get("goal", ""))
    if prediction and not fit:
        raise CleaningError("예측용 대치값을 계산할 학습 구간을 먼저 정해 주세요.")
    fitting = frame.loc[_condition(frame, fit)] if fit else frame
    if fitting.empty:
        raise CleaningError("대치값을 계산할 기준 행이 없습니다.")
    frozen["params"]["fit_condition"] = fit
    values = []
    group_by = params.get("group_by", [])
    group_method = method.startswith("group_")
    if group_method and (not group_by or any(c not in frame or c == cols[0] for c in group_by)):
        raise CleaningError("집단별 대치에는 대상과 다른 집단 컬럼이 필요합니다.")
    minimum = params.get("min_group_size", 1)
    if not isinstance(minimum, int) or isinstance(minimum, bool) or minimum < 1:
        raise CleaningError("최소 집단 크기는 1 이상의 정수여야 합니다.")
    if params.get("on_unmatched", "keep") not in {"keep", "error"}:
        raise CleaningError("대치 기준이 없는 집단의 처리 방식을 확인해 주세요.")
    if group_method:
        valid_groups = ~pd.concat([missing_mask(fitting[c]) for c in group_by], axis=1).any(axis=1)
        groups = fitting.loc[valid_groups].groupby(group_by[0] if len(group_by) == 1 else group_by, sort=False, dropna=False)
    else:
        groups = [((), fitting)]
    for key, group in groups:
        series = group[cols[0]]
        series = series.loc[~missing_mask(series)]
        if len(series) < minimum:
            continue
        if method.endswith("median"):
            value = _numeric(series).median()
        else:
            counts = series.value_counts(dropna=True, sort=False)
            # 최빈값 동률은 원본에서 먼저 나타난 값을 사용하고 명세에 고정한다.
            value = counts[counts == counts.max()].index[0]
        keys = list(key) if isinstance(key, tuple) else [key]
        values.append({"group": _jsonable(keys), "value": _jsonable(value), "observations": len(series)})
        if len(values) > 10000:
            raise CleaningError("집단이 10,000개를 넘습니다. 집단 정의를 줄여 주세요.")
    if not values and not group_method:
        raise CleaningError("모두 결측인 컬럼에서는 대치값을 계산할 수 없습니다.")
    frozen["_frozen_values"] = values
    frozen["_fit_rows"] = len(fitting)
    return frozen


def _new_column(frame, schema, new_id, new_name, role, description, series, unit=""):
    if not isinstance(new_id, str) or not new_id or new_id in frame:
        raise CleaningError("파생 컬럼에는 사용하지 않은 ID가 필요합니다.")
    if not isinstance(new_name, str) or not new_name.strip() or new_name in [c["name"] for c in schema]:
        raise CleaningError("파생 컬럼명을 비어 있지 않은 고유한 이름으로 지정해 주세요.")
    frame[new_id] = series
    schema.append({"id": new_id, "name": new_name, "original_name": new_name, "dtype": str(series.dtype), "role": role, "description": description, "unit": unit})


def _execute_rule(frame, schema, rule):
    # frame과 schema는 호출부에서 만든 복사본이다.
    op, cols, p = rule["operation"], rule["columns"], rule.get("params", {})
    by_id = {s["id"]: s for s in schema}
    col = cols[0] if cols else None
    details = {}
    if op == "rename":
        names = p.get("names", {})
        if not isinstance(names, dict) or set(names) != set(cols) or any(not isinstance(v, str) or not v.strip() for v in names.values()):
            raise CleaningError("대상 컬럼마다 새 이름을 지정해 주세요.")
        result_names = [names.get(s["id"], s["name"]) for s in schema]
        if len(result_names) != len(set(result_names)):
            raise CleaningError("변경 후 컬럼명이 중복됩니다.")
        for key, name in names.items():
            by_id[key]["name"] = name
    elif op == "drop_columns":
        if p.get("confirmed") is not True or len(cols) == len(frame.columns):
            raise CleaningError("컬럼 삭제의 의미를 확인해야 하며 모든 컬럼을 삭제할 수 없습니다.")
        duplicate_of = p.get("duplicate_of", {})
        if not isinstance(duplicate_of, dict) or any(c not in cols for c in duplicate_of):
            raise CleaningError("중복 컬럼 비교 기준을 확인해 주세요.")
        for dropped, kept in duplicate_of.items():
            if kept not in frame or kept in cols or not frame[dropped].equals(frame[kept]):
                raise CleaningError("삭제할 컬럼과 보존할 컬럼의 값이 같지 않습니다.")
        frame.drop(columns=cols, inplace=True)
        schema[:] = [s for s in schema if s["id"] not in cols]
    elif op == "cast":
        dtype, errors = p.get("dtype"), p.get("errors", "raise")
        if errors not in {"raise", "coerce"}:
            raise CleaningError("변환 실패 처리 방식은 raise 또는 coerce여야 합니다.")
        source = frame[col].mask(missing_mask(frame[col]))
        if dtype in {"numeric", "integer"}:
            if p.get("thousands"):
                if not isinstance(p["thousands"], str) or len(p["thousands"]) != 1:
                    raise CleaningError("천 단위 구분자를 한 글자로 지정해 주세요.")
                source = source.astype("string").str.replace(p["thousands"], "", regex=False)
            if p.get("decimal", ".") != ".":
                if not isinstance(p["decimal"], str) or len(p["decimal"]) != 1 or p["decimal"] == p.get("thousands"):
                    raise CleaningError("소수점 구분자를 확인해 주세요.")
                source = source.astype("string").str.replace(p["decimal"], ".", regex=False)
            result = pd.to_numeric(source, errors=errors)
            if dtype == "integer":
                non_integer = result.notna() & (result % 1 != 0)
                if non_integer.any() and errors == "raise":
                    raise CleaningError("정수가 아닌 값이 있어 정수형으로 변환할 수 없습니다.")
                result = result.mask(non_integer).astype("Int64")
        elif dtype == "string":
            result = source.astype("string")
        elif dtype == "datetime":
            if not isinstance(p.get("format"), str) or not p["format"]:
                raise CleaningError("날짜 변환 형식을 명시해 주세요. 혼용은 mixed로 지정할 수 있습니다.")
            result = pd.to_datetime(source, format=p["format"], errors=errors)
            if p.get("timezone"):
                if not pd.api.types.is_datetime64_any_dtype(result.dtype):
                    raise CleaningError("시간대가 혼용되어 있습니다. 같은 기준으로 정리해 주세요.")
                result = result.dt.tz_localize(p["timezone"], ambiguous="raise", nonexistent="raise") if result.dt.tz is None else result.dt.tz_convert(p["timezone"])
        else:
            raise CleaningError("지원하지 않는 자료형입니다.")
        details["parse_failures"] = int((~missing_mask(frame[col]) & result.isna()).sum())
        frame[col] = result
        if dtype == "datetime":
            by_id[col]["role"] = "datetime"
        if dtype in {"numeric", "integer"} and by_id[col].get("role") not in {"id", "categorical"}:
            by_id[col]["role"] = "numeric"
    elif op == "unit":
        factor, offset = _number(p.get("factor"), "배율"), _number(p.get("offset", 0), "보정값")
        if not p.get("from_unit") or not p.get("to_unit") or factor == 0:
            raise CleaningError("변환 전후 단위와 0이 아닌 배율을 지정해 주세요.")
        if by_id[col].get("unit") and by_id[col]["unit"] != p["from_unit"]:
            raise CleaningError("현재 컬럼 단위와 변환 전 단위가 다릅니다.")
        frame[col] = _numeric(frame[col]) * factor + offset
        by_id[col]["unit"] = p["to_unit"]
    elif op == "category_map":
        series = frame[col].copy()
        if p.get("strip") or p.get("case"):
            series = series.astype("string")
            if p.get("strip"):
                series = series.str.strip()
            if p.get("case") not in {None, "lower", "upper"}:
                raise CleaningError("대소문자 정규화 방식을 확인해 주세요.")
            if p.get("case"):
                series = getattr(series.str, p["case"])()
        mapping = p.get("mapping", [])
        if not isinstance(mapping, list) or len(mapping) > 1000:
            raise CleaningError("범주 매핑은 최대 1,000개까지 지정할 수 있습니다.")
        result = series.copy()
        seen = set()
        for item in mapping:
            if not isinstance(item, dict) or set(item) != {"from", "to"}:
                raise CleaningError("범주 매핑에는 from과 to를 지정해 주세요.")
            token = _canonical(_scalar(item["from"]))
            if token in seen:
                raise CleaningError("같은 범주의 매핑이 중복되었습니다.")
            seen.add(token)
            value = _scalar(item["to"])
            mask = missing_mask(series) if item["from"] is None else series.eq(item["from"]).fillna(False)
            result = _assign(result, mask, value)
        frame[col] = result
    elif op == "fill_missing":
        method = p["method"]
        series = frame[col].copy()
        if method == "constant":
            series = _assign(series, missing_mask(series), p["value"])
        else:
            for item in rule.get("_frozen_values", []):
                mask = missing_mask(series)
                for group_col, key in zip(p.get("group_by", []), item["group"]):
                    mask &= frame[group_col].eq(key).fillna(False)
                series = _assign(series, mask, item["value"])
        if p.get("on_unmatched", "keep") == "error" and missing_mask(series).any():
            raise CleaningError("대치 기준이 없는 집단 또는 결측 집단 키가 남아 있습니다.")
        details["filled"] = int((missing_mask(frame[col]) & ~missing_mask(series)).sum())
        details["unfilled"] = int(missing_mask(series).sum())
        frame[col] = series
    elif op == "missing_indicator":
        _new_column(frame, schema, p.get("new_id"), p.get("new_name"), "categorical", f"{by_id[col]['name']}의 결측 여부 (1: 결측, 0: 관측)", missing_mask(frame[col]).astype("int8"))
    elif op == "clip":
        lower, upper = p.get("lower"), p.get("upper")
        if lower is None and upper is None:
            raise CleaningError("하한 또는 상한을 지정해 주세요.")
        if lower is not None:
            _number(lower, "하한")
        if upper is not None:
            _number(upper, "상한")
        if lower is not None and upper is not None and lower > upper:
            raise CleaningError("하한이 상한보다 큽니다.")
        frame[col] = _numeric(frame[col]).clip(lower=lower, upper=upper)
    elif op == "log":
        offset = _number(p.get("offset", 0), "로그 보정값")
        base = p.get("base", "e")
        if base not in {"e", 2, 10}:
            raise CleaningError("로그 밑은 e, 2, 10 중 하나여야 합니다.")
        series = _numeric(frame[col]) + offset
        if (series.dropna() <= 0).any():
            raise CleaningError("로그 변환 대상에 0 이하 값이 있습니다. 정의역과 보정값을 확인해 주세요.")
        result = np.log(series) / (1 if base == "e" else np.log(base))
        if p.get("new_id"):
            _new_column(frame, schema, p["new_id"], p.get("new_name"), "numeric", f"{by_id[col]['name']}의 로그 변환 (밑={base}, 보정값={offset})", result)
        else:
            frame[col] = result
            by_id[col]["unit"] = "로그 척도"
            by_id[col]["description"] = f"{by_id[col].get('description') or by_id[col]['name']} · 로그 변환 (밑={base}, 보정값={offset})"
    elif op in {"set_missing", "replace", "drop_rows"}:
        mask = _condition(frame, p.get("condition"))
        if op == "drop_rows":
            frame = frame.loc[~mask].copy()
        else:
            if op == "replace" and "value" not in p:
                raise CleaningError("변경할 값을 지정해 주세요.")
            frame[col] = _assign(frame[col], mask, None if op == "set_missing" else _scalar(p["value"]))
    elif op == "deduplicate":
        keep = p.get("keep")
        if keep not in {"first", "last", False} or keep is True or keep is None:
            raise CleaningError("중복 행의 보존 기준을 first, last, false 중에서 지정해 주세요.")
        subset = cols or list(frame.columns)
        key_missing = p.get("key_missing", "keep")
        if key_missing not in {"keep", "drop", "error"}:
            raise CleaningError("키 결측 처리 방식을 확인해 주세요.")
        missing = pd.concat([missing_mask(frame[c]) for c in subset], axis=1).any(axis=1) if cols else pd.Series(False, index=frame.index)
        if key_missing == "error" and missing.any():
            raise CleaningError("중복 기준 키에 결측값이 있습니다.")
        sort_by = p.get("sort_by", [])
        if not isinstance(sort_by, list) or any(c not in frame for c in sort_by) or not isinstance(p.get("ascending", True), bool):
            raise CleaningError("중복 보존용 정렬 기준을 확인해 주세요.")
        ordered = frame.sort_values(sort_by, ascending=p.get("ascending", True), kind="mergesort") if sort_by else frame
        candidates = ordered.loc[~missing.reindex(ordered.index)]
        keep_ids = candidates.loc[~candidates.duplicated(subset=subset, keep=keep)].index
        if key_missing == "keep":
            keep_ids = keep_ids.union(frame.index[missing], sort=False)
        # 보존 행의 출력 순서는 원본 순서를 유지한다. 정렬은 선택에만 사용한다.
        frame = frame.loc[frame.index.isin(keep_ids)].copy()
        details["tie_policy"] = "정렬 동률은 원본 행 순서, 결과도 원본 행 순서"
    else:
        raise CleaningError("실행할 수 없는 연산입니다.")
    for item in schema:
        item["dtype"] = str(frame[item["id"]].dtype)
    return frame, schema, details


def _assign(series, mask, value):
    result = series.copy()
    if value is None:
        return result.mask(mask)
    try:
        result.loc[mask] = value
    except (TypeError, ValueError):
        # 이질적인 상수 대치는 명세에 남기고 결과 자료형을 보고한다.
        result = result.astype(object)
        result.loc[mask] = value
    return result


def _summary(frame, schema):
    result = {"rows": len(frame), "columns": len(schema), "missing_cells": sum(int(missing_mask(frame[c]).sum()) for c in frame), "numeric": {}, "groups": {}}
    for item in schema:
        col = item["id"]
        if item.get("role") == "numeric" and len(result["numeric"]) < 30:
            nums = pd.to_numeric(frame[col].mask(missing_mask(frame[col])), errors="coerce")
            result["numeric"][col] = {"valid": int(nums.notna().sum()), "mean": nums.mean(), "median": nums.median(), "min": nums.min(), "max": nums.max()}
        if item.get("role") == "categorical" and frame[col].nunique(dropna=True) <= 30 and len(result["groups"]) < 10:
            result["groups"][col] = [{"value": key, "count": int(count), "rate": float(count / len(frame)) if len(frame) else 0} for key, count in frame[col].value_counts(dropna=False).items()]
    return _jsonable(result)


def _impact(before, after, before_schema, after_schema):
    rows = before.index.intersection(after.index, sort=False)
    cols = before.columns.intersection(after.columns, sort=False)
    changes, examples = 0, []
    changed_rows = pd.Series(False, index=rows)
    for col in cols:
        old, new = before.loc[rows, col], after.loc[rows, col]
        same = old.eq(new).fillna(False) | (old.isna() & new.isna())
        diff = ~same
        changes += int(diff.sum())
        changed_rows |= diff
        for row in rows[diff][:max(0, 12 - len(examples))]:
            examples.append({"row_id": _jsonable(row), "column": col, "before": _jsonable(old.loc[row]), "after": _jsonable(new.loc[row])})
    return {"scope": "full", "before": _summary(before, before_schema), "after": _summary(after, after_schema), "removed_rows": len(before) - len(after), "changed_rows": int(changed_rows.sum()), "changed_cells": changes, "added_columns": list(after.columns.difference(before.columns, sort=False)), "removed_columns": list(before.columns.difference(after.columns, sort=False)), "examples": examples, "definitions_changed": before_schema != after_schema}


def preview(frame, schema, rules, context=None):
    """전수 데이터 복사본에서 적용하고 재현 가능한 파라미터·해시를 고정한다."""
    _check_frame(frame, schema)
    if not isinstance(rules, list) or not 1 <= len(rules) <= 100:
        raise CleaningError("미리보기에는 1~100개의 규칙을 지정해 주세요.")
    ids = [r.get("id") for r in rules if isinstance(r, dict)]
    if len(ids) != len(rules) or len(ids) != len(set(ids)):
        raise CleaningError("규칙 ID가 중복되거나 형식이 올바르지 않습니다.")
    result, definitions = frame.copy(deep=True), copy.deepcopy(schema)
    frozen_rules, steps = [], []
    for rule in rules:
        frozen = _freeze_rule(rule, result, definitions, context or {})
        before, before_schema = result.copy(deep=True), copy.deepcopy(definitions)
        try:
            result, definitions, details = _execute_rule(result, definitions, frozen)
        except CleaningError:
            raise
        except (TypeError, ValueError, KeyError, OverflowError) as exc:
            raise CleaningError(f"{rule['id']} 규칙을 적용할 수 없습니다: {str(exc)[:180]}") from exc
        step = _impact(before, result, before_schema, definitions)
        step.update({"rule_id": rule["id"], "operation": rule["operation"], "details": details})
        frozen_rules.append(_jsonable(frozen))
        steps.append(step)
    impact = _impact(frame, result, schema, definitions)
    impact["steps"] = steps
    manifest = {"engine_version": ENGINE_VERSION, "environment": environment(), "source_hash": hash_frame(frame, schema), "output_hash": hash_frame(result, definitions), "source_schema": copy.deepcopy(schema), "output_schema": copy.deepcopy(definitions), "rules": frozen_rules, "created_at": datetime.now(timezone.utc).isoformat(), "impact": impact}
    manifest = _jsonable(manifest)
    manifest["manifest_hash"] = _digest(manifest)
    return {"frame": result, "schema": definitions, "manifest": manifest, "impact": impact, "frame_hash": manifest["output_hash"]}


def apply_manifest(frame, schema, manifest):
    """승인된 전수 미리보기와 같은 입력·환경에서만 고정된 규칙을 재실행한다."""
    envelope = copy.deepcopy(manifest)
    expected = envelope.pop("manifest_hash", None)
    if not expected or expected != _digest(envelope):
        raise CleaningError("미리보기 명세가 변경되었습니다. 다시 미리보기해 주세요.")
    if manifest.get("engine_version") != ENGINE_VERSION or manifest.get("environment") != environment():
        raise CleaningError("정제 엔진 또는 라이브러리 버전이 다릅니다. 같은 환경을 사용하거나 다시 미리보기해 주세요.")
    if manifest.get("source_hash") != hash_frame(frame, schema):
        raise CleaningError("미리보기 이후 입력 데이터나 컬럼 정의가 변경되었습니다.")
    result, definitions = frame.copy(deep=True), copy.deepcopy(schema)
    for frozen in manifest["rules"]:
        public_rule = {k: v for k, v in frozen.items() if not k.startswith("_")}
        _validate_rule(public_rule, result, definitions)
        result, definitions, _ = _execute_rule(result, definitions, frozen)
    if hash_frame(result, definitions) != manifest["output_hash"]:
        raise CleaningError("실행 결과가 승인한 미리보기와 일치하지 않습니다.")
    return result, definitions
