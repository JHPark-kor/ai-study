"""Deterministic evidence for data understanding and targeted investigations.

No function in this module changes the uploaded data. Inferences about business
meaning are kept apart from measured facts and are supplied by the chat layer.
"""
from __future__ import annotations

import hashlib
import io
import json
import math
import re
import warnings
from collections import Counter
from datetime import date, datetime
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd

from .analysis_loader import (load_dataset, missing_mask, standalone_loader_source,
                              notebook_loader_source)

ALGORITHM_VERSION = "1.2"
SAMPLE_LIMIT = 50_000
SAMPLE_MEMORY = 64 * 1024 * 1024
RANDOM_SEED = 41
ROLES = {"numeric", "categorical", "datetime", "text", "id"}
INVESTIGATION_KINDS = {"grouped_missing", "co_missing", "key_duplicates", "date_order",
                       "correlation", "relation_residual", "time_profile", "rule_check",
                       "category_variants", "rows"}


def json_safe(value):
    if value is pd.NA or value is pd.NaT:
        return None
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set, np.ndarray, pd.Index)):
        return [json_safe(v) for v in value]
    if isinstance(value, (datetime, date, pd.Timestamp)):
        return value.isoformat()
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (float, np.floating)):
        return float(value) if math.isfinite(value) else None
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def _evidence(kind, columns, summary, *, count=None, details=None, row_ids=None,
              total_rows=None, sampled=False, severity="info"):
    details = json_safe(details or {})
    identity = json.dumps([kind, columns, details, count, total_rows, sampled], sort_keys=True,
                          ensure_ascii=False, allow_nan=False).encode("utf-8")
    return {"id": "ev_" + hashlib.sha256(identity).hexdigest()[:14], "kind": kind,
            "columns": list(columns), "summary": summary, "count": json_safe(count),
            "details": details, "row_ids": json_safe(list(row_ids or [])[:30]),
            "total_rows": total_rows, "sampled": sampled, "severity": severity,
            "algorithm_version": ALGORITHM_VERSION}


def _column_context(schema, context):
    definitions = (context or {}).get("definitions", {})
    columns = []
    for source in schema:
        column = dict(source)
        supplied = definitions.get(source["id"], {})
        for key in ("role", "description", "unit", "date_format", "expected_range", "code_values",
                    "expected_frequency", "allow_negative", "allowed_values", "definition_status"):
            if key in supplied:
                column[key] = supplied[key]
        if column.get("role") not in ROLES:
            column["role"] = "text"
        columns.append(column)
    return columns


def _numbers(series):
    return pd.to_numeric(series.where(~missing_mask(series)), errors="coerce")


def _dates(series, date_format=None):
    value = series.where(~missing_mask(series)).astype("string")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        return pd.to_datetime(value, errors="coerce", format=date_format or "mixed", utc=True)


def _row_ids(mask):
    return list(mask.index[mask.fillna(False)][:30])


def _sample(frame, max_rows=SAMPLE_LIMIT):
    memory = int(frame.memory_usage(index=True, deep=True).sum())
    if memory > SAMPLE_MEMORY:
        max_rows = min(max_rows, max(1, int(len(frame) * SAMPLE_MEMORY / memory)))
    if len(frame) <= max_rows:
        return frame, False
    return frame.sample(n=max_rows, random_state=RANDOM_SEED).sort_index(), True


def _numeric_profile(series, column):
    missing = missing_mask(series)
    numeric = _numbers(series)
    finite = numeric.notna() & np.isfinite(numeric.astype(float))
    values = numeric[finite].astype(float)
    parse_failed = ~missing & numeric.isna()
    nonfinite = numeric.notna() & ~finite
    n = len(values)
    stats = {"n": n, "parse_failures": int(parse_failed.sum()), "nonfinite": int(nonfinite.sum()),
             "mean": None, "std": None, "min": None, "q1": None, "median": None, "q3": None,
             "max": None, "skew": None, "kurtosis": None, "negative": 0,
             "iqr_candidates": 0, "z_candidates": 0, "iqr_lower": None, "iqr_upper": None,
             "std_ddof": 1, "quantile_method": "linear", "kurtosis_definition": "Fisher excess",
             "iqr_factor": 1.5, "z_threshold": 3.0}
    histogram, boxplot = [], {}
    iqr_mask = pd.Series(False, index=series.index)
    if n:
        q1, median, q3 = values.quantile([.25, .5, .75]).tolist()
        spread = q3 - q1
        lower, upper = q1 - 1.5 * spread, q3 + 1.5 * spread
        iqr_mask = finite & ((numeric < lower) | (numeric > upper))
        std = values.std(ddof=1)
        z_count = int(((values - values.mean()).abs() / std > 3).sum()) if n > 1 and std > 0 else 0
        stats.update({"mean": values.mean(), "std": std if n > 1 else None,
                      "min": values.min(), "q1": q1, "median": median, "q3": q3, "max": values.max(),
                      "skew": values.skew() if n >= 3 and std > 0 else None,
                      "kurtosis": values.kurt() if n >= 4 and std > 0 else None,
                      "negative": int((values < 0).sum()), "iqr_candidates": int(iqr_mask.sum()),
                      "z_candidates": z_count, "iqr_lower": lower, "iqr_upper": upper})
        bins = min(30, max(1, int(math.sqrt(n))))
        counts, edges = np.histogram(values.to_numpy(), bins=bins)
        histogram = [{"lower": float(edges[i]), "upper": float(edges[i + 1]), "count": int(counts[i])}
                     for i in range(len(counts))]
        inside = values.between(lower, upper)
        boxplot = {"min": values.min(), "q1": q1, "median": median, "q3": q3, "max": values.max(),
                   "whisker_low": values[inside].min(), "whisker_high": values[inside].max(),
                   "outlier_count": int(iqr_mask.sum())}
    return json_safe({"stats": stats, "histogram": histogram, "boxplot": boxplot,
                      "parse_failure_rows": _row_ids(parse_failed), "outlier_rows": _row_ids(iqr_mask),
                      "nonfinite_rows": _row_ids(nonfinite),
                      "chart": {"x": column["name"], "unit": column.get("unit", ""), "y": "건수",
                                "sampled": False, "rows": len(series), "included": n,
                                "excluded_missing": int(missing.sum()), "excluded_invalid": int((parse_failed | nonfinite).sum()),
                                "hidden_valid": 0}})


def _category_profile(series, column):
    values = series[~missing_mask(series)].astype(str)
    counts = values.value_counts(dropna=False)
    n = len(values)
    top = counts.head(20)
    rare = counts[counts / n < .01] if n else counts
    result = {"frequency": [{"value": str(key)[:200], "value_truncated": len(str(key)) > 200, "count": int(count), "rate_valid": count / n,
                             "rate_all": count / len(series)} for key, count in top.items()],
              "rare_frequency": [{"value": str(key)[:200], "value_truncated": len(str(key)) > 200,
                                  "count": int(count), "rate_valid": count / n,
                                  "rate_all": count / len(series)} for key, count in rare.head(50).items()],
              "stats": {"mode": str(counts.index[0])[:200] if len(counts) else None,
                        "mode_count": int(counts.iloc[0]) if len(counts) else 0,
                        "unique_ratio": len(counts) / n if n else None,
                        "rare_threshold": .01, "rare_categories": len(rare),
                        "rare_rows": int(rare.sum()), "rare_examples": [str(v)[:200] for v in rare.index[:15]],
                        "id_candidate": n >= 20 and len(counts) / n >= .98},
              "chart": {"x": column["name"], "unit": "", "y": "건수", "sampled": False,
                        "rows": len(series), "included": n, "excluded_missing": len(series) - n,
                        "shown_categories": len(top), "hidden_categories": max(0, len(counts) - len(top)),
                        "hidden_valid": int(counts.iloc[20:].sum())}}
    result["chart"]["labels_truncated"] = int(sum(len(str(value)) > 200 for value in top.index))
    if column["role"] in {"text", "id"}:
        length = values.str.len()
        shape = values.map(_value_shape).value_counts()
        result["stats"].update({"length_min": int(length.min()) if n else None,
                                "length_max": int(length.max()) if n else None,
                                "length_mean": float(length.mean()) if n else None,
                                "whitespace_only": int(values.str.fullmatch(r"\s+").sum()),
                                "outer_whitespace": int(values.ne(values.str.strip()).sum()),
                                "leading_zero": int(values.str.match(r"^[+-]?0\d+$").sum()),
                                "duplicate_extra": int(values.duplicated().sum()),
                                "duplicate_participants": int(values.duplicated(keep=False).sum())})
        result["patterns"] = [{"pattern": str(key), "count": int(count)} for key, count in shape.head(15).items()]
    return json_safe(result)


def _value_shape(value):
    if re.fullmatch(r"\s+", value):
        return "공백"
    if re.fullmatch(r"[+-]?\d+", value):
        return "정수 표기"
    if re.fullmatch(r"[+-]?\d*\.\d+", value):
        return "소수 표기"
    if re.match(r"^\d{4}-\d{1,2}-\d{1,2}", value):
        return "YYYY-MM-DD"
    if re.match(r"^\d{4}/\d{1,2}/\d{1,2}", value):
        return "YYYY/MM/DD"
    if re.match(r"^\d{4}\.\d{1,2}\.\d{1,2}", value):
        return "YYYY.MM.DD"
    if re.fullmatch(r"\d{8}", value):
        return "8자리 숫자"
    if re.match(r"^\d{1,2}/\d{1,2}/\d{4}", value):
        return "DD/MM/YYYY 또는 MM/DD/YYYY"
    if re.fullmatch(r"[A-Za-z]+", value):
        return "영문"
    if re.fullmatch(r"[가-힣\s]+", value):
        return "한글"
    return "혼합 표기"


def _date_profile(series, column):
    missing = missing_mask(series)
    parsed = _dates(series, column.get("date_format"))
    valid = parsed.dropna()
    parse_failed = ~missing & parsed.isna()
    reference = pd.Timestamp.now(tz="UTC")
    unique = valid.sort_values().drop_duplicates()
    intervals = unique.diff().dropna().dt.total_seconds()
    typical = float(intervals.median()) if len(intervals) else None
    gaps = intervals[intervals > typical * 1.5] if typical and typical > 0 else intervals.iloc[:0]
    pattern = series[~missing].astype(str).map(_value_shape).value_counts()
    ambiguous_parts = series.astype("string").str.extract(r"^(\d{1,2})[/-](\d{1,2})[/-]\d{4}(?:\D|$)")
    first = pd.to_numeric(ambiguous_parts[0], errors="coerce")
    second = pd.to_numeric(ambiguous_parts[1], errors="coerce")
    ambiguous = (first.between(1, 12) & second.between(1, 12) & first.ne(second)) if not column.get("date_format") else pd.Series(False, index=series.index)
    span_days = (valid.max() - valid.min()).days if len(valid) else 0
    period = "D" if span_days <= 180 else "W" if span_days <= 1800 else "M"
    counts = valid.dt.tz_localize(None).dt.to_period(period).astype(str).value_counts().sort_index()
    return json_safe({"stats": {"parsed": len(valid), "parse_failures": int(parse_failed.sum()),
                                "start": valid.min() if len(valid) else None,
                                "end": valid.max() if len(valid) else None,
                                "future": int((valid > reference).sum()), "reference_time": reference.isoformat(),
                                "ambiguous_dates": int(ambiguous.sum()),
                                "typical_interval_seconds": typical, "gap_candidates": len(gaps),
                                "max_interval_seconds": float(intervals.max()) if len(intervals) else None,
                                "date_format": column.get("date_format") or "mixed",
                                "timezone": "UTC 기준 비교; 원문 시간대는 원본에 보존"},
                      "patterns": [{"pattern": str(k), "count": int(v)} for k, v in pattern.items()],
                      "date_counts": [{"period": str(k), "count": int(v)} for k, v in counts.head(500).items()],
                      "parse_failure_rows": _row_ids(parse_failed),
                      "ambiguous_date_rows": _row_ids(ambiguous),
                      "chart": {"x": column["name"], "y": "건수", "period": period, "sampled": False,
                                "rows": len(series), "included": len(valid), "excluded_missing": int(missing.sum()),
                                "excluded_invalid": int(parse_failed.sum()), "hidden_periods": max(0, len(counts) - 500),
                                "hidden_valid": int(counts.iloc[500:].sum())}})


def profile_dataset(frame, schema, context=None, deep=False):
    """Full-data univariate measurements; bounded and explicitly sampled deep checks."""
    if list(frame.columns) != [column["id"] for column in schema]:
        raise ValueError("데이터와 컬럼 정의의 순서가 일치하지 않습니다.")
    context = context or {}
    resolved = _column_context(schema, context)
    missing_by_column = {cid: int(missing_mask(frame[cid]).sum()) for cid in frame.columns}
    duplicate_mask = frame.duplicated(keep=False)
    overview = {"rows": len(frame), "columns": len(frame.columns),
                "missing_cells": sum(missing_by_column.values()),
                "duplicate_rows": int(frame.duplicated().sum()),
                "duplicate_participants": int(duplicate_mask.sum()),
                "memory_bytes": int(frame.memory_usage(index=True, deep=True).sum()),
                "types": dict(Counter(col["role"] for col in resolved)),
                "source": context.get("source", ""), "collection_period": context.get("collection_period", ""),
                "observation_unit": context.get("observation_unit", "")}
    evidence = [_evidence("overview", list(frame.columns),
                          f"{len(frame):,}행, {len(frame.columns):,}개 컬럼입니다.",
                          details=overview, total_rows=len(frame))]
    overview["evidence_id"] = evidence[0]["id"]
    if overview["duplicate_rows"]:
        evidence.append(_evidence("duplicate_rows", list(frame.columns),
                                  f"완전히 같은 행이 {overview['duplicate_rows']:,}건 추가로 포함되어 있습니다.",
                                  count=overview["duplicate_rows"], details={"participants": overview["duplicate_participants"],
                                  "meaning": "중복 관측인지 반복 기록인지 별도 확인 필요"},
                                  row_ids=_row_ids(duplicate_mask), total_rows=len(frame), severity="review"))
    headers = Counter(column["name"] for column in resolved)
    header_issues = [col["id"] for col in resolved if not col["name"].strip() or col["name"] != col["name"].strip() or headers[col["name"]] > 1]
    if header_issues:
        evidence.append(_evidence("headers", header_issues, "중복·빈 이름·앞뒤 공백이 있는 컬럼명이 있습니다.",
                                  count=len(header_issues), details={"columns": [{"id": c["id"], "name": c["name"]} for c in resolved if c["id"] in header_issues]}, total_rows=len(frame), severity="review"))
    profiles = []
    for column in resolved:
        cid, name, role = column["id"], column["name"], column["role"]
        series = frame[cid]
        missing = missing_mask(series)
        entry = {"id": cid, "name": name, "role": role, "dtype": str(series.dtype),
                 "unit": column.get("unit", ""), "description": column.get("description", ""),
                 "rows": len(series), "valid": len(series) - int(missing.sum()),
                 "missing": int(missing.sum()), "missing_rate": float(missing.mean()) if len(series) else None,
                 "unique": int(series[~missing].nunique()), "sampled": False,
                 "examples": [str(value)[:160] for value in series[~missing].drop_duplicates().head(5)]}
        if role == "numeric":
            entry.update(_numeric_profile(series, column))
        elif role == "datetime":
            entry.update(_date_profile(series, column))
        else:
            entry.update(_category_profile(series, column))
        fact = _evidence("column_profile", [cid], f"{name}의 분포와 품질을 점검했습니다.",
                         details=entry, total_rows=len(frame))
        entry["evidence_id"] = fact["id"]
        evidence.append(fact)
        if entry["missing"]:
            evidence.append(_evidence("missing", [cid], f"{name}: 결측값 {entry['missing']:,}건({entry['missing_rate']:.1%}).",
                                      count=entry["missing"], details={"rate": entry["missing_rate"], "denominator": len(frame)},
                                      row_ids=_row_ids(missing), total_rows=len(frame), severity="review"))
        parse_count = entry.get("stats", {}).get("parse_failures", 0)
        if parse_count:
            evidence.append(_evidence("parse_failure", [cid], f"{name}: {role} 형식으로 해석되지 않는 값 {parse_count:,}건.",
                                      count=parse_count, row_ids=entry.get("parse_failure_rows", []),
                                      details={"role": role, "original_missing": entry["missing"]}, total_rows=len(frame), severity="review"))
        if entry.get("stats", {}).get("ambiguous_dates"):
            evidence.append(_evidence("ambiguous_date", [cid], f"{name}: 일/월 순서에 따라 해석이 달라지는 날짜 {entry['stats']['ambiguous_dates']:,}건.",
                                      count=entry["stats"]["ambiguous_dates"], details={"interpretation": "현재 날짜 요약은 자동 해석 초안. 일/월 형식 확인 후 재검사 필요"},
                                      row_ids=entry["ambiguous_date_rows"], total_rows=len(frame), severity="review"))
        if role == "numeric":
            stats = entry["stats"]
            if stats["iqr_candidates"]:
                evidence.append(_evidence("outlier_candidate", [cid], f"{name}: IQR 기준의 극단값 후보 {stats['iqr_candidates']:,}건.",
                                          count=stats["iqr_candidates"], details={"lower": stats["iqr_lower"], "upper": stats["iqr_upper"],
                                          "method": "Q1−1.5×IQR, Q3+1.5×IQR", "interpretation": "통계적 후보이며 오류 판정이 아님"},
                                          row_ids=entry["outlier_rows"], total_rows=len(frame), severity="review"))
            if stats["negative"]:
                evidence.append(_evidence("negative_values", [cid], f"{name}: 음수 {stats['negative']:,}건.",
                                          count=stats["negative"], details={"allow_negative": column.get("allow_negative"),
                                          "interpretation": "변환값·환불·수익률 등 업무 의미에 따라 정상일 수 있음"},
                                          row_ids=_row_ids(_numbers(series) < 0), total_rows=len(frame)))
        expected = column.get("expected_range")
        if isinstance(expected, dict) and any(key in expected for key in ("min", "max")):
            try:
                evidence.extend(investigate(frame, resolved, {"kind": "rule_check", "columns": [cid], "params": expected}, context))
            except ValueError as exc:
                evidence.append(_evidence("invalid_definition", [cid], f"{name}: 허용 범위 정의를 확인해야 합니다.",
                                          details={"reason": str(exc), "definition": expected}, total_rows=len(frame), severity="review"))
        profiles.append(entry)
    evidence.extend(_identical_columns(frame))
    deep_info = {"performed": False, "sampled": False, "checks": [], "skipped": []}
    if deep:
        extra, deep_info = _automatic_deep(frame, resolved, profiles, context)
        evidence.extend(extra)
    return json_safe({"overview": overview, "columns": profiles, "evidence": evidence,
                      "deep": deep_info, "algorithm_version": ALGORITHM_VERSION,
                      "missing_policy": "빈 문자열과 실제 결측만 집계; NA·null·공백 표기는 별도 확인",
                      "limitations": ["통계적 극단값·음수·미래 날짜는 업무 오류로 확정하지 않습니다.",
                                      "수집 원인과 값의 실제 정확성은 출처 자료 확인이 필요할 수 있습니다."]})


def _identical_columns(frame):
    if len(frame.columns) < 2:
        return []
    probe = frame if len(frame) <= 2000 else frame.sample(n=2000, random_state=RANDOM_SEED)
    buckets = {}
    for cid in frame.columns:
        digest = hashlib.sha256(pd.util.hash_pandas_object(probe[cid], index=False).values.tobytes()).hexdigest()
        buckets.setdefault(digest, []).append(cid)
    results = []
    for candidate in buckets.values():
        while len(candidate) > 1:
            first, *others = candidate
            identical = [cid for cid in others if frame[first].equals(frame[cid])]
            if identical:
                results.append(_evidence("identical_columns", [first] + identical,
                                          "전체 행의 값이 같은 컬럼이 있습니다. 의미가 같은지 확인한 뒤 삭제할 수 있습니다.",
                                          count=len(identical), details={"comparison": "전체 행·자료형 일치", "semantic_duplicate": "미확정"}, total_rows=len(frame), severity="review"))
            candidate = [cid for cid in others if cid not in identical]
    return results


def investigate(frame, schema, request: dict, context=None, *, _sampled=None):
    """Run only named, bounded, read-only operations. Never evaluate supplied code."""
    if not isinstance(request, dict) or request.get("kind") not in INVESTIGATION_KINDS:
        raise ValueError("지원하지 않는 추가 검사입니다.")
    kind = request["kind"]
    columns = request.get("columns", [])
    if not isinstance(columns, list) or not columns or len(columns) > 12 or len(set(columns)) != len(columns):
        raise ValueError("검사할 컬럼 ID를 1~12개 지정해 주세요.")
    if any(not isinstance(cid, str) or cid not in frame.columns for cid in columns):
        raise ValueError("검사 요청에 현재 데이터에 없는 컬럼이 포함되어 있습니다.")
    params = request.get("params") or {}
    if not isinstance(params, dict):
        raise ValueError("검사 설정은 객체여야 합니다.")
    resolved = {item["id"]: item for item in _column_context(schema, context)}
    cid = columns[0]
    name = resolved[cid]["name"]
    all_rows = len(frame)
    exact = {"key_duplicates", "date_order", "rule_check", "rows"}
    work, sampled = (frame, False) if kind in exact else (_sampled if _sampled is not None else _sample(frame))
    n = len(work)
    detail = {"source_rows": all_rows, "examined_rows": n, "seed": RANDOM_SEED if sampled else None}
    masks = []
    count, row_ids = None, []

    if kind == "grouped_missing":
        groups = params.get("group_by", [])
        if not isinstance(groups, list) or not 1 <= len(groups) <= 2 or len(set(groups)) != len(groups) or any(g not in frame for g in groups):
            raise ValueError("집단 컬럼을 1~2개 지정해 주세요.")
        period_column = params.get("period_column")
        group_frame = work[groups].copy()
        for group in groups:
            group_frame[group] = group_frame[group].where(~missing_mask(group_frame[group])).astype("string").fillna("〈결측〉")
        if period_column:
            if period_column not in frame or period_column in groups:
                raise ValueError("기간 검사 컬럼을 확인해 주세요.")
            period = params.get("period", "M")
            if period not in {"D", "W", "M", "Q", "Y"}:
                raise ValueError("기간 단위는 D/W/M/Q/Y 중 하나입니다.")
            parsed = _dates(work[period_column], resolved[period_column].get("date_format"))
            group_frame[period_column] = parsed.dt.tz_localize(None).dt.to_period(period).astype("string").fillna("〈날짜 미확인〉")
            groups = groups + [period_column]
        group_frame["_missing"] = missing_mask(work[cid]).astype(int)
        aggregated = group_frame.groupby(groups, dropna=False, observed=True)["_missing"].agg(["count", "sum"])
        aggregated["rate"] = aggregated["sum"] / aggregated["count"]
        shown = aggregated.sort_values(["rate", "count"], ascending=[False, False]).head(100)
        records = []
        for key, values in shown.iterrows():
            keys = key if isinstance(key, tuple) else (key,)
            records.append({"group": dict(zip(groups, keys)), "rows": int(values["count"]),
                            "missing": int(values["sum"]), "rate": float(values["rate"]),
                            "small_group": values["count"] < 20})
        detail.update({"groups": records, "group_by": groups, "total_groups": len(aggregated),
                       "hidden_groups": max(0, len(aggregated) - len(shown)),
                       "overall_missing_rate": float(missing_mask(work[cid]).mean()) if n else None,
                       "max_rate_difference": float(aggregated["rate"].max() - aggregated["rate"].min()) if len(aggregated) else None,
                       "interpretation": "집단 차이는 원인을 확정하지 않으며 작은 집단은 함께 확인"})
        count = int(missing_mask(work[cid]).sum())
        row_ids = _row_ids(missing_mask(work[cid]))
        summary = f"{name}의 집단별 결측률을 비교했습니다."
        columns = list(dict.fromkeys(columns + groups))

    elif kind == "co_missing":
        if len(columns) < 2:
            raise ValueError("동시 결측 검사는 컬럼이 두 개 이상 필요합니다.")
        missing = {key: missing_mask(work[key]) for key in columns}
        pairs = []
        for first, second in combinations(columns, 2):
            both = missing[first] & missing[second]
            union = missing[first] | missing[second]
            pairs.append({"columns": [first, second], "both_missing": int(both.sum()),
                          "either_missing": int(union.sum()),
                          "jaccard": float(both.sum() / union.sum()) if union.any() else None,
                          "rate_all": float(both.mean()) if n else None})
        detail["pairs"] = sorted(pairs, key=lambda x: x["both_missing"], reverse=True)
        count = sum(1 for pair in pairs if pair["both_missing"])
        summary = "여러 컬럼이 함께 결측인 패턴을 점검했습니다."

    elif kind == "key_duplicates":
        if len(columns) > 4:
            raise ValueError("복합 키는 컬럼 네 개까지 검사합니다.")
        missing_key = pd.concat([missing_mask(work[key]) for key in columns], axis=1).any(axis=1)
        valid = work.loc[~missing_key, columns]
        duplicated = valid.duplicated(keep=False)
        count = int(valid.duplicated().sum())
        row_ids = _row_ids(duplicated)
        detail.update({"extra_rows": count, "participating_rows": int(duplicated.sum()),
                       "missing_key_rows": int(missing_key.sum()), "null_policy": "불완전한 키는 중복 판정에서 제외해 별도 집계",
                       "interpretation": "반복 관측 여부와 관측 단위를 확인한 뒤 삭제 판단"})
        summary = f"지정한 키에서 중복으로 추가된 행 {count:,}건이 확인되었습니다."

    elif kind == "date_order":
        if len(columns) != 2:
            raise ValueError("시작일과 종료일 컬럼을 지정해 주세요.")
        start = _dates(work[columns[0]], resolved[columns[0]].get("date_format"))
        end = _dates(work[columns[1]], resolved[columns[1]].get("date_format"))
        comparable = start.notna() & end.notna()
        invalid = comparable & (end < start)
        count, row_ids = int(invalid.sum()), _row_ids(invalid)
        detail.update({"comparable_rows": int(comparable.sum()), "unparsed_or_missing_rows": int((~comparable).sum()),
                       "rule": "종료일 >= 시작일", "interpretation": "컬럼의 시작·종료 의미가 맞는 경우에 적용되는 규칙"})
        summary = f"종료일이 시작일보다 빠른 행 {count:,}건이 확인되었습니다."

    elif kind in {"correlation", "relation_residual"}:
        if len(columns) != 2:
            raise ValueError("비교할 수치형 컬럼 두 개를 지정해 주세요.")
        xy = pd.concat([_numbers(work[key]) for key in columns], axis=1).replace([np.inf, -np.inf], np.nan).dropna()
        xy.columns = columns
        detail.update({"complete_pairs": len(xy), "excluded_pairs": n - len(xy),
                       "interpretation": "상관·잔차는 관계의 후보이며 인과관계나 업무 오류를 확정하지 않음"})
        usable = len(xy) >= 3 and all(xy[key].nunique() > 1 for key in columns)
        pearson = float(xy[columns[0]].corr(xy[columns[1]])) if usable else None
        spearman = float(xy[columns[0]].rank().corr(xy[columns[1]].rank())) if usable else None
        detail.update({"pearson": pearson, "spearman": spearman})
        if kind == "relation_residual" and usable and len(xy) >= 20:
            x, y = xy[columns[0]].to_numpy(dtype=float), xy[columns[1]].to_numpy(dtype=float)
            centered = x - x.mean()
            slope = float(np.dot(centered, y - y.mean()) / np.dot(centered, centered))
            intercept = float(y.mean() - slope * x.mean())
            residual = pd.Series(y - (slope * x + intercept), index=xy.index)
            med = float(residual.median())
            mad = float((residual - med).abs().median())
            scale = mad * 1.4826
            tolerance = max(float(np.max(np.abs(y))) * 1e-9, 1e-9)
            threshold = max(4.5 * scale, tolerance)
            # Weak linear relationships do not support a residual-outlier judgment.
            suitable = abs(pearson or 0) >= .5
            candidate = (residual - med).abs() > threshold if suitable else pd.Series(False, index=xy.index)
            count, row_ids = int(candidate.sum()), _row_ids(candidate)
            detail.update({"method": "OLS 직선의 잔차 / 중앙값 절대편차(MAD)", "slope": slope,
                           "intercept": intercept, "residual_median": med, "residual_mad": mad,
                           "threshold": threshold, "suitable": suitable,
                           "interpretation": "직선 관계를 가정한 후보. 비선형 관계·집단 구성·업무 조건을 추가 확인",
                           "scatter": [{"x": float(row[columns[0]]), "y": float(row[columns[1]]), "row_id": json_safe(index)}
                                       for index, row in xy.sample(min(300, len(xy)), random_state=RANDOM_SEED).iterrows()]})
            summary = f"두 변수의 관계에서 벗어나는 후보 {count:,}건을 확인했습니다." if suitable else "선형 관계가 약해 잔차 기준의 이상 후보 판정을 보류했습니다."
        else:
            detail["reason"] = "비결측 쌍 20건 이상과 변동이 필요" if kind == "relation_residual" else "세 쌍 이상과 변동이 필요"
            summary = "두 변수의 상관을 계산했습니다." if usable else "상수 또는 유효 쌍 부족으로 상관을 계산하지 않았습니다."

    elif kind == "time_profile":
        if len(columns) > 2:
            raise ValueError("날짜와 선택적인 수치형 컬럼을 지정해 주세요.")
        period = params.get("period", "M")
        if period not in {"D", "W", "M", "Q", "Y"}:
            raise ValueError("기간 단위는 D/W/M/Q/Y 중 하나입니다.")
        parsed = _dates(work[cid], resolved[cid].get("date_format"))
        periods = parsed.dt.tz_localize(None).dt.to_period(period)
        table = pd.DataFrame({"period": periods, "rows": 1}, index=work.index)
        if len(columns) == 2:
            table["value"] = _numbers(work[columns[1]])
            table["missing"] = missing_mask(work[columns[1]]).astype(int)
            aggregate = table.dropna(subset=["period"]).groupby("period").agg(rows=("rows", "sum"), mean=("value", "mean"), median=("value", "median"), missing=("missing", "sum"))
        else:
            aggregate = table.dropna(subset=["period"]).groupby("period").agg(rows=("rows", "sum"))
        detail.update({"period": period, "unparsed_or_missing_dates": int(parsed.isna().sum()),
                       "periods": [{"period": str(index), **json_safe(row.to_dict())} for index, row in aggregate.head(500).iterrows()],
                       "hidden_periods": max(0, len(aggregate) - 500),
                       "interpretation": "시간별 변화이며 수집 누락·행동 변화의 원인은 별도 확인"})
        summary = f"{name} 기준으로 기간별 건수와 분포를 비교했습니다."

    elif kind == "rule_check":
        if len(columns) != 1:
            raise ValueError("범위 검사는 컬럼 하나씩 지정해 주세요.")
        if not any(key in params for key in ("min", "max", "allowed_values")):
            raise ValueError("최솟값·최댓값·허용값 중 하나를 지정해 주세요.")
        invalid = pd.Series(False, index=work.index)
        numeric = _numbers(work[cid])
        for key in ("min", "max"):
            if key in params:
                boundary = params[key]
                if isinstance(boundary, bool) or not isinstance(boundary, (int, float)) or not math.isfinite(boundary):
                    raise ValueError("범위 경계는 유한한 숫자여야 합니다.")
                invalid |= numeric.lt(boundary) if key == "min" else numeric.gt(boundary)
        if "allowed_values" in params:
            allowed = params["allowed_values"]
            if not isinstance(allowed, list) or len(allowed) > 200:
                raise ValueError("허용값은 200개 이하 목록으로 지정해 주세요.")
            invalid |= ~missing_mask(work[cid]) & ~work[cid].astype(str).isin([str(v) for v in allowed])
        count, row_ids = int(invalid.sum()), _row_ids(invalid)
        detail.update({"rule": {key: params[key] for key in ("min", "max", "allowed_values") if key in params},
                       "unparsed_numeric": int((~missing_mask(work[cid]) & numeric.isna()).sum()),
                       "interpretation": "제공된 업무 규칙에 대한 위반 건수"})
        summary = f"{name}: 지정한 허용 기준을 벗어난 값 {count:,}건."

    elif kind == "category_variants":
        if len(columns) != 1:
            raise ValueError("표기 검사는 컬럼 하나씩 지정해 주세요.")
        values = work[cid][~missing_mask(work[cid])].astype(str)
        counts = values.value_counts()
        groups = {}
        for value, number in counts.head(10_000).items():
            normalized = re.sub(r"\s+", " ", value.strip()).casefold()
            groups.setdefault(normalized, []).append({"value": value, "count": int(number)})
        variants = [{"normalized": key, "variants": values} for key, values in groups.items() if len(values) > 1]
        count = len(variants)
        detail.update({"candidates": variants[:50], "hidden_candidates": max(0, count - 50),
                       "unexamined_categories": max(0, len(counts) - 10_000),
                       "normalization": "앞뒤 공백·연속 공백·영문 대소문자", "interpretation": "동일 의미 확정 전 자동 통합하지 않음"})
        summary = f"{name}: 공백·대소문자가 다른 표기 후보 {count:,}개."

    else:  # rows; an explicit read-only row preview, no query language.
        ids = params.get("row_ids")
        missing_column = params.get("missing_column")
        if ids is not None:
            if not isinstance(ids, list) or len(ids) > 50 or any(not isinstance(index, int) for index in ids):
                raise ValueError("행 ID는 정수 50개 이하로 지정해 주세요.")
            if any(index not in frame.index for index in ids):
                raise ValueError("현재 버전에 없는 행 ID입니다.")
            selected = frame.loc[ids, columns]
        elif missing_column in frame:
            selected = frame.loc[missing_mask(frame[missing_column]), columns].head(30)
        else:
            selected = frame.loc[:, columns].head(20)
        count = len(selected)
        row_ids = list(selected.index)
        detail["rows"] = [{"row_id": json_safe(index), "values": json_safe(row.to_dict())} for index, row in selected.iterrows()]
        summary = f"선택한 데이터 {count:,}행을 확인했습니다."
    return [_evidence(kind, columns, summary, count=count, details=detail, row_ids=row_ids,
                      total_rows=all_rows, sampled=sampled, severity="review" if count else "info")]


def _automatic_deep(frame, schema, profiles, context):
    """Build a bounded, dataset-specific quality baseline for every upload.

    The checks are selected from the current schema and measured values only.
    Nothing from another project is used, and no cleaning is applied here.
    Codex can request targeted follow-up checks after reviewing this evidence.
    """
    goal = str((context or {}).get("goal", ""))
    ordered = sorted(schema, key=lambda col: (col["name"] not in goal, col.get("position", 0)))
    numeric = [col["id"] for col in ordered if col["role"] == "numeric"]
    categories = [col["id"] for col in ordered if col["role"] == "categorical" and 2 <= frame[col["id"]].nunique() <= 50]
    dates = [col["id"] for col in ordered if col["role"] == "datetime"]
    ids = [col["id"] for col in ordered if col["role"] == "id"]
    missing = [entry["id"] for entry in sorted(profiles, key=lambda p: p["missing"], reverse=True) if entry["missing"]]
    requests = []
    if len(missing) >= 2:
        requests.append({"kind": "co_missing", "columns": missing[:8]})
    for target in missing[:3]:
        for group in categories[:2]:
            if target != group:
                requests.append({"kind": "grouped_missing", "columns": [target], "params": {"group_by": [group]}})
        if categories and dates:
            requests.append({"kind": "grouped_missing", "columns": [target], "params": {"group_by": categories[:1], "period_column": dates[0], "period": "M"}})
    for key in ids[:2]:
        requests.append({"kind": "key_duplicates", "columns": [key]})
    for first, second in list(combinations(numeric[:5], 2))[:4]:
        requests.extend([{"kind": "correlation", "columns": [first, second]},
                         {"kind": "relation_residual", "columns": [first, second]}])
    if dates:
        requests.append({"kind": "time_profile", "columns": [dates[0]] + numeric[:1]})
    starts = [col for col in ordered if col["role"] == "datetime" and re.search(r"start|시작|접수|발생", col["name"].lower())]
    ends = [col for col in ordered if col["role"] == "datetime" and re.search(r"end|종료|완료", col["name"].lower())]
    if starts and ends:
        requests.append({"kind": "date_order", "columns": [starts[0]["id"], ends[0]["id"]]})
    for cid in categories[:2]:
        requests.append({"kind": "category_variants", "columns": [cid]})
    # Reserve each family before allowing high-dimensional combinations to fill the budget.
    prioritized = []
    seen_kinds = set()
    for request in requests:
        if request["kind"] not in seen_kinds:
            prioritized.append(request)
            seen_kinds.add(request["kind"])
    prioritized.extend(request for request in requests if request not in prioritized)
    results, checks, skipped = [], [], []
    sampled_view = _sample(frame)
    for request in prioritized[:20]:
        try:
            current = investigate(frame, schema, request, context, _sampled=sampled_view)
            results.extend(current)
            checks.append({"kind": request["kind"], "columns": request["columns"], "evidence_ids": [ev["id"] for ev in current]})
        except ValueError as exc:
            skipped.append({"kind": request["kind"], "reason": str(exc)})
    if len(prioritized) > 20:
        skipped.append({"kind": "budget", "reason": f"자동 검사 예산에 따라 {len(prioritized) - 20}개 후보를 보류했습니다. 필요한 검사는 대화에서 추가할 수 있습니다."})
    if not requests:
        skipped.append({"kind": "no_candidates", "reason": "현재 변수 유형에서 자동 다변량 검사 후보가 없습니다. 의미·역할 확인 후 추가 검사를 요청할 수 있습니다."})
    return results, {"performed": True, "checks": checks, "skipped": skipped,
                     "sampled": any(ev.get("sampled", False) for ev in results), "sample_limit": SAMPLE_LIMIT,
                     "seed": RANDOM_SEED, "scope": "목적에 언급된 컬럼 우선, 유형별 제한된 조합; 모든 변수 조합을 검사하지 않음"}


_FIELD_ALIASES = {
    "column_name": "column_name", "column": "column_name", "컬럼명": "column_name",
    "변수명": "column_name", "필드명": "column_name", "name": "column_name",
    "column_id": "column_id", "id": "column_id", "컬럼id": "column_id",
    "column_index": "column_index", "position": "column_index", "열번호": "column_index",
    "description": "description", "설명": "description", "의미": "description", "정의": "description",
    "role": "role", "역할": "role", "변수유형": "role", "유형": "role",
    "unit": "unit", "단위": "unit", "dtype": "expected_dtype", "자료형": "expected_dtype",
    "code_values": "code_values", "코드값": "code_values", "코드정의": "code_values",
    "expected_range": "expected_range", "허용범위": "expected_range",
    "date_format": "date_format", "날짜형식": "date_format",
    "expected_frequency": "expected_frequency", "수집주기": "expected_frequency",
    "allow_negative": "allow_negative", "음수허용": "allow_negative",
}
_ROLE_ALIASES = {"numeric": "numeric", "number": "numeric", "수치형": "numeric", "숫자": "numeric",
                 "categorical": "categorical", "nominal": "categorical", "범주형": "categorical",
                 "datetime": "datetime", "date": "datetime", "날짜": "datetime", "날짜형": "datetime",
                 "text": "text", "문자": "text", "문자열": "text", "텍스트": "text",
                 "id": "id", "식별자": "id", "identifier": "id"}
_DATASET_ALIASES = {"dataset_description": "dataset_description", "데이터설명": "dataset_description",
                    "description": "dataset_description", "source": "source", "출처": "source",
                    "collection_period": "collection_period", "수집기간": "collection_period",
                    "observation_unit": "observation_unit", "관측단위": "observation_unit",
                    "collection_date": "collection_date", "수집일": "collection_date",
                    "source_version": "source_version", "출처버전": "source_version"}


def _normalize_key(key):
    return re.sub(r"\s+", "", str(key)).lower()


def _unpack_metadata(document):
    if isinstance(document, list):
        return document, {}
    if not isinstance(document, dict):
        raise ValueError("메타데이터 JSON은 객체 또는 컬럼 정의 목록이어야 합니다.")
    dataset = {}
    for key, value in document.items():
        if _normalize_key(key) in _DATASET_ALIASES:
            dataset[_DATASET_ALIASES[_normalize_key(key)]] = value
    if isinstance(document.get("dataset"), dict):
        for key, value in document["dataset"].items():
            if _normalize_key(key) in _DATASET_ALIASES:
                dataset[_DATASET_ALIASES[_normalize_key(key)]] = value
    rows = document.get("columns", document.get("컬럼", document.get("definitions", [])))
    if isinstance(rows, dict):
        rows = [{"column_id" if re.fullmatch(r"c\d{4}", str(key)) else "column_name": key, **value}
                for key, value in rows.items() if isinstance(value, dict)]
    if not isinstance(rows, list):
        raise ValueError("columns 항목은 컬럼 정의 목록이어야 합니다.")
    if not rows and any(_FIELD_ALIASES.get(_normalize_key(key)) in {"column_name", "column_id"} for key in document):
        rows = [document]
    return rows, dataset


def read_metadata(raw: bytes | None, filename: str | None, text: str, schema: list) -> dict:
    """Match explicit definitions; free prose remains context, never an executable rule.

    Exact IDs/names are applied. Normalized-name matches are suggestions. A
    contradictory confirmed definition is recorded for review, never overwritten.
    """
    result = {"definitions": {}, "dataset": {}, "warnings": [], "unmatched": [],
              "suggestions": [], "conflicts": [], "sources": [], "text": str(text or ""),
              "source_text": ""}
    sources = []
    if raw is not None:
        if len(raw) > 20 * 1024 * 1024:
            raise ValueError("메타데이터 파일은 20MB 이하로 업로드해 주세요.")
        suffix = Path(filename or "").suffix.lower()
        label = Path(filename or "metadata").name
        origin = {"kind": "file", "filename": label, "sha256": hashlib.sha256(raw).hexdigest()}
        result["sources"].append(origin)
        if suffix in {".csv", ".xlsx"}:
            meta_frame, meta_schema, ingest = load_dataset(raw, label)
            renamed = meta_frame.rename(columns={column["id"]: column["name"] for column in meta_schema})
            if len(set(renamed.columns)) != len(renamed.columns):
                raise ValueError("메타데이터 파일의 필드명이 중복되어 있습니다.")
            rows, dataset = renamed.to_dict(orient="records"), {}
            result["warnings"].extend(ingest["warnings"])
            sources.append((rows, dataset, origin))
        elif suffix in {".json", ".txt", ".md"}:
            from .analysis_loader import _decode_csv
            decoded, encoding = _decode_csv(raw)
            if suffix == ".json":
                try:
                    rows, dataset = _unpack_metadata(json.loads(decoded))
                except (ValueError, json.JSONDecodeError) as exc:
                    raise ValueError("메타데이터 JSON 형식을 확인해 주세요.") from exc
                sources.append((rows, dataset, origin))
            else:
                result["source_text"] = decoded[:200_000]
                if len(decoded) > 200_000:
                    result["warnings"].append("메타데이터 문서는 앞 200,000자만 해석 대상으로 전달합니다. 원본 파일은 별도로 보존됩니다.")
        else:
            raise ValueError("메타데이터는 CSV·XLSX·JSON·TXT·MD 형식을 지원합니다.")
    manual = str(text or "").strip()
    if len(result["text"]) > 200_000:
        result["text"] = result["text"][:200_000]
        result["warnings"].append("추가 설명은 앞 200,000자만 해석 대상으로 전달합니다.")
    if manual.startswith(("{", "[")):
        try:
            rows, dataset = _unpack_metadata(json.loads(manual))
            sources.append((rows, dataset, {"kind": "manual", "label": "직접 입력"}))
        except (ValueError, json.JSONDecodeError):
            result["warnings"].append("직접 입력한 내용은 JSON 정의로 읽지 못해 설명문으로 전달합니다.")
    by_id = {col["id"]: col for col in schema}
    for rows, dataset, origin in sources:
        for key, value in dataset.items():
            if key in result["dataset"] and result["dataset"][key] != value:
                result["conflicts"].append({"scope": "dataset", "field": key, "previous": result["dataset"][key],
                                             "incoming": value, "resolution": "직접 입력 우선" if origin["kind"] == "manual" else "앞선 정의 유지"})
                if origin["kind"] != "manual":
                    continue
            result["dataset"][key] = json_safe(value)
        if len(rows) > 1000:
            result["warnings"].append("컬럼 정의는 앞 1,000개 행을 읽었습니다. 나머지 행은 적용하지 않았습니다.")
        for raw_row in rows[:1000]:
            if not isinstance(raw_row, dict):
                result["unmatched"].append({"row": json_safe(raw_row), "reason": "컬럼 정의 행 형식이 아님"})
                continue
            row = {_FIELD_ALIASES[_normalize_key(key)]: value for key, value in raw_row.items()
                   if _normalize_key(key) in _FIELD_ALIASES and value is not None and value != ""}
            explicit_id = row.get("column_id")
            name = str(row.get("column_name", ""))
            matched = by_id.get(str(explicit_id)) if explicit_id else None
            if explicit_id and not matched:
                result["unmatched"].append({"row": json_safe(raw_row), "reason": "없는 column_id"})
                continue
            if not matched:
                exact = [col for col in schema if name and name in {col["original_name"], col["name"]}]
                if "column_index" in row:
                    try:
                        position = int(row["column_index"])
                    except (ValueError, TypeError):
                        position = -1
                    exact = [col for col in exact if col.get("position") == position]
                if len(exact) == 1:
                    matched = exact[0]
                elif len(exact) > 1:
                    result["unmatched"].append({"row": json_safe(raw_row), "reason": "중복 헤더: column_id 또는 column_index가 필요", "candidates": [col["id"] for col in exact]})
                    continue
                else:
                    normalized = [col for col in schema if name and _normalize_key(name) in {_normalize_key(col["name"]), _normalize_key(col["original_name"])}]
                    if len(normalized) == 1:
                        result["suggestions"].append({"row": json_safe(raw_row), "column_id": normalized[0]["id"], "reason": "공백·대소문자 정규화 후 일치; 확인 전 미적용"})
                    else:
                        result["unmatched"].append({"row": json_safe(raw_row), "reason": "일치하는 컬럼 없음"})
                    continue
            cid = matched["id"]
            target = result["definitions"].setdefault(cid, {"sources": [], "definition_status": "provided"})
            for key, value in row.items():
                if key in {"column_name", "column_id", "column_index"}:
                    continue
                if key == "role":
                    value = _ROLE_ALIASES.get(str(value).strip().lower())
                    if not value:
                        result["warnings"].append(f"{matched['name']}: 알 수 없는 역할은 적용하지 않았습니다.")
                        continue
                if key in {"code_values", "expected_range"} and isinstance(value, str):
                    try:
                        value = json.loads(value)
                    except ValueError:
                        result["warnings"].append(f"{matched['name']}: {key}는 구조화된 규칙으로 읽지 못해 설명 자료로만 보관했습니다.")
                        target.setdefault("notes", []).append({key: value})
                        continue
                if key == "allow_negative" and not isinstance(value, bool):
                    if str(value).lower() in {"true", "yes", "허용"}:
                        value = True
                    elif str(value).lower() in {"false", "no", "불허"}:
                        value = False
                    else:
                        result["warnings"].append(f"{matched['name']}: 음수 허용 여부를 해석하지 못했습니다.")
                        continue
                existing = matched.get(key)
                confirmed = matched.get("definition_status") in {"confirmed", "user_confirmed"}
                if confirmed and existing not in (None, "") and existing != value:
                    result["conflicts"].append({"column_id": cid, "field": key, "previous": existing, "incoming": json_safe(value), "resolution": "사용자 확정값 유지; 재확인 필요"})
                    continue
                if key in target and target[key] != value:
                    result["conflicts"].append({"column_id": cid, "field": key, "previous": target[key], "incoming": json_safe(value),
                                                "resolution": "직접 입력 우선" if origin["kind"] == "manual" else "앞선 정의 유지"})
                    if origin["kind"] != "manual":
                        continue
                target[key] = json_safe(value)
            if origin not in target["sources"]:
                target["sources"].append(origin)
    result.update(result["dataset"])
    if result["conflicts"]:
        result["warnings"].append(f"정의가 충돌하는 항목 {len(result['conflicts'])}개를 별도로 기록했습니다.")
    return json_safe(result)
