"""Read data without silently changing identifiers, headers, or missing-value tokens.

This file is self-contained so the same loader can be embedded in an exported
notebook. Conversions belong to the separately approved cleaning manifest.
"""
from __future__ import annotations

import csv
import hashlib
import io
import re
import warnings
import zipfile
from collections import Counter
from datetime import date, datetime
from pathlib import Path

import numpy as np
import pandas as pd

MAX_FILE_BYTES = 150 * 1024 * 1024
MAX_COLUMNS = 300
MAX_FRAME_BYTES = 768 * 1024 * 1024
SUPPORTED_DATA_SUFFIXES = {".csv", ".xlsx", ".txt", ".tsv", ".arff", ".ts"}


def missing_mask(series: pd.Series) -> pd.Series:
    """An empty field is missing. Literal NA, null, and whitespace remain values."""
    return series.isna() | series.eq("").fillna(False)


def _text(value):
    if value is None:
        return ""
    return str(value)


def _decode_csv(raw: bytes, encoding=None):
    encodings = [encoding] if encoding else ["utf-8-sig", "cp949"]
    for candidate in encodings:
        try:
            return raw.decode(candidate), candidate
        except (UnicodeDecodeError, LookupError):
            continue
    raise ValueError("파일 인코딩을 확인해 주세요. UTF-8 또는 CP949로 저장하거나 읽기 설정을 지정할 수 있습니다.")


def _guess_role(series: pd.Series, name: str) -> str:
    values = series[~missing_mask(series)]
    if values.empty:
        return "text"
    sample = values.head(1000)
    strings = sample.astype(str)
    id_name = bool(re.search(r"(^id$|(^|[_\s])id($|[_\s])|identifier|번호$|코드$|아이디$)", name.lower()))
    leading_zero = bool(strings.str.match(r"^[+-]?0\d+$").any())
    if id_name or leading_zero:
        return "id"
    if pd.api.types.is_datetime64_any_dtype(series):
        return "datetime"
    if any(isinstance(v, (datetime, date, pd.Timestamp)) for v in sample):
        return "datetime"
    date_name = bool(re.search(r"date|time|날짜|일자|일시|시각|년월|시작일|종료일|생년월일", name.lower()))
    date_shape = strings.str.match(r"^\d{4}[-/.년]\d{1,2}[-/.월]|^\d{1,2}[-/]\d{1,2}[-/]\d{4}|^\d{8}$")
    if date_shape.mean() >= .8 or (date_name and date_shape.any()):
        return "datetime"
    numeric = pd.to_numeric(sample, errors="coerce")
    if numeric.notna().mean() >= .9:
        if pd.api.types.is_bool_dtype(series):
            return "categorical"
        return "numeric"
    if strings.str.len().mean() <= 80 and (values.nunique(dropna=True) <= 40 or values.nunique(dropna=True) / len(values) <= .1):
        return "categorical"
    return "text"


def _schema_for(frame, headers, formats=None):
    formats = formats or {}
    duplicates = Counter(headers)
    schema = []
    for position, cid in enumerate(frame.columns):
        name = headers[position]
        schema.append({
            "id": cid, "name": name, "original_name": name,
            "position": position + 1, "dtype": str(frame[cid].dtype),
            "role": _guess_role(frame[cid], name), "role_status": "inferred",
            "description": "", "unit": "", "definition_status": "unconfirmed",
            "duplicate_header": duplicates[name] > 1,
            "number_formats": formats.get(cid, {}),
        })
    return schema


def _load_csv(raw, settings):
    text, encoding = _decode_csv(raw, settings.get("encoding"))
    separator = settings.get("separator", ",")
    if separator == "\\t":
        separator = "\t"
    if separator in (None, "auto"):
        try:
            separator = csv.Sniffer().sniff(text[:65536], delimiters=",;\t|").delimiter
        except csv.Error:
            separator = ","
    if not isinstance(separator, str) or len(separator) != 1:
        raise ValueError("구분자는 한 글자여야 합니다.")
    header_row = settings.get("header_row", 0)
    if not isinstance(header_row, int) or not 0 <= header_row <= 100:
        raise ValueError("헤더 행은 0~100 범위에서 지정해 주세요.")
    reader = csv.reader(io.StringIO(text, newline=""), delimiter=separator, strict=True)
    try:
        for _ in range(header_row):
            next(reader)
        headers = next(reader)
    except (StopIteration, csv.Error) as exc:
        raise ValueError("헤더 행을 읽지 못했습니다. 구분자와 헤더 위치를 확인해 주세요.") from exc
    if not headers or len(headers) > MAX_COLUMNS:
        raise ValueError(f"1~{MAX_COLUMNS}개 컬럼으로 구성된 파일을 지원합니다.")
    ids = [f"c{i + 1:04d}" for i in range(len(headers))]
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", pd.errors.ParserWarning)
            frame = pd.read_csv(io.StringIO(text), sep=separator, header=header_row, names=ids,
                                dtype=str, na_filter=False, keep_default_na=False,
                                skip_blank_lines=False, on_bad_lines="error", index_col=False)
    except (pd.errors.ParserError, pd.errors.ParserWarning, ValueError) as exc:
        raise ValueError("행마다 컬럼 수가 다르거나 CSV 형식이 올바르지 않습니다. 구분자·따옴표·헤더 위치를 확인해 주세요.") from exc
    info = {"encoding": encoding, "separator": separator, "raw_headers": headers,
            "settings": {"encoding": encoding, "separator": separator, "header_row": header_row},
            "warnings": [], "xlsx_formats": {}}
    return frame, headers, info


def _load_arff(raw, settings):
    """Read dense ARFF while keeping declared names and text values reviewable."""
    text, encoding = _decode_csv(raw, settings.get("encoding"))
    attributes, data_lines, in_data = [], [], False
    relation = ""
    attribute_pattern = re.compile(
        r"^@attribute\s+(?:'((?:[^'\\]|\\.)*)'|\"((?:[^\"\\]|\\.)*)\"|(\S+))\s+(.+)$",
        re.IGNORECASE,
    )
    for line_number, raw_line in enumerate(text.splitlines(), 1):
        line = raw_line.strip()
        if not line or line.startswith("%"):
            continue
        if in_data:
            data_lines.append((line_number, raw_line))
            continue
        if line.lower().startswith("@relation"):
            relation = line[len("@relation"):].strip().strip("'\"")
        elif line.lower().startswith("@attribute"):
            match = attribute_pattern.match(line)
            if not match:
                raise ValueError(f"ARFF {line_number}행의 컬럼 정의를 읽지 못했습니다.")
            name = next(value for value in match.groups()[:3] if value is not None)
            kind = match.group(4).strip()
            if kind.lower().startswith("relational"):
                raise ValueError("관계형 ARFF 컬럼은 아직 지원하지 않습니다. 일반 표 형태로 저장해 주세요.")
            attributes.append((name, kind))
        elif line.lower() == "@data":
            in_data = True
        elif line.startswith("@"):
            raise ValueError(f"ARFF {line_number}행에 지원하지 않는 선언이 있습니다.")
    if not in_data or not attributes:
        raise ValueError("ARFF의 @attribute 또는 @data 영역을 찾지 못했습니다.")
    if len(attributes) > MAX_COLUMNS:
        raise ValueError(f"1~{MAX_COLUMNS}개 컬럼으로 구성된 파일을 지원합니다.")
    rows, missing_count = [], 0
    for line_number, line in data_lines:
        if line.strip().startswith("{"):
            raise ValueError("희소 ARFF는 값의 기본 의미가 달라 자동 변환하지 않습니다. dense ARFF 또는 CSV로 저장해 주세요.")
        try:
            quote = "'" if "'" in line and '"' not in line else '"'
            values = next(csv.reader([line], skipinitialspace=True, quotechar=quote))
        except csv.Error as exc:
            raise ValueError(f"ARFF {line_number}행의 값을 읽지 못했습니다.") from exc
        if len(values) != len(attributes):
            raise ValueError(f"ARFF {line_number}행의 값 수가 컬럼 수와 다릅니다.")
        normalized = []
        for value in values:
            if value.strip() == "?":
                normalized.append(None)
                missing_count += 1
            else:
                normalized.append(value)
        rows.append(normalized)
    headers = [name for name, _ in attributes]
    ids = [f"c{i + 1:04d}" for i in range(len(headers))]
    frame = pd.DataFrame(rows, columns=ids, dtype=object)
    warnings_list = []
    if missing_count:
        warnings_list.append(f"ARFF의 결측 표시(?) {missing_count:,}개를 결측값으로 읽었습니다. 원본 파일은 그대로 보관합니다.")
    info = {
        "encoding": encoding, "format": "arff", "relation": relation,
        "attribute_types": {ids[i]: kind for i, (_, kind) in enumerate(attributes)},
        "raw_headers": headers,
        "settings": {"encoding": encoding}, "warnings": warnings_list, "xlsx_formats": {},
    }
    return frame, headers, info


def _ts_metadata(text):
    metadata, data_index = {}, None
    for index, raw_line in enumerate(text.splitlines()):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.lower() == "@data":
            data_index = index + 1
            break
        if line.startswith("@"):
            key, _, value = line[1:].partition(" ")
            metadata[key.lower()] = value.strip()
    return metadata, data_index


def _ts_values(segment, timestamped, line_number):
    if not segment.strip():
        return []
    if not timestamped:
        return [None if value.strip() == "?" else value.strip()
                for value in next(csv.reader([segment], skipinitialspace=True))]
    matches = re.findall(r"\(([^,()]+),([^()]+)\)", segment)
    remainder = re.sub(r"\(([^,()]+),([^()]+)\)", "", segment).replace(",", "").strip()
    if not matches or remainder:
        raise ValueError(f"TS {line_number}행의 timestamp 값을 읽지 못했습니다.")
    values = []
    for timestamp, value in matches:
        values.extend([timestamp.strip(), None if value.strip() == "?" else value.strip()])
    return values


def _load_ts(raw, settings):
    """Read the common UEA/UCR .ts structure; plain delimited .ts falls back to text."""
    text, encoding = _decode_csv(raw, settings.get("encoding"))
    metadata, data_index = _ts_metadata(text)
    if data_index is None:
        fallback = dict(settings)
        fallback.setdefault("separator", "auto")
        frame, headers, info = _load_csv(raw, fallback)
        info.update(format="delimited-ts")
        return frame, headers, info
    timestamped = metadata.get("timestamps", "false").lower() == "true"
    has_label = (metadata.get("classlabel", "false").lower().split()[:1] == ["true"]
                 or metadata.get("targetlabel", "false").lower().split()[:1] == ["true"])
    parsed_rows, widths, dimension_count = [], [], None
    lines = text.splitlines()
    for offset, raw_line in enumerate(lines[data_index:], data_index + 1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(":")
        label = parts.pop() if has_label else None
        if dimension_count is None:
            dimension_count = len(parts)
        if not parts or len(parts) != dimension_count:
            raise ValueError(f"TS {offset}행의 차원 수가 다른 행과 다릅니다.")
        dimensions = [_ts_values(part, timestamped, offset) for part in parts]
        widths.append([len(values) for values in dimensions])
        parsed_rows.append((dimensions, label))
    if not parsed_rows:
        raise ValueError("TS의 @data 영역에 분석할 행이 없습니다.")
    maximums = [max(row_width[i] for row_width in widths) for i in range(dimension_count)]
    headers = []
    for dimension, width in enumerate(maximums, 1):
        if timestamped:
            for position in range(1, width // 2 + 1):
                headers.extend([f"series_{dimension}_time_{position}", f"series_{dimension}_value_{position}"])
        else:
            headers.extend(f"series_{dimension}_t{position}" for position in range(1, width + 1))
    if has_label:
        headers.append("class")
    if len(headers) > MAX_COLUMNS:
        raise ValueError(f"TS를 펼치면 {len(headers):,}개 컬럼이 됩니다. {MAX_COLUMNS}개 이하인 데이터만 지원합니다.")
    rows = []
    for dimensions, label in parsed_rows:
        row = []
        for index, values in enumerate(dimensions):
            row.extend(values + [None] * (maximums[index] - len(values)))
        if has_label:
            row.append(None if label.strip() == "?" else label.strip())
        rows.append(row)
    ids = [f"c{i + 1:04d}" for i in range(len(headers))]
    frame = pd.DataFrame(rows, columns=ids, dtype=object)
    info = {
        "encoding": encoding, "format": "time-series-ts", "ts_metadata": metadata,
        "raw_headers": headers, "settings": {"encoding": encoding},
        "warnings": ["시계열의 각 관측 위치를 컬럼으로 펼쳐 읽었습니다. 원본 파일은 그대로 보관합니다."],
        "xlsx_formats": {},
    }
    return frame, headers, info


def inspect_archive(raw: bytes):
    """List supported ZIP members without extracting paths to disk."""
    if not isinstance(raw, bytes) or not raw:
        raise ValueError("ZIP 파일이 비어 있습니다.")
    if len(raw) > MAX_FILE_BYTES:
        raise ValueError("150MB 이하 파일을 업로드해 주세요.")
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            items = []
            names = set()
            for member in archive.infolist():
                if member.is_dir() or Path(member.filename).suffix.lower() not in SUPPORTED_DATA_SUFFIXES:
                    continue
                if member.filename in names:
                    raise ValueError("ZIP 안에 이름이 같은 데이터 파일이 둘 이상 있습니다. 파일명을 구분해 다시 압축해 주세요.")
                names.add(member.filename)
                if member.flag_bits & 0x1:
                    raise ValueError("암호화된 ZIP 파일은 읽을 수 없습니다.")
                if member.file_size > MAX_FILE_BYTES:
                    raise ValueError(f"ZIP 안의 {Path(member.filename).name} 파일이 150MB를 넘습니다.")
                if member.file_size > 10 * 1024 * 1024 and member.file_size > max(member.compress_size, 1) * 200:
                    raise ValueError("압축률이 비정상적으로 높은 파일은 안전을 위해 읽지 않습니다.")
                items.append({"name": member.filename, "size_bytes": member.file_size,
                              "type": Path(member.filename).suffix.lower().lstrip(".")})
    except zipfile.BadZipFile as exc:
        raise ValueError("유효한 ZIP 파일이 아닙니다.") from exc
    if not items:
        raise ValueError("ZIP 안에 지원하는 데이터 파일이 없습니다.")
    return items


def _load_xlsx(raw, settings):
    from openpyxl import load_workbook

    # Expanded size matters for compressed spreadsheets. No extraction to disk.
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            expanded = sum(item.file_size for item in archive.infolist())
        if expanded > MAX_FRAME_BYTES:
            raise ValueError("압축을 해제한 Excel 데이터가 메모리 예산을 초과합니다. 시트나 컬럼을 나눠 주세요.")
    except zipfile.BadZipFile as exc:
        raise ValueError("유효한 XLSX 파일이 아닙니다.") from exc
    book = load_workbook(io.BytesIO(raw), read_only=True, data_only=False, keep_links=False)
    try:
        requested = settings.get("sheet", 0)
        if isinstance(requested, int):
            if not 0 <= requested < len(book.sheetnames):
                raise ValueError("지정한 시트가 없습니다.")
            sheet = book[book.sheetnames[requested]]
        elif requested in book.sheetnames:
            sheet = book[requested]
        else:
            raise ValueError("지정한 시트가 없습니다.")
        if (sheet.max_column or 0) > MAX_COLUMNS:
            raise ValueError(f"서식 영역을 포함해 {MAX_COLUMNS}개 컬럼 이하인 시트를 지원합니다. 오른쪽의 불필요한 열을 삭제해 주세요.")
        header_row = settings.get("header_row", 0)
        if not isinstance(header_row, int) or not 0 <= header_row <= 100:
            raise ValueError("헤더 행은 0~100 범위에서 지정해 주세요.")
        rows = sheet.iter_rows(min_row=header_row + 1)
        header_cells = next(rows, None)
        if not header_cells:
            raise ValueError("시트에 헤더가 없습니다.")
        # Ignore trailing formatted but empty cells, not empty headers within data.
        last = max((i + 1 for i, cell in enumerate(header_cells) if cell.value is not None), default=0)
        if last > MAX_COLUMNS:
            raise ValueError(f"1~{MAX_COLUMNS}개 컬럼으로 구성된 시트를 지원합니다.")
        original_headers = [_text(cell.value) for cell in header_cells]
        ids = [f"c{i + 1:04d}" for i in range(len(header_cells))]
        values, formats, formulas, pad_count = [], {cid: Counter() for cid in ids}, 0, 0
        warnings_list = []
        for row in rows:
            row_width = max((i + 1 for i, cell in enumerate(row) if cell.value is not None), default=0)
            last = max(last, row_width)
            current = []
            for i, cell in enumerate(row):
                value = cell.value
                fmt = getattr(cell, "number_format", "General") or "General"
                if value is not None:
                    formats[ids[i]][fmt] += 1
                if getattr(cell, "data_type", None) == "f":
                    formulas += 1
                # Exact zero masks encode lexical identifiers; preserve displayed zeros.
                if isinstance(value, (int, float)) and not isinstance(value, bool) and re.fullmatch(r"0{2,}", fmt) and float(value).is_integer():
                    sign = "-" if value < 0 else ""
                    value = sign + str(abs(int(value))).zfill(len(fmt))
                    pad_count += 1
                current.append(value)
            values.append(current)
            if len(values) * last > 8_000_000:
                raise ValueError("Excel 셀 수가 메모리 예산을 초과합니다. 시트나 컬럼을 나눠 주세요.")
        while values and all(value is None for value in values[-1]):
            values.pop()
        if not last:
            raise ValueError("시트에 분석할 값이 없습니다.")
        headers = (original_headers + [""] * last)[:last]
        ids = ids[:last]
        values = [(row + [None] * last)[:last] for row in values]
        if any(not header for header in headers):
            warnings_list.append("컬럼명이 비어 있는 열이 있습니다. 원래 위치와 값을 보존했으며 이름을 지정할 수 있습니다.")
        if formulas:
            warnings_list.append(f"수식 셀 {formulas:,}개는 수식 원문을 보존했습니다. 최신 계산값이 필요하면 Excel에서 값으로 저장해 주세요.")
        if pad_count:
            warnings_list.append(f"숫자 표시 형식의 선행 0을 {pad_count:,}개 셀에 보존했습니다. 원본 파일도 별도로 유지됩니다.")
        frame = pd.DataFrame(values, columns=ids, dtype=object)
        normalized_formats = {cid: dict(counts.most_common(20)) for cid, counts in formats.items() if counts}
        info = {"sheet": sheet.title, "sheets": book.sheetnames, "raw_headers": headers,
                "settings": {"sheet": sheet.title, "header_row": header_row},
                "xlsx_formats": normalized_formats, "formula_cells": formulas,
                "display_zero_preserved": pad_count, "warnings": warnings_list}
        return frame, headers, info
    finally:
        book.close()


def load_dataset(raw: bytes, filename: str, settings: dict | None = None):
    """Return a preserved frame, stable column schema, and reproducible ingest settings."""
    if not isinstance(raw, bytes) or not raw:
        raise ValueError("파일이 비어 있습니다.")
    if len(raw) > MAX_FILE_BYTES:
        raise ValueError("150MB 이하 파일을 업로드해 주세요.")
    settings = dict(settings or {})
    suffix = Path(filename).suffix.lower()
    outer = None
    if suffix == ".zip":
        members = inspect_archive(raw)
        selected = settings.get("archive_member")
        if not selected and len(members) == 1:
            selected = members[0]["name"]
        if selected not in {item["name"] for item in members}:
            raise ValueError("ZIP 안에서 분석할 데이터 파일을 선택해 주세요.")
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                inner = archive.read(selected)
        except (KeyError, RuntimeError, zipfile.BadZipFile) as exc:
            raise ValueError("ZIP 안의 선택한 파일을 읽지 못했습니다.") from exc
        inner_settings = {key: value for key, value in settings.items() if key != "archive_member"}
        frame, schema, info = load_dataset(inner, selected, inner_settings)
        outer = {
            "filename": Path(filename).name, "source_sha256": hashlib.sha256(raw).hexdigest(),
            "size_bytes": len(raw), "archive_member": selected,
            "inner_source_sha256": hashlib.sha256(inner).hexdigest(),
        }
        info["settings"] = {**info.get("settings", {}), "archive_member": selected}
        info["archive_members"] = members
        headers = info["raw_headers"]
    elif suffix == ".csv":
        frame, headers, info = _load_csv(raw, settings)
    elif suffix in {".txt", ".tsv"}:
        text_settings = dict(settings)
        text_settings.setdefault("separator", "\t" if suffix == ".tsv" else "auto")
        frame, headers, info = _load_csv(raw, text_settings)
        info["format"] = "delimited-text"
    elif suffix == ".arff":
        frame, headers, info = _load_arff(raw, settings)
    elif suffix == ".ts":
        frame, headers, info = _load_ts(raw, settings)
    elif suffix == ".xlsx":
        frame, headers, info = _load_xlsx(raw, settings)
    else:
        raise ValueError("CSV, XLSX, TXT, TSV, ARFF, TS 또는 이 파일을 담은 ZIP을 업로드해 주세요.")
    if frame.empty:
        raise ValueError("헤더 외에 분석할 행이 없습니다.")
    memory = int(frame.memory_usage(index=True, deep=True).sum())
    if memory > MAX_FRAME_BYTES:
        raise ValueError("읽은 데이터가 메모리 예산(768MB)을 초과합니다. 행이나 컬럼을 나눠 주세요.")
    frame.index = pd.RangeIndex(len(frame), name="row_id")
    schema = _schema_for(frame, headers, info.get("xlsx_formats"))
    for column in schema:
        if column["role"] == "id" and pd.to_numeric(frame[column["id"]], errors="coerce").notna().any() and suffix == ".xlsx":
            original = frame[column["id"]].dropna()
            if any(isinstance(v, (int, float, np.number)) for v in original.head(1000)):
                info["warnings"].append(f"{column['name']}: 숫자로 저장된 ID가 있습니다. 파일에 남아 있지 않은 선행 0은 복원할 수 없습니다.")
    info.update({"filename": Path(filename).name, "source_sha256": hashlib.sha256(raw).hexdigest(),
                 "size_bytes": len(raw), "memory_bytes": memory, "rows": len(frame),
                 "columns": len(frame.columns), "loader_version": "1.1",
                 "missing_policy": "실제 결측과 빈 문자열만 결측으로 집계. NA·null·공백 문자열은 원래 값으로 보존."})
    if outer:
        info.update(outer)
    return frame, schema, info


def standalone_loader_source() -> str:
    """Exact loader implementation for a self-contained exported notebook."""
    return Path(__file__).read_text(encoding="utf-8")


notebook_loader_source = standalone_loader_source
