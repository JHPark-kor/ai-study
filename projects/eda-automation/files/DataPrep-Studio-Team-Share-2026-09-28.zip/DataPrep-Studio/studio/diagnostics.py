"""Connection diagnostics run in the same process as the login request."""
import urllib.error
import urllib.request


def auth_transport():
    # No credentials, OAuth codes or tokens are sent. HTTP rejection of OPTIONS is normal.
    request=urllib.request.Request('https://auth.openai.com/oauth/token',method='OPTIONS')
    try:
        with urllib.request.urlopen(request,timeout=6) as response:
            return {'reachable':True,'http_status':response.status}
    except urllib.error.HTTPError as exc:
        return {'reachable':True,'http_status':exc.code}
    except (urllib.error.URLError,TimeoutError,OSError):
        return {'reachable':False,'message':'현재 웹앱 실행 환경에서 인증 서버에 연결할 수 없습니다. 이 폴더의 시작.cmd로 일반 로컬 환경에서 실행한 뒤 다시 시도해 주세요.'}
