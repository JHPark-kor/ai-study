"""Validate a DataPrep Studio source ZIP before sharing it."""
from __future__ import annotations

import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path, PurePosixPath


ROOT = "DataPrep-Studio"
BLOCKED_SEGMENTS = {
    ".venv", ".codex", "data", "logs", "run", "dist",
    "__pycache__", ".pytest_cache", ".git",
}
BLOCKED_FILES = {".env", "secrets.toml"}
TEXT_SUFFIXES = {".py", ".md", ".ps1", ".cmd", ".toml", ".json", ".txt", ".csv", ".example"}
REQUIRED = {
    f"{ROOT}/README.md",
    f"{ROOT}/TEAM_SETUP.md",
    f"{ROOT}/DEVELOPMENT.md",
    f"{ROOT}/AGENTS.md",
    f"{ROOT}/.env.example",
    f"{ROOT}/setup.ps1",
    f"{ROOT}/start.ps1",
    f"{ROOT}/app.py",
    f"{ROOT}/studio/codex_client.py",
    f"{ROOT}/package_manifest.json",
}


def validate(zip_path: Path) -> dict:
    errors: list[str] = []
    with zipfile.ZipFile(zip_path) as archive:
        names = set(archive.namelist())
        missing = sorted(REQUIRED - names)
        if missing:
            errors.append("필수 파일 누락: " + ", ".join(missing))

        for name in sorted(names):
            parts = PurePosixPath(name).parts
            if any(part in BLOCKED_SEGMENTS for part in parts):
                errors.append(f"제외 폴더 포함: {name}")
            if PurePosixPath(name).name in BLOCKED_FILES:
                errors.append(f"제외 파일 포함: {name}")

            suffix = PurePosixPath(name).suffix.lower()
            if suffix not in TEXT_SUFFIXES or name.endswith("package_manifest.json"):
                continue
            text = archive.read(name).decode("utf-8-sig", errors="ignore")
            if re.search(r"C:[\\/]Users[\\/][^\\/\r\n]+", text, re.IGNORECASE):
                errors.append(f"개인 Windows 경로 포함: {name}")
            if re.search(r"sk-[A-Za-z0-9_-]{12,}", text):
                errors.append(f"API 키 형태 문자열 포함: {name}")
            for line in text.splitlines():
                if not line.strip().upper().startswith("PGPASSWORD="):
                    continue
                value = line.split("=", 1)[1].strip()
                if value and value != "각자_PC의_비밀번호":
                    errors.append(f"PostgreSQL 비밀번호 값 포함: {name}")

        manifest_name = f"{ROOT}/package_manifest.json"
        if manifest_name in names:
            manifest = json.loads(archive.read(manifest_name).decode("utf-8-sig"))
            for entry in manifest.get("files", []):
                archived_name = f"{ROOT}/{entry['path']}"
                if archived_name not in names:
                    errors.append(f"매니페스트 파일 누락: {archived_name}")
                    continue
                actual = hashlib.sha256(archive.read(archived_name)).hexdigest()
                if actual != entry["sha256"]:
                    errors.append(f"해시 불일치: {archived_name}")

        broken = archive.testzip()
        if broken:
            errors.append(f"ZIP 손상: {broken}")

    if errors:
        raise ValueError("\n".join(errors))
    return {
        "zip": str(zip_path.resolve()),
        "files": len(names),
        "bytes": zip_path.stat().st_size,
        "sha256": hashlib.sha256(zip_path.read_bytes()).hexdigest(),
        "status": "ok",
    }


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("사용법: python verify_share_package.py <공유 ZIP>")
    print(json.dumps(validate(Path(sys.argv[1])), ensure_ascii=False, indent=2))
