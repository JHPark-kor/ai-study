# Data

This project uses the **SECOM** dataset from the UCI Machine Learning Repository.

Dataset page:
https://archive.ics.uci.edu/dataset/179/secom

Place the following files under `data/raw/`:

```text
data/raw/
├─ secom.data
└─ secom_labels.data
```

The raw data files are not included in this repository.  
SECOM contains anonymized semiconductor manufacturing process measurements and a Pass/Fail label.
