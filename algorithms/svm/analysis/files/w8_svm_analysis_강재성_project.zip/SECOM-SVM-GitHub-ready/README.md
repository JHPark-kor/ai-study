# SECOM SVM Classification

반도체 제조 공정 데이터 **SECOM**을 이용해 `Pass(-1)` / `Fail(+1)`을 분류한 SVM 프로젝트입니다.

## Project Goal

SECOM은 Fail 비율이 낮은 불균형 데이터입니다. 따라서 단순 Accuracy보다 다음 지표를 중심으로 평가했습니다.

- Balanced Accuracy
- Fail Recall
- Fail F1
- ROC-AUC

## Dataset

- Samples: 1,567
- Raw features: 590
- Pass (-1): 1,463 (93.36%)
- Fail (+1): 104 (6.64%)
- Train/Test: 80/20 stratified split
- Test Fail samples: 21

Source: UCI Machine Learning Repository  
https://archive.ics.uci.edu/dataset/179/secom

## Project Structure

```text
SECOM-SVM/
├─ README.md
├─ requirements.txt
├─ .gitignore
├─ notebooks/
│  └─ 02_secom_svm.ipynb
├─ results/
│  ├─ svm_model_comparison_final.csv
│  └─ pca_variance_comparison.csv
└─ data/
   ├─ README.md
   └─ raw/
      └─ .gitkeep
```

## Preprocessing

Train 데이터만 기준으로 전처리 기준을 결정했습니다.

1. 결측률 50% 이상 변수 제거: 590 → 566
2. 상수 변수 제거: 566 → 450
3. Median imputation
4. StandardScaler

## Experiments

1. Linear SVM
2. Basic RBF-SVM
3. `C × gamma` Grid Search
4. PCA 90% + RBF-SVM
5. Decision threshold tuning
6. `C × gamma × class_weight` tuning
7. SelectKBest + RBF-SVM
8. Repeated Stratified CV stability check

## Main Results

| Model | Accuracy | Balanced Accuracy | Fail Recall | Fail F1 | ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Linear SVM | 0.8567 | 0.5475 | 0.1905 | 0.1509 | 0.6096 |
| Basic RBF-SVM | **0.9268** | 0.5187 | 0.0476 | 0.0800 | 0.6329 |
| Tuned RBF-SVM | 0.8089 | 0.6324 | 0.4286 | **0.2308** | 0.6930 |
| PCA90 + Tuned RBF | 0.7866 | 0.5983 | 0.3810 | 0.1928 | 0.6771 |
| **SelectKBest(35) + RBF-SVM** | 0.7834 | **0.6408** | **0.4762** | 0.2273 | **0.7754** |

### Accuracy Trap

Basic RBF-SVM의 Accuracy는 92.68%였지만 Test의 Fail 21개 중 **1개만 탐지**했습니다.

따라서 이 프로젝트에서는 Accuracy가 높은 모델보다 **Fail을 실제로 구분하는 모델**이 더 중요했습니다.

### Threshold Trade-off

Train OOF score에서 threshold를 조정하면 Test Fail Recall이 **0.7619 (16/21)**까지 상승했습니다.

하지만 정상 293개 중 **142개를 Fail로 오탐**하여 최종 모델로 채택하지 않았습니다.

## Final Model

```python
Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler()),
    ("select", SelectKBest(score_func=f_classif, k=35)),
    ("svc", SVC(
        kernel="rbf",
        C=2.0,
        gamma=0.004,
        class_weight="balanced"
    ))
])
```

Feature count: **450 → 35 (92.2% reduction)**

Test confusion matrix:

```text
[[236, 57],
 [ 11, 10]]
```

즉 Fail 21개 중 **10개를 탐지**했습니다.

## Stability Check

Fixed final model with RepeatedStratifiedKFold (5 folds × 10 repeats):

| Metric | Mean ± Std |
|---|---:|
| Balanced Accuracy | 0.6099 ± 0.0530 |
| Fail Recall | 0.4457 ± 0.1091 |
| Fail F1 | 0.1930 ± 0.0431 |
| ROC-AUC | 0.6679 ± 0.0501 |

## Run

Python 3.11 is recommended.

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
pip install -r requirements.txt
jupyter notebook
```

Download the SECOM data, place it under `data/raw/`, and run:

```text
notebooks/02_secom_svm.ipynb
```

## Methodology Notes / Limitations

- Fail이 전체 데이터의 약 6.64%로 매우 적습니다.
- Test에 Fail이 21개뿐이라 한두 개 예측 변화가 Recall에 크게 영향을 줍니다.
- 개발 과정에서 동일 Test 결과를 여러 번 확인했기 때문에 Test set은 완전히 untouched holdout이라고 보기 어렵습니다.
- 엄밀한 최종 성능 추정에는 **Nested Cross Validation** 또는 새로운 독립 holdout이 필요합니다.
- 기존 보고서의 Tuned RBF 수치를 재현하기 위해 해당 섹션은 Train 전체에서 fit한 imputer/scaler 결과를 CV에 입력합니다. 더 엄밀한 fold-level preprocessing은 Pipeline 사용이 권장됩니다.
- SelectKBest 실험은 imputer/scaler/feature selection을 Pipeline 내부에서 수행합니다.

## Key Takeaway

SECOM 불량 분류에서는 높은 Accuracy 자체보다 **불균형을 고려한 평가와 지도형 Feature Selection**이 중요했습니다.  
PCA보다 SelectKBest가 더 효과적이었고, 35개 변수만 사용하면서 최종 Test에서 가장 높은 Balanced Accuracy와 ROC-AUC를 기록했습니다.
